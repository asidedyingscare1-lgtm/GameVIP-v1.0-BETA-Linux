"""Clear the plate the branding art ships on, so a window shows artwork only.

The supplied artwork arrives as a logo painted on a plate of its own
background. The windows draw it as a whole rectangle on one of their surfaces,
so a frame of the wrong tone shows around the art.

Cutting the plate out as transparent pixels is the obvious answer and it does
not work for this art: the emblem is a dark figure on black, where the figure's
own black and the plate's black are the same connected black. Keying at any
tolerance that clears the plate also eats the face and the cloak -- checked by
keying one at 2, 4, 6 and 8 and rendering each over magenta -- so the plate is
composited into the surface colour the window draws the art on instead. Pixels
that match the plate take the surface colour, artwork pixels are left alone,
and the two meet on a ramp rather than a step, so the frame stops showing and
no hard outline appears where it used to be. The largest change made to any
pixel is then the gap between the plate and the surface, a few levels out of
255.

The surface colour is read from the window's own palette (single source of
truth), never typed in here. Output goes to assets/branding_t/, which the
windows prefer when both copies are present -- the same arrangement
tools/key_icons.py uses for the row icons. The originals stay untouched, and
running this again always starts from them.

    python tools/clear_branding_frames.py
"""
import os
import re
import sys

from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'assets', 'branding')
DST = os.path.join(ROOT, 'assets', 'branding_t')

# (asset, the file whose palette it is drawn against, the token in that palette)
FILES = (('sidebar-emblem.png', 'control.py', 'sidebar'),
         ('sidebar-wordmark.png', 'control.py', 'sidebar'))

# The frame is not one flat tone, so the band covers its whole variation: every
# pixel this close to the plate becomes the surface colour exactly, and the art
# takes over on a ramp from there, with no step where the two meet.
PLATE_BAND = 8
REACH = 48          # colour distance at which the artwork is fully itself


def surface_colour(source, token):
    """The window's own colour for that token, so the two can never drift."""
    with open(os.path.join(ROOT, source), encoding='utf-8') as handle:
        text = handle.read()
    found = re.search(r"'%s': '(#[0-9a-fA-F]{6})'" % token, text)
    if not found:
        raise SystemExit('%s has no %r colour: the tool would guess wrong'
                         % (source, token))
    return tuple(int(found.group(1)[index:index + 2], 16) for index in (1, 3, 5))


def plate_of(image):
    """The frame's own tone: the mean of the four corners."""
    corners = [image.getpixel(spot)[:3] for spot in
               ((0, 0), (image.width - 1, 0), (0, image.height - 1),
                (image.width - 1, image.height - 1))]
    return tuple(sum(channel) // len(corners) for channel in zip(*corners))


def clear(image, surface):
    """The artwork with its frame faded into the surface behind it."""
    plate = plate_of(image)
    result = Image.new('RGB', image.size)
    source, target = image.load(), result.load()
    shifted = 0
    largest = 0
    for x in range(image.width):
        for y in range(image.height):
            here = source[x, y][:3]
            distance = max(abs(here[index] - plate[index]) for index in range(3))
            weight = min(1.0, max(0.0, (distance - PLATE_BAND)
                                    / float(REACH - PLATE_BAND)))
            pixel = tuple(int(round(here[index] * weight
                                    + surface[index] * (1.0 - weight)))
                          for index in range(3))
            if pixel != here:
                shifted += 1
                largest = max(largest, max(abs(pixel[index] - here[index])
                                           for index in range(3)))
            target[x, y] = pixel
    return result, plate, shifted, largest


def main():
    os.makedirs(DST, exist_ok=True)
    for name, palette, token in FILES:
        path = os.path.join(SRC, name)
        if not os.path.isfile(path):
            print('missing %s' % name)
            continue
        surface = surface_colour(palette, token)
        cleared, plate, shifted, largest = clear(
            Image.open(path).convert('RGB'), surface)
        cleared.save(os.path.join(DST, name))
        print('cleared %-26s plate %-12s onto %-12s %6d px moved, largest '
              'shift %d/255' % (name, plate, surface, shifted, largest))
    return 0


if __name__ == '__main__':
    sys.exit(main())
