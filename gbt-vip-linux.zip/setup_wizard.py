"""GameBaTo VIP Spoof - setup (Tkinter, stdlib only).

One clickable window that installs the finished product: it copies the frozen
panel and engine out of its own bundle, opens the firewall ports the PS4 needs,
writes the shortcuts and, if asked, sets the panel to start at logon. Nothing it
installs needs Python, and every step it takes is listed in the window as it
happens.

Nothing here opens a browser on its own. The dashboard page is shown only when
the person running the setup asks for it: with the Options-page toggle, with the
button on the last page, or from a shortcut afterwards. A scripted run needs
--launch to open it, so a double-clicked exe never throws a tab at someone who
only wanted the panel installed.

Run from this file while developing:

    python setup_wizard.py                 the installer window
    python setup_wizard.py --uninstall     the removal window
    python setup_wizard.py --silent --dir=C:\\somewhere
                                           scripted install, no window
    python setup_wizard.py --silent --launch
                                           scripted install that also opens the
                                           dashboard when it finishes

The shipped build is the same code with both executables embedded, so the file
the user double-clicks is the whole product.
"""
import ctypes
import os
import platform
import queue
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import tkinter as tk
from tkinter import filedialog, ttk

APP_NAME = 'GameVIP'
APP_TAGLINE = 'PS4 premium session over your own network'
VERSION = '1.0'

PANEL_EXE = 'GameVIP.exe'
ENGINE_EXE = 'GBTVipTap-Engine.exe'
ICON_FILE = 'gbt.ico'
README_FILE = 'README.md'
MARKER_FILE = 'install.txt'
LOG_FILE = 'setup.log'
# The per-user folder the installed program keeps its working files in
# (%LOCALAPPDATA%\GameBaToVipSpoof). app.py and tap.py carry the same name, so
# the panel, the engine and the removal all agree on one place. Nothing of the
# kind goes in the install folder: that folder is left holding one exe.
DATA_FOLDER = 'GameBaToVipSpoof'

PANEL_PORT = 8899
ENGINE_TCP_PORT = 80
DNS_PORT = 53
TASK_NAME = 'GameVIP'
FIREWALL_RULES = (('GameVIP DNS', 'UDP', DNS_PORT),
                  ('GameVIP HTTP', 'TCP', ENGINE_TCP_PORT),
                  ('GameVIP Panel', 'TCP', PANEL_PORT))
LEGACY_FIREWALL_RULES = ('GBTTap DNS', 'GBTTap HTTP', 'GBTTap Panel')
LEGACY_TASK_NAMES = ('GBTVipTap',)
LEGACY_PANEL_EXES = ('GBTVipTap.exe',)
MIN_FREE_BYTES = 120 * 1024 * 1024
MIN_PROGRESS_MS = 1200         # keep the working page on screen at least this long
DRAIN_MS = 80                   # how often the window picks up worker events
PANEL_OPEN_TIMEOUT = 20         # seconds to wait for the dashboard to answer
NO_WINDOW = 0x08000000          # CREATE_NO_WINDOW: never flash a console
DETACHED = 0x00000008           # DETACHED_PROCESS, for the panel at logon

# Reference visual system (from the approved screenshot): black/charcoal
# surfaces, vivid red brand, green OK, amber warning. One token table so
# every page adjusts together.
C = {'bg': '#060708', 'sidebar': '#0a0b0e', 'card': '#111318',
      'card_edge': '#1e222b', 'ink': '#f2f4f7', 'muted': '#9aa0ab',
      'faint': '#6b7078', 'accent': '#4ae894', 'accent_dim': '#2f8f5d',
      'brand': '#d61f26', 'brand_hot': '#f0333b', 'brand_dim': '#7a1216',
      'ok': '#2fd671', 'warn': '#f5a623', 'bad': '#ff7d7d',
      'row': '#101319', 'line': '#1d4436'}


def app_dir():
    """The folder this build lives in (bundle folder when frozen)."""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def same_path(one, other):
    """True when two paths name the same folder or file."""
    try:
        return (os.path.normcase(os.path.normpath(os.path.abspath(one)))
                == os.path.normcase(os.path.normpath(os.path.abspath(other))))
    except (OSError, ValueError):
        return False


def payload(name):
    """Absolute path of one bundled file, whether frozen or run from source."""
    bundle = getattr(sys, '_MEIPASS', None)
    candidates = []
    if bundle:
        candidates.append(os.path.join(bundle, name))
    here = app_dir()
    candidates += [os.path.join(here, 'release', name), os.path.join(here, name),
                   os.path.join(here, 'build', 'stage', name),
                   os.path.join(here, 'assets', name)]
    for candidate in candidates:
        if os.path.exists(candidate):
            return candidate
    return candidates[0]


def asset_path(*parts):
    """Absolute path of a design asset (assets/ tree), frozen or source."""
    return payload(os.path.join('assets', *parts))


class AssetCache:
    """Tk images for the reference artwork, loaded once and retained.

    Icons ship at native crop size; callers subsample for row height.
    Missing files fall back to None so pages still render (text-first).
    """

    def __init__(self):
        self._images = {}

    def get(self, *parts, subsample=1):
        key = ('/'.join(parts), subsample)
        cached = self._images.get(key)
        if cached is not None:
            try:
                cached.width()
                return cached
            except tk.TclError:
                pass  # image belonged to a destroyed window; reload below
        self._images[key] = self._load(*parts, subsample=subsample)
        return self._images[key]

    def _load(self, *parts, subsample=1):
        path = asset_path(*parts)
        if not os.path.isfile(path):
            return None
        try:
            image = tk.PhotoImage(file=path)
        except tk.TclError:
            return None
        if subsample > 1:
            try:
                image = image.subsample(subsample, subsample)
            except tk.TclError:
                pass
        return image


ASSETS = AssetCache()


# The subfolder a build before this one made beside the setup. This build
# installs into the setup's own folder instead, so this name is only used to
# find and sweep an install left by that older build.
LEGACY_INSTALL_FOLDER = 'GameVIP'


def data_dir():
    """The per-user folder for the log, the cache, the heartbeat and, on a
    removal, the files an install left there."""
    base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
    return os.path.join(base, DATA_FOLDER)


def local_install_dir():
    """The folder under the user's own Programs tree.

    This is where the setup used to install by default, so it is still where
    an install from an older build is looked for -- and still the fallback
    when the folder the setup was started from cannot host the program.
    """
    base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
    return os.path.join(base, 'Programs', 'GameBaToVipSpoof')


def can_host_install(folder):
    """Could the program live in this folder?

    It has to be a folder this user can write to without elevation, on the
    machine rather than in a temporary folder that gets swept up, and not one
    of the protected system folders. The working files do not need it -- the
    installed program keeps its log, cache and heartbeat in the per-user
    folder (see data_dir) -- but replacing or removing the program later does,
    and the setup runs elevated, so a test that only asked "can I write here?"
    would happily put the program in Program Files and then need an
    administrator for every one of those afterwards.
    """
    try:
        resolved = os.path.abspath(folder)
    except OSError:
        return False
    protected_names = (os.environ.get('ProgramFiles'),
                       os.environ.get('ProgramFiles(x86)'),
                       os.environ.get('ProgramW6432'),
                       os.environ.get('SystemRoot'),
                       os.environ.get('windir'),
                       tempfile.gettempdir())
    for name in protected_names:
        if not name:
            continue
        try:
            protected = os.path.abspath(name)
            if os.path.commonpath([resolved, protected]) == protected:
                return False
        except ValueError:              # another drive: cannot be inside it
            continue
    if os.path.dirname(resolved) == resolved:
        return False                    # a bare drive root, not a folder
    probe = os.path.join(resolved, '.gbt-write-test')
    try:
        with open(probe, 'w', encoding='utf-8') as handle:
            handle.write('')
    except OSError:
        return False
    try:
        os.remove(probe)
    except OSError:
        pass
    return True


def default_install_dir():
    """Install where the setup itself is sitting, when that folder can host it.

    The setup ships as one file, so the folder it was started from is its home:
    drop it in a folder, run it, and the program lands in that same folder
    beside the setup -- one folder to hand over, no GameVIP subfolder created
    inside it to go looking in. Wherever that folder cannot host the program
    (read-only media, a temporary folder, a system folder), the install goes to
    the per-user Programs folder instead, which is also where an install from
    an older build is looked for.
    """
    here = app_dir()
    if can_host_install(here):
        return here
    return local_install_dir()


def install_candidates():
    """Every folder an install could be in, in the order to look for it.

    The setup's own folder first (where this build installs), then the GameVIP
    subfolder an earlier build made inside it, then the per-user Programs
    folder the build before that used, then whatever folder the marker names.
    """
    here = app_dir()
    candidates = [default_install_dir(), os.path.join(here, LEGACY_INSTALL_FOLDER),
                  local_install_dir()]
    marker = read_marker(candidates[0]).get('dir')
    if marker:
        candidates.append(marker)
    return candidates


def run_quiet(arguments):
    """Run a helper program with no window and no inherited handles."""
    try:
        return subprocess.run(arguments, stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL, timeout=60,
                              creationflags=NO_WINDOW if os.name == 'nt' else 0,
                              check=False)
    except (OSError, subprocess.SubprocessError):
        return None


def powershell(script):
    """Run a PowerShell snippet and return its captured stdout."""
    if os.name != 'nt':
        return ''
    try:
        finished = subprocess.run(['powershell', '-NoProfile', '-NonInteractive',
                                   '-ExecutionPolicy', 'Bypass', '-Command', script],
                                  stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                  timeout=60,
                                  creationflags=NO_WINDOW if os.name == 'nt' else 0,
                                  check=False)
    except (OSError, subprocess.SubprocessError):
        return ''
    return finished.stdout.decode('utf-8', 'replace')


def is_admin():
    if os.name != 'nt':
        return os.geteuid() == 0
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except OSError:
        return False


def relaunch_elevated():
    """Ask Windows for an administrator window and hand this run over to it."""
    if os.name != 'nt':
        return False
    parameters = subprocess.list2cmdline(sys.argv[1:])
    try:
        result = ctypes.windll.shell32.ShellExecuteW(
            None, 'runas', sys.executable, parameters, app_dir(), 1)
    except OSError:
        return False
    return result > 32


def port_state(port):
    """'free', 'open' (something answered) or 'unknown' for a local TCP port."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    probe.settimeout(0.4)
    try:
        probe.connect(('127.0.0.1', port))
    except OSError:
        return 'free'
    finally:
        probe.close()
    return 'open'


def free_space(path):
    """Bytes free on the volume that holds this path, or None."""
    probe = path
    while probe and not os.path.isdir(probe):
        probe = os.path.dirname(probe)
    try:
        return shutil.disk_usage(probe or os.getcwd()).free
    except OSError:
        return None


def vcredist_present():
    """True when the VC++ runtime PyInstaller exes need is loadable.

    The panel and engine are frozen with Python 3.12, which needs
    VCRUNTIME140.dll. Windows 10/11 ships it, but a stripped or very old
    install may lack it -- then both exes die on launch with no message.
    """
    if os.name != 'nt':
        return True
    for name in ('vcruntime140.dll', 'vcruntime140_1.dll'):
        try:
            ctypes.windll.kernel32.LoadLibraryW(name)
            return True
        except OSError:
            continue
    try:
        return bool(ctypes.util.find_library('vcruntime140'))
    except OSError:
        return False


def requirements(install_dir):
    """The checklist shown on the first page: (label, ok, detail, fix).

    fix names the repair button beside a failed row, or '' when there is
    nothing to repair: 'elevate' relaunches as administrator, 'vcredist'
    opens the Microsoft download, 'free-port' ends our leftover that holds
    the port and rechecks, 'recheck' just checks again.
    """
    version = sys.getwindowsversion() if os.name == 'nt' else None
    modern = bool(version and (version.major, version.minor) >= (10, 0))
    admin = is_admin()
    vc = vcredist_present()
    panel_port = port_state(PANEL_PORT)
    engine_port = port_state(ENGINE_TCP_PORT)
    space = free_space(install_dir)
    checks = [
        ('Windows 10 or newer',
         modern, platform.platform() if modern else 'Windows %s found' % platform.release(), ''),
        ('Administrator rights',
         admin, 'Granted - firewall rules, shortcuts and logon start are available.'
         if admin else 'Not granted - relaunch to enable firewall, shortcuts and logon start.',
         '' if admin else 'elevate'),
        ('System runtime (VC++ 2015+)',
         vc, 'Present - the compiled programs can start.'
         if vc else 'Missing - both programs would exit silently. The fix downloads it from Microsoft.',
         '' if vc else 'vcredist'),
        ('No Python required',
         True, 'The panel and engine are compiled executables.', ''),
        ('Port %d free' % ENGINE_TCP_PORT,
         engine_port != 'open', 'In use by another program.' if engine_port == 'open'
         else 'Nothing else is serving the store relay.',
         'free-port' if engine_port == 'open' else ''),
        ('Panel port %d' % PANEL_PORT,
         panel_port != 'open',
         'A panel is already open on it; the setup closes and replaces that one.'
         if panel_port == 'open' else 'Free for the dashboard.',
         'free-port' if panel_port == 'open' else ''),
        ('Room to install',
         space is None or space >= MIN_FREE_BYTES,
         ('%.0f MB free' % (space / (1024 * 1024.0))) if space is not None else 'Unknown', ''),
    ]
    return checks


# What an install used to leave in the program's folder beside the program:
# the working files, which belong in the per-user folder now, and the two
# copies of the documentation and the icon, which are not the program at all.
LEGACY_WORKING_FILES = ('panel.log', 'tap.log', 'engine_health.json', 'cache', LOG_FILE)
LEGACY_DOC_FILES = (README_FILE, ICON_FILE)


def tidy_install_folder(install_dir, log):
    """Sweep an older install's leftovers out of the program's folder.

    Working files are moved into the per-user folder (never deleted: the log
    is the only record of what the engine did), and the extra copies of the
    readme and the icon are removed. An install made by this build leaves
    nothing else to find here.

    The folder the setup itself was started from is left alone: this build
    installs into it, but that folder is the one the setup was handed over in
    -- usually the user's own or their download folder -- so nothing in it is
    deleted or carried off. The only leftover an earlier build can have left
    there is a GameVIP subfolder, and tidy_legacy_install_folder takes that one
    away.
    """
    if same_path(install_dir, app_dir()):
        return
    base = data_dir()
    moved, dropped = [], []
    for name in LEGACY_WORKING_FILES:
        source = os.path.join(install_dir, name)
        if not os.path.exists(source):
            continue
        destination = os.path.join(base, name)
        try:
            os.makedirs(base, exist_ok=True)
            if os.path.exists(destination):
                if os.path.isdir(source):
                    shutil.rmtree(source, ignore_errors=True)
                else:
                    os.remove(source)
            else:
                shutil.move(source, destination)
            moved.append(name)
        except OSError as error:
            log('WARNING: could not move %s out of the folder: %s' % (name, error))
    for name in LEGACY_DOC_FILES:
        path = os.path.join(install_dir, name)
        if not os.path.isfile(path):
            continue
        try:
            os.remove(path)
            dropped.append(name)
        except OSError as error:
            log('WARNING: could not remove %s: %s' % (name, error))
    if moved:
        log('Moved %s into %s.' % (', '.join(moved), base))
    if dropped:
        log('Removed the extra %s from the install folder.' % ', '.join(dropped))


def tidy_legacy_install_folder(target, log):
    """Take away the program an earlier build left in a GameVIP subfolder.

    That build installed into a folder of its own beside the setup; this one
    installs beside the setup itself, so that subfolder is left holding a second
    copy of the product the person installing it never asked for. Its working
    files are moved to the per-user folder (kept, not deleted), the program and
    the marker go, and the folder itself is removed only if it ends up empty --
    anything else in there is the user's.
    """
    legacy = os.path.join(app_dir(), LEGACY_INSTALL_FOLDER)
    if os.path.abspath(legacy) == os.path.abspath(target):
        return
    if not os.path.isfile(os.path.join(legacy, PANEL_EXE)):
        return
    tidy_install_folder(legacy, log)
    for name in (PANEL_EXE, MARKER_FILE) + tuple(LEGACY_PANEL_EXES):
        path = os.path.join(legacy, name)
        if not os.path.isfile(path):
            continue
        try:
            os.remove(path)
        except OSError as error:
            log('WARNING: could not remove the old %s: %s' % (name, error))
    try:
        if not os.listdir(legacy):
            os.rmdir(legacy)
            log('Removed the old %s folder: the program lives beside the setup '
                'now.' % LEGACY_INSTALL_FOLDER)
        else:
            log('Kept %s: it holds files that are not ours.' % legacy)
    except OSError as error:
        log('WARNING: could not remove the old %s folder: %s'
            % (LEGACY_INSTALL_FOLDER, error))


def marker_path(install_dir=None):
    """Where the install record goes for one folder (or, with no folder, for
    the per-user folder).

    Beside the program when that folder is ours, so a folder holding the
    program keeps its own record. Not when the program was installed into the
    folder the setup was started from: that one is the user's, and the point of
    the folder they hand over is that it holds the program and the setup and
    nothing else of ours -- so the record goes to the per-user folder with the
    log and the cache.
    """
    if install_dir and same_path(install_dir, app_dir()):
        return os.path.join(data_dir(), MARKER_FILE)
    return os.path.join(install_dir or data_dir(), MARKER_FILE)


def marker_locations(install_dir):
    """Every path the record could be at for this folder, likeliest first."""
    wanted = []
    for path in (marker_path(install_dir),
                 os.path.join(install_dir, MARKER_FILE),
                 os.path.join(data_dir(), MARKER_FILE)):
        if not any(same_path(path, seen) for seen in wanted):
            wanted.append(path)
    return wanted


def hide(path):
    """Mark a file hidden in Explorer, so the install folder shows the program
    and nothing else. Best-effort: a filesystem that refuses the attribute
    still installs and still uninstalls."""
    if os.name != 'nt':
        return False
    try:
        # FILE_ATTRIBUTE_HIDDEN, with the archive bit the file already had.
        return bool(ctypes.windll.kernel32.SetFileAttributesW(str(path), 0x22))
    except Exception:
        return False


def read_marker(install_dir):
    """The options a previous install was made with, or {}.

    Both places are read -- beside the program and in the per-user folder -- so
    an install stays legible whether it landed in a folder of its own or in the
    folder the setup was started from.
    """
    for path in marker_locations(install_dir):
        values = {}
        try:
            with open(path, 'r', encoding='utf-8') as handle:
                for line in handle:
                    key, _, value = line.strip().partition('=')
                    if key:
                        values[key] = value
        except OSError:
            continue
        if values:
            return values
    return {}


def existing_install():
    """The install folder holding our panel exe, or None."""
    for candidate in install_candidates():
        if os.path.isfile(os.path.join(candidate, PANEL_EXE)):
            return candidate
        for legacy in LEGACY_PANEL_EXES:
            if os.path.isfile(os.path.join(candidate, legacy)):
                return candidate
    return None


def write_marker(install_dir, options):
    """Write the install record and return where it went, or None.

    The folder is made first: the record goes to the per-user folder when the
    program was installed into the folder the setup was started from, and on a
    machine that has never run the panel that folder does not exist yet. A
    write that fails says so rather than leaving the caller believing it was
    recorded.
    """
    lines = ['version=%s' % VERSION, 'dir=%s' % install_dir]
    for key, value in sorted(options.items()):
        if isinstance(value, bool):
            lines.append('%s=%s' % (key, '1' if value else '0'))
        else:
            lines.append('%s=%s' % (key, value))
    path = marker_path(install_dir)
    try:
        folder = os.path.dirname(path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        with open(path, 'w', encoding='utf-8') as handle:
            handle.write('\n'.join(lines) + '\n')
    except OSError as error:
        return None
    return path


def panel_port_owners():
    """(pid, name) for whatever is answering on the dashboard port."""
    script = ('$owners = @(Get-NetTCPConnection -LocalPort %d -State Listen -ErrorAction'
              ' SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique);'
              ' foreach ($p in $owners) {'
              ' $proc = Get-CimInstance Win32_Process -Filter "ProcessId=$p" -ErrorAction'
              ' SilentlyContinue;'
              ' if ($proc) { "{0}|{1}" -f $p, $proc.Name } }' % PANEL_PORT)
    found = []
    for line in powershell(script).splitlines():
        pid_text, _, name = line.strip().partition('|')
        if pid_text.strip().isdigit():
            found.append((int(pid_text), name.strip()))
    return found


def stop_running():
    """End a panel or engine left from an earlier run, so files can be replaced.

    Two kinds of leftover matter. A panel or engine started from these very
    executables is matched by image name. A panel started from source is a
    pythonw.exe process instead, and if it kept the dashboard port the freshly
    installed panel would join the old one and serve the old code -- so whatever
    answers on that port is ended as well, but only when its name says it is one
    of ours.
    """
    if os.name != 'nt':
        return []
    stopped = []
    for image in (PANEL_EXE, ENGINE_EXE) + LEGACY_PANEL_EXES:
        result = run_quiet(['taskkill', '/IM', image, '/T', '/F'])
        if result and result.returncode == 0:
            stopped.append(image)
    for pid, name in panel_port_owners():
        lowered = name.lower()
        if not (lowered.startswith('python') or lowered.startswith('gbtviptap')
                or lowered.startswith('gamevip')):
            continue
        result = run_quiet(['taskkill', '/PID', str(pid), '/T', '/F'])
        if result and result.returncode == 0:
            stopped.append('%s (PID %d)' % (name or 'a panel', pid))
    return stopped


def add_firewall_rules(log):
    """(Re)create the inbound rules the PS4 needs; report what was skipped."""
    added, failed = [], []
    for name in [rule[0] for rule in FIREWALL_RULES] + list(LEGACY_FIREWALL_RULES):
        run_quiet(['netsh', 'advfirewall', 'firewall', 'delete', 'rule', 'name=%s' % name])
    for name, protocol, port in FIREWALL_RULES:
        result = run_quiet(['netsh', 'advfirewall', 'firewall', 'add', 'rule',
                            'name=%s' % name, 'dir=in', 'action=allow',
                            'protocol=%s' % protocol, 'localport=%d' % port,
                            'remoteip=localsubnet'])
        if result and result.returncode == 0:
            added.append('%s %d' % (protocol, port))
        else:
            failed.append('%s %d' % (protocol, port))
    if added:
        log('Firewall opened for %s.' % ', '.join(added))
    if failed:
        log('WARNING: the firewall rule for %s was not added. The panel asks for it '
            'again the first time the switch is flipped.' % ', '.join(failed))
    return added, failed


def remove_firewall_rules(log):
    removed = 0
    for name in ([rule[0] for rule in FIREWALL_RULES] + list(LEGACY_FIREWALL_RULES)):
        result = run_quiet(['netsh', 'advfirewall', 'firewall', 'delete', 'rule', 'name=%s' % name])
        if result and result.returncode == 0:
            removed += 1
    if removed:
        log('Removed %d firewall rule%s.' % (removed, '' if removed == 1 else 's'))


def make_shortcut(link_path, target, working_dir, description):
    """Write a .lnk through the Windows Script Host, no extra dependency."""
    script = (
        "$shell = New-Object -ComObject WScript.Shell;"
        "$c = $shell.CreateShortcut('%s');"
        "$c.TargetPath = '%s';"
        "$c.WorkingDirectory = '%s';"
        "$c.IconLocation = '%s';"
        "$c.Description = '%s';"
        "$c.Save()" % (link_path, target, working_dir, target, description))
    powershell(script)
    return os.path.isfile(link_path)


def long_path(path):
    """Long form of a path (resolves 8.3 segments like CYBERF~1).

    The smoke test caught this: $env:TEMP expands to a short path while the
    shortcut target stores the long form, so a naive compare says a shortcut
    pointing at this install points elsewhere. GetLongPathNameW fixes it.
    """
    if os.name != 'nt':
        return os.path.normpath(path)
    try:
        import ctypes
        get_long = ctypes.windll.kernel32.GetLongPathNameW
        buf = ctypes.create_unicode_buffer(32768)
        length = get_long(path, buf, 32768)
        if length and length < 32768:
            return os.path.normpath(buf.value)
    except (AttributeError, OSError):
        pass
    return os.path.normpath(path)


def shortcut_points_at(link_path, install_dir):
    """True when a .lnk still targets this install; anything else is kept.

    A shortcut the user repointed (or one from another program with a
    colliding name) must never be deleted by our uninstall.
    """
    try:
        target = powershell(
            "$s = (New-Object -ComObject WScript.Shell).CreateShortcut('%s');"
            " $s.TargetPath" % link_path).strip()
    except Exception:
        return True  # unreadable: fall back to the old behaviour, remove it
    if not target:
        return True
    wanted = os.path.normcase(long_path(install_dir))
    got_dir = os.path.normcase(long_path(
        os.path.dirname(os.path.abspath(target))))
    return got_dir == wanted or os.path.normcase(long_path(target)).startswith(wanted)


def shortcut_paths():
    start_menu = os.path.join(os.environ.get('APPDATA', app_dir()),
                              'Microsoft', 'Windows', 'Start Menu', 'Programs',
                              '%s.lnk' % APP_NAME)
    desktop = os.path.join(os.environ.get('USERPROFILE', app_dir()), 'Desktop',
                           '%s.lnk' % APP_NAME)
    return start_menu, desktop


def set_autostart(panel, log):
    """Register the panel to start with Windows, or say why it could not."""
    if os.name != 'nt':
        return False
    result = run_quiet(['schtasks', '/create', '/tn', TASK_NAME, '/tr', '"%s"' % panel,
                        '/sc', 'onlogon', '/f'])
    if result and result.returncode == 0:
        log('The panel will start with Windows.')
        return True
    log('WARNING: the logon task was not created; start the panel from its shortcut instead.')
    return False


def clear_autostart(log):
    for task in (TASK_NAME,) + LEGACY_TASK_NAMES:
        result = run_quiet(['schtasks', '/delete', '/tn', task, '/f'])
        if result and result.returncode == 0:
            log('Removed the logon task.')


def launch_panel(panel):
    """Start the panel with no console or window of its own."""
    if os.name != 'nt':
        return run_quiet([panel])
    try:
        subprocess.Popen([panel], cwd=os.path.dirname(panel),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=DETACHED, close_fds=True)
    except OSError:
        return None
    return True


def wait_for_port(port, seconds=15):
    """True once something answers on the loopback port (the panel is up)."""
    import time as _time
    deadline = _time.time() + seconds
    while _time.time() < deadline:
        probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        probe.settimeout(0.4)
        try:
            probe.connect(('127.0.0.1', port))
            return True
        except OSError:
            _time.sleep(0.3)
        finally:
            probe.close()
    return False


def open_dashboard(port=PANEL_PORT):
    """Open the dashboard page in the default browser.

    The frozen panel opens its own page, but this is the backstop: if the
    panel was already running (or its own open failed silently), the user
    still lands on the UI instead of staring at nothing.
    """
    url = 'http://127.0.0.1:%d/' % port
    if os.name == 'nt':
        try:
            os.startfile(url)
            return True
        except OSError:
            pass
    try:
        import webbrowser
        return bool(webbrowser.open(url))
    except Exception:
        return False


def launch_panel_with_page(panel, log=None, port=PANEL_PORT):
    """Open the panel's page, starting the program only when it is down.

    A second copy started while one already answers on the port would fight
    it for the socket, so the running panel is reused and only its page opens.
    """
    if port_state(port) == 'open':
        open_dashboard(port)
        if log is not None:
            log('The dashboard is opening in your browser.')
        return True
    launched = launch_panel(panel)
    if not launched:
        if log is not None:
            log('WARNING: the program could not be started.')
        return False
    if wait_for_port(port):
        open_dashboard(port)
        if log is not None:
            log('The dashboard is opening in your browser.')
        return True
    if log is not None:
        log('WARNING: the program started but its page did not answer. '
            'Open http://127.0.0.1:%d/ yourself.' % port)
    return False


def install(options, log, progress):
    """Copy the product into place and set it up.

    options: dir, desktop, startmenu, firewall, autostart, launch
    log: callable(str) for the running commentary
    progress: callable(done, total, label)
    """
    target = options['dir']
    steps = 7      # one per step() call below; the bar is determinate, so it must match
    done = 0
    # Rollback ledger: everything this run creates is recorded here, so a
    # failure halfway through undoes only what this run did -- never a rule,
    # task or shortcut from an earlier install or another program.
    made = {'dir': False, 'files': [], 'rules': [], 'shortcuts': [],
            'task': False, 'marker': False}

    def step(label):
        nonlocal done
        done += 1
        progress(done, steps, label)

    def rollback(log):
        """Undo this run's partial work, newest first. Best-effort, logged."""
        start_menu, desktop = shortcut_paths()
        for link in reversed(made['shortcuts']):
            try:
                if os.path.isfile(link):
                    os.remove(link)
                    log('Rolled back %s.' % os.path.basename(link))
            except OSError:
                pass
        if made['task']:
            clear_autostart(log)
        for name in reversed(made['rules']):
            run_quiet(['netsh', 'advfirewall', 'firewall', 'delete', 'rule',
                       'name=%s' % name])
            log('Rolled back firewall rule %s.' % name)
        for path in reversed(made['files']):
            try:
                if os.path.isfile(path):
                    os.remove(path)
            except OSError:
                pass
        if made['dir']:
            try:
                if os.path.isdir(target) and not os.listdir(target):
                    os.rmdir(target)
                    log('Rolled back %s.' % target)
            except OSError:
                pass

    try:
        step('Creating %s' % target)
        existed = os.path.isdir(target)
        os.makedirs(target, exist_ok=True)
        if not os.path.isdir(target):
            raise OSError('The folder %s could not be created.' % target)
        made['dir'] = not existed
        log('Installing into %s' % target)

        step('Stopping any running panel')
        stopped = stop_running()
        if stopped:
            log('Closed a panel that was still running (%s).' % ', '.join(stopped))

        step('Copying the one program')
        # Single-exe installs: the panel carries the engine inside its own
        # bundle, so exactly one program lands in the folder. A sibling engine
        # from an older install is removed -- it was ours, and leaving it
        # would confuse which engine the panel runs.
        #
        # The folder gets that program and nothing else. The readme and the
        # icon are documentation and a build input, not the program, so they
        # are no longer copied in; the log, the cache and the heartbeat live
        # in the per-user folder the panel uses (see data_dir), and the marker
        # is hidden, so Explorer shows one file rather than six.
        payload_files = [(PANEL_EXE, payload(PANEL_EXE))]
        for name, source in payload_files:
            if not os.path.isfile(source):
                if name == PANEL_EXE:
                    raise OSError('The bundled %s is missing from this setup file.' % name)
                continue
            destination = os.path.join(target, name)
            if os.path.exists(destination) and \
                    os.path.samefile(source, destination):
                # Run from source with the install folder being the one the
                # program already sits in: copying a file onto itself is not a
                # copy, and shutil says so out loud.
                log('%s is already in place.' % name)
                made['files'].append(destination)
                continue
            shutil.copy2(source, destination)
            made['files'].append(destination)
        stale_engine = os.path.join(target, ENGINE_EXE)
        if os.path.isfile(stale_engine):
            try:
                os.remove(stale_engine)
                log('Removed the old separate engine; it now rides inside the panel.')
            except OSError as error:
                log('WARNING: could not remove the old engine file: %s' % error)
        log('Copied %s (%.0f MB).'
            % (PANEL_EXE, sum(os.path.getsize(os.path.join(target, name))
                              for name, _source in payload_files
                              if os.path.isfile(os.path.join(target, name)))
                / (1024 * 1024.0)))
        tidy_install_folder(target, log)
        tidy_legacy_install_folder(target, log)

        step('Opening the firewall')
        if options['firewall']:
            added, _failed = add_firewall_rules(log)
            made['rules'] = ['GameVIP DNS', 'GameVIP HTTP', 'GameVIP Panel'] if added else []
        else:
            log('Firewall left alone; the panel asks for the rules the first time the '
                'switch is flipped.')

        step('Writing the shortcuts')
        panel = os.path.join(target, PANEL_EXE)
        start_menu, desktop = shortcut_paths()
        if options['startmenu']:
            os.makedirs(os.path.dirname(start_menu), exist_ok=True)
            if make_shortcut(start_menu, panel, target, APP_NAME + ' - dashboard'):
                made['shortcuts'].append(start_menu)
                log('Start menu shortcut created.')
            else:
                log('WARNING: the Start menu shortcut could not be written.')
        if options['desktop']:
            if make_shortcut(desktop, panel, target, APP_NAME + ' - dashboard'):
                made['shortcuts'].append(desktop)
                log('Desktop shortcut created.')
            else:
                log('WARNING: the desktop shortcut could not be written.')

        step('Setting the logon start')
        if options['autostart']:
            if set_autostart(panel, log):
                made['task'] = True
            else:
                options['autostart'] = False
        else:
            clear_autostart(log)

        step('Recording the install')
        import hashlib

        def _digest(path):
            try:
                digest = hashlib.sha256()
                with open(path, 'rb') as handle:
                    for chunk in iter(lambda: handle.read(1048576), b''):
                        digest.update(chunk)
                return digest.hexdigest()[:16]
            except OSError:
                return ''

        marker_options = {key: options[key] for key in
                          ('desktop', 'startmenu', 'firewall', 'autostart')}
        marker_options['panel_digest'] = _digest(os.path.join(target, PANEL_EXE))
        marker_options['engine_digest'] = marker_options['panel_digest']
        record = write_marker(target, marker_options)
        if record is None:
            log('WARNING: the install record could not be written in %s, so '
                'this setup will not know what the install was made with.'
                % marker_path(target))
        else:
            if same_path(os.path.dirname(record), target):
                # Beside the program the record is hidden, so Explorer shows the
                # program alone. In the per-user folder there is nothing to hide
                # it from, and nothing of ours is left in the user's folder.
                hide(record)
            made['marker'] = True
            log('Install recorded in %s (one program, digest %s).'
                % (record, marker_options['panel_digest'] or '?'))
        return target
    except Exception:
        log('Install failed halfway; undoing what this run created.')
        rollback(log)
        raise


def uninstall(install_dir, log, progress, remove_dir=True, keep_shortcuts=False):
    """Take the product back out: processes, rules, shortcuts, files."""
    steps = 6
    done = 0

    def step(label):
        nonlocal done
        done += 1
        progress(done, steps, label)

    step('Stopping the panel and engine')
    stopped = stop_running()
    if stopped:
        log('Stopped %s.' % ', '.join(stopped))
    else:
        log('Nothing was running.')

    step('Removing the logon task')
    clear_autostart(log)

    step('Closing the firewall ports')
    remove_firewall_rules(log)

    step('Removing the shortcuts')
    if not keep_shortcuts:
        start_menu, desktop = shortcut_paths()
        links = [start_menu, desktop]
        for folder, old in ((os.path.dirname(start_menu), 'GameBaTo VIP Spoof.lnk'),
                            (os.path.dirname(desktop), 'GameBaTo VIP Spoof.lnk')):
            legacy_link = os.path.join(folder, old)
            if legacy_link not in links:
                links.append(legacy_link)
        for link in links:
            try:
                if os.path.isfile(link):
                    if shortcut_points_at(link, install_dir):
                        os.remove(link)
                        log('Removed %s.' % os.path.basename(link))
                    else:
                        log('Kept %s: it no longer points at this install.'
                            % os.path.basename(link))
            except OSError as error:
                log('WARNING: could not remove %s: %s' % (link, error))

    step('Removing the working files')
    if remove_dir:
        # The log, the cache and the heartbeat live in the per-user folder, not
        # in the install folder, so removing the program has to take that
        # folder too or it would outlive the product it belongs to.
        folder = data_dir()
        if os.path.isdir(folder):
            try:
                shutil.rmtree(folder)
                log('Removed %s.' % folder)
            except OSError as error:
                log('WARNING: could not remove %s: %s' % (folder, error))

    step('Deleting the installed files')
    if remove_dir and os.path.isdir(install_dir):
        # Only product files go: the panel, engine, docs, marker, logs, cache
        # and heartbeat. Anything else in the folder is the user's, and the
        # folder itself stays unless it ends up empty.
        for name in (PANEL_EXE, ENGINE_EXE) + LEGACY_PANEL_EXES + (README_FILE, ICON_FILE,
                     MARKER_FILE, LOG_FILE, 'panel.log', 'tap.log',
                     'engine_health.json', 'cache'):
            path = os.path.join(install_dir, name)
            try:
                if os.path.isdir(path) and name == 'cache':
                    shutil.rmtree(path)
                elif os.path.isfile(path):
                    os.remove(path)
            except OSError as error:
                log('WARNING: could not delete %s: %s' % (name, error))
        leftovers = []
        try:
            leftovers = os.listdir(install_dir)
        except OSError:
            pass
        if not leftovers:
            try:
                os.rmdir(install_dir)
                log('%s is gone.' % install_dir)
            except OSError:
                log('%s still holds files another program is using.' % install_dir)
        else:
            log('%s kept %d file(s) that are not part of this product.'
                % (install_dir, len(leftovers)))


class Wizard(tk.Tk):
    """The setup window: a checklist, a few choices, and a live install log."""

    def __init__(self, mode='install', options=None):
        super().__init__()
        # Hidden until first layout: kills the small-white-flash frame.
        try:
            self.withdraw()
        except tk.TclError:
            pass
        self.title('%s - Setup' % APP_NAME)
        self.configure(bg=C['bg'])
        self.resizable(False, False)
        self.mode = mode
        self.installed = existing_install()
        self.events = queue.Queue()
        self.log_lines = []
        self.running = False
        self.result_ok = None
        self.options = options or {}
        self.busy = False
        # Timer bookkeeping: every scheduled callback is remembered so the
        # window can cancel it on close (see _later/destroy).
        self._closing = False
        self._drain_job = None
        self._delayed_jobs = []
        self.dashboard_opened = False
        self._opened_at = 0.0
        self._set_icon()
        self._build_shell()
        self.show_step(0)
        self._drain_job = self.after(DRAIN_MS, self.drain)
        self.update_idletasks()
        try:
            self.deiconify()
        except tk.TclError:
            pass

    # -- window furniture -------------------------------------------------
    def _set_icon(self):
        icon = payload(ICON_FILE)
        if os.path.isfile(icon):
            try:
                self.iconbitmap(icon)
            except tk.TclError:
                pass
        logo = ASSETS.get('gamevip-logo.png')
        if logo is not None:
            try:
                self.iconphoto(True, logo)
            except tk.TclError:
                pass
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except (AttributeError, OSError):
            pass

    def _build_shell(self):
        # Reference proportions at 1536x1024: sidebar ~21% (~330px), content
        # the rest. Default geometry follows the same ratio; the stage
        # scrolls so the footer never clips on small displays or 200% scale.
        width, height = 1240, 900
        self.geometry('%dx%d+%d+%d' % (
            width, height,
            (self.winfo_screenwidth() - width) // 2,
            max(0, (self.winfo_screenheight() - height) // 2 - 20)))
        self.minsize(1024, 680)
        self.configure(bg=C['bg'])
        body = tk.Frame(self, bg=C['bg'])
        body.pack(fill='both', expand=True)
        self.sidebar = tk.Frame(body, bg=C['sidebar'], width=270)
        self.sidebar.pack(side='left', fill='y')
        self.sidebar.pack_propagate(False)
        self._build_sidebar_chrome()
        tk.Frame(body, bg=C['brand_dim'], width=1).pack(side='left', fill='y')
        right = tk.Frame(body, bg=C['bg'])
        right.pack(side='left', fill='both', expand=True)
        self.stage_canvas = tk.Canvas(right, bg=C['bg'], highlightthickness=0)
        self.scrollbar = tk.Scrollbar(right, orient='vertical',
                                        command=self.stage_canvas.yview,
                                        bg=C['row'], troughcolor=C['bg'],
                                        activebackground=C['brand_dim'],
                                        highlightthickness=0, bd=0, width=12)
        self.stage_canvas.configure(yscrollcommand=self._scroll_set)
        self.scrollbar.pack(side='right', fill='y')
        self.stage_canvas.pack(side='left', fill='both', expand=True)
        self.stage = tk.Frame(self.stage_canvas, bg=C['bg'])
        self.stage_window = self.stage_canvas.create_window(
            (0, 0), window=self.stage, anchor='nw')
        self.stage.bind('<Configure>', self._sync_scroll)
        self.stage_canvas.bind('<Configure>', self._sync_stage_width)
        self.bind_all('<MouseWheel>', self._scroll_stage, add='+')

        footer = tk.Frame(self, bg=C['bg'], height=64)
        footer.pack(fill='x', side='bottom')
        footer.pack_propagate(False)
        tk.Frame(self, bg=C['card_edge'], height=1).pack(fill='x', side='bottom')
        # Buttons pack first so a long status line can never shove them off.
        self.buttons = tk.Frame(footer, bg=C['bg'])
        self.buttons.pack(side='right', padx=20)
        self.back_btn = self._button(self.buttons, 'Back', self.go_back, kind='ghost')
        self.next_btn = self._button(self.buttons, 'Continue', self.go_next, kind='brand')
        chevron = self.icon('chevron-right.png')
        if chevron is not None:
            self.next_btn.configure(image=chevron, compound='right')
            self._chevron = chevron
        self.back_btn.pack(side='left', padx=(0, 10))
        self.next_btn.pack(side='left')
        info_icon = self.icon('info.png')
        if info_icon is not None:
            self.hint_icon = tk.Label(footer, image=info_icon, bg=C['bg'],
                                      bd=0, highlightthickness=0)
            self._info_icon = info_icon
        else:
            self.hint_icon = tk.Label(footer, text='\u24d8', bg=C['bg'],
                                      fg=C['muted'], font=('Segoe UI', 13))
        self.hint_icon.pack(side='left', padx=(20, 6))
        self.hint = tk.Label(footer, text='', bg=C['bg'], fg=C['muted'],
                             font=('Segoe UI', 9), justify='left', anchor='w',
                             wraplength=640)
        self.hint.pack(side='left', fill='x', expand=True)

    def _scroll_set(self, first, last):
        """Show the scrollbar only while content actually overflows."""
        try:
            self.scrollbar.set(first, last)
            needs = float(first) > 0.0 or float(last) < 1.0
            if needs and not self.scrollbar.winfo_ismapped():
                self.scrollbar.pack(side='right', fill='y')
            elif not needs and self.scrollbar.winfo_ismapped():
                self.scrollbar.pack_forget()
        except (tk.TclError, ValueError):
            pass

    def _sync_scroll(self, _event=None):
        self.stage_canvas.configure(scrollregion=self.stage_canvas.bbox('all'))

    def _sync_stage_width(self, event=None):
        width = event.width if event is not None else self.stage_canvas.winfo_width()
        self.stage_canvas.itemconfigure(self.stage_window, width=width)

    def _scroll_stage(self, event=None):
        try:
            self.stage_canvas.yview_scroll(-1 if event.delta > 0 else 1, 'units')
        except (tk.TclError, AttributeError):
            pass

    # -- timers ------------------------------------------------------------
    def _later(self, delay_ms, callback):
        """A one-shot UI callback that dies with the window.

        A bare ``after`` outlives the widget that scheduled it: Tk deletes
        the Python command on destroy, the timer still fires, and stderr
        fills with 'invalid command name ... ("after" script)'. Remembering
        the job id lets destroy() cancel it first.
        """
        job = None

        def run():
            if job in self._delayed_jobs:
                self._delayed_jobs.remove(job)
            if not self._closing:
                callback()

        job = self.after(delay_ms, run)
        self._delayed_jobs.append(job)
        return job

    def destroy(self):
        """Cancel the timers first, then take the window down."""
        if self._closing:
            return
        self._closing = True
        jobs = [self._drain_job] + list(self._delayed_jobs)
        self._drain_job = None
        self._delayed_jobs = []
        for job in jobs:
            if job is None:
                continue
            try:
                self.after_cancel(job)
            except tk.TclError:
                pass
        try:
            self.unbind_all('<MouseWheel>')
        except tk.TclError:
            pass
        super().destroy()

    def _build_sidebar_chrome(self):
        # Approved sidebar: static brand lockup (emblem + wordmark + tagline
        # in one crop -- never duplicate those words with widgets), steps,
        # text-free decoration fragment, version footer.
        lockup = ASSETS.get('branding', 'sidebar-brand-lockup.png')
        if lockup is not None:
            while lockup.width() > 262 and lockup.width() > 1:
                try:
                    lockup = lockup.subsample(2, 2)
                except tk.TclError:
                    break
            art = tk.Label(self.sidebar, image=lockup,
                           bg=C['sidebar'], bd=0, highlightthickness=0)
            art.pack(padx=4, pady=(14, 2))
            self.logo_images = [lockup]
        else:
            self.logo_images = []
            tk.Label(self.sidebar, text='Game', bg=C['sidebar'], fg='#ffffff',
                     font=('Segoe UI Semibold', 34)).pack()
            tk.Label(self.sidebar, text='VIP', bg=C['sidebar'],
                     fg=C['brand_hot'],
                     font=('Segoe UI Semibold', 34)).pack()
            tk.Label(self.sidebar, text='PS4 PREMIUM SESSION', bg=C['sidebar'],
                     fg=C['muted'], font=('Segoe UI', 9)).pack(pady=(6, 0))
            tk.Label(self.sidebar, text='OVER YOUR OWN NETWORK',
                     bg=C['sidebar'],
                     fg=C['faint'], font=('Segoe UI', 8)).pack()
        self.step_list = tk.Frame(self.sidebar, bg=C['sidebar'])
        self.step_list.pack(fill='x', padx=18, pady=(18, 0))
        # The sidebar used to end in the smoky red decoration art from the
        # reference screenshot. It is not painted any more: it carried no
        # information, and a red haze hanging in the corner of a window that is
        # otherwise green-and-grey read as a stray picture rather than part of
        # the product. What is left is the footer, packed bottom-up so the
        # version sits at the bottom of the sidebar and the line above it.
        tk.Label(self.sidebar, text='Version %s' % VERSION, bg=C['sidebar'],
                 fg=C['muted'], font=('Segoe UI', 9)).pack(side='bottom',
                                                           pady=(0, 14))
        tk.Label(self.sidebar, text='PRIVATE \u2022 SECURE \u2022 YOUR NETWORK',
                 bg=C['sidebar'], fg=C['faint'],
                 font=('Segoe UI', 7)).pack(side='bottom', pady=(0, 6))

    def _button(self, parent, text, command, kind='main', width=13):
        colours = {'main': (C['accent'], '#04150d', C['accent_dim']),
                   'brand': (C['brand'], '#ffffff', C['brand_hot']),
                   'ghost': (C['row'], C['ink'], C['card_edge']),
                   'danger': (C['bad'], '#1a0505', '#a33')}[kind]
        if kind == 'brand':
            # Chevron image rides beside the text; width 0 lets Tk size to
            # the real content instead of a stale character count.
            width = 0
        button = tk.Button(parent, text=text, command=command, width=width,
                           bg=colours[0], fg=colours[1], activebackground=colours[2],
                           activeforeground=colours[1], relief='flat', bd=0,
                           font=('Segoe UI Semibold', 11), cursor='hand2',
                           highlightthickness=0, padx=10, pady=9,
                           disabledforeground=C['faint'])
        return button

    # -- step scaffolding -------------------------------------------------
    def clear_stage(self):
        for child in self.stage.winfo_children():
            child.destroy()

    def clear_sidebar(self):
        for child in self.step_list.winfo_children():
            child.destroy()

    def show_step(self, index):
        self.step = index
        self.clear_stage()
        self.clear_sidebar()
        builders = {0: self.step_welcome, 1: self.step_options,
                    2: self.step_progress, 3: self.step_finish}
        builders[index]()
        self.stage_canvas.yview_moveto(0)

    def sidebar_rows(self, rows, active):
        for number, label in rows:
            done = number < active
            current = number == active
            if current:
                row = tk.Frame(self.step_list, bg=C['brand'],
                               padx=1, pady=1)
                inner = tk.Frame(row, bg='#2a0d0f')
            else:
                row = tk.Frame(self.step_list, bg=C['sidebar'])
                inner = tk.Frame(row, bg=C['sidebar'])
            row.pack(fill='x', pady=4)
            inner.pack(fill='x')
            badge = tk.Canvas(inner, width=34, height=34,
                              bg='#2a0d0f' if current else C['sidebar'],
                              highlightthickness=0)
            badge.pack(side='left', padx=(12, 10), pady=8)
            if current:
                badge.create_oval(2, 2, 32, 32, outline=C['brand_hot'],
                                  width=2, fill=C['brand'])
                badge.create_text(17, 17, text=str(number + 1), fill='#ffffff',
                                  font=('Segoe UI Semibold', 13))
            elif done:
                badge.create_oval(2, 2, 32, 32, outline=C['ok'],
                                  width=2, fill=C['ok'])
                badge.create_text(17, 17, text='\u2713', fill='#06130c',
                                  font=('Segoe UI Semibold', 13))
            else:
                badge.create_oval(2, 2, 32, 32, outline=C['faint'], width=2)
                badge.create_text(17, 17, text=str(number + 1), fill=C['muted'],
                                  font=('Segoe UI', 12))
            tk.Label(inner, text=label,
                     bg='#2a0d0f' if current else C['sidebar'],
                     fg='#ffffff' if (current or done) else C['muted'],
                     font=('Segoe UI Semibold', 14) if current else ('Segoe UI', 13)).pack(side='left')

    def title_block(self, title, subtitle):
        self.hero(title, subtitle)

    def hero(self, title, subtitle):
        """Reference hero: red caps kicker, raster wordmark, tagline, art.

        The wordmark is the exact branding crop (never a guessed font). The
        header art is the preferred combined file (controller + slogan with
        the paragraph cleanly repaired); the paragraph itself stays real
        text below. Non-welcome pages pass their own title and skip the art.
        """
        top = tk.Frame(self.stage, bg=C['bg'])
        top.pack(fill='x', padx=34, pady=(18, 0))
        left = tk.Frame(top, bg=C['bg'])
        left.pack(side='left', fill='x', expand=True)
        tk.Label(left, text='WELCOME TO', bg=C['bg'], fg=C['brand_hot'],
                 font=('Segoe UI Semibold', 12)).pack(anchor='w')
        wordmark = ASSETS.get('branding', 'hero-wordmark.png')
        if wordmark is not None:
            art = tk.Label(left, image=wordmark, bg=C['bg'], bd=0,
                           highlightthickness=0)
            art.pack(anchor='w', pady=(2, 4))
        else:
            fallback = tk.Frame(left, bg=C['bg'])
            fallback.pack(anchor='w')
            tk.Label(fallback, text='Game', bg=C['bg'], fg='#ffffff',
                     font=('Segoe UI Semibold', 44)).pack(side='left')
            tk.Label(fallback, text='VIP', bg=C['bg'], fg=C['brand_hot'],
                     font=('Segoe UI Semibold', 44)).pack(side='left')
        tk.Label(left, text=APP_TAGLINE, bg=C['bg'], fg=C['muted'],
                 font=('Segoe UI', 12)).pack(anchor='w', pady=(2, 6))
        tk.Label(self.stage, text=subtitle, bg=C['bg'], fg=C['muted'],
                 wraplength=760, justify='left',
                 font=('Segoe UI', 11)).pack(anchor='w', padx=34, pady=(0, 8))

    def hero_with_art(self, subtitle):
        """Welcome hero with the controller artwork docked right."""
        top = tk.Frame(self.stage, bg=C['bg'])
        top.pack(fill='x', padx=34, pady=(18, 0))
        left = tk.Frame(top, bg=C['bg'])
        left.pack(side='left', fill='x', expand=True)
        tk.Label(left, text='WELCOME TO', bg=C['bg'], fg=C['brand_hot'],
                 font=('Segoe UI Semibold', 12)).pack(anchor='w')
        wordmark = ASSETS.get('branding', 'hero-wordmark.png')
        if wordmark is not None:
            tk.Label(left, image=wordmark, bg=C['bg'], bd=0,
                     highlightthickness=0).pack(anchor='w', pady=(2, 6))
        else:
            tk.Label(left, text='GameVIP', bg=C['bg'], fg='#ffffff',
                     font=('Segoe UI Semibold', 44)).pack(anchor='w')
        tk.Label(left, text=APP_TAGLINE, bg=C['bg'], fg=C['muted'],
                 font=('Segoe UI', 12)).pack(anchor='w', pady=(2, 6))
        art = ASSETS.get('hero-artwork.png')
        if art is not None:
            try:
                while art.width() > 460:
                    art = art.subsample(2, 2)
            except tk.TclError:
                pass
            # Retained: a PhotoImage held only by a local dies with the
            # function and the label goes blank.
            self._hero_refs = getattr(self, '_hero_refs', [])
            self._hero_refs.append(art)
            tk.Label(top, image=art, bg=C['bg'], bd=0,
                     highlightthickness=0).pack(side='right', anchor='n')
        tk.Label(self.stage, text=subtitle, bg=C['bg'], fg=C['muted'],
                 wraplength=760, justify='left',
                 font=('Segoe UI', 11)).pack(anchor='w', padx=34, pady=(0, 12))

    CHECK_ICONS = {'windows': 'windows.png', 'shield': 'shield.png',
                   'gear': 'gear.png', 'code': 'code.png',
                   'port': 'network.png', 'disk': 'disk.png',
                   'folder': 'folder.png', 'warn': 'panel-port.png'}

    def icon(self, name):
        """Keyed-transparent icon, falling back to the raw crop."""
        image = ASSETS.get('icons_t', name)
        return image if image is not None else ASSETS.get('icons', name)

    def check_icon(self, label, ok):
        lowered = label.lower()
        if 'windows' in lowered:
            key = 'windows'
        elif 'administrator' in lowered:
            key = 'shield'
        elif 'runtime' in lowered or 'system' in lowered:
            key = 'gear'
        elif 'python' in lowered:
            key = 'code'
        elif 'port 80' in lowered:
            key = 'port'
        elif 'panel port' in lowered:
            key = 'warn' if not ok else 'port'
        elif 'room' in lowered:
            key = 'disk'
        else:
            key = 'shield'
        return self.icon(self.CHECK_ICONS[key])

    # -- page 1: welcome and requirements ---------------------------------
    def step_welcome(self):
        uninstalling = self.mode == 'uninstall'
        if uninstalling:
            self.sidebar_rows([(0, 'Remove'), (1, 'Progress'), (2, 'Done')], self.step)
            self.title_block('Remove %s' % APP_NAME,
                             'The panel, the engine, its shortcuts and its firewall rules '
                             'are taken back out. Store files it cached go with it.')
        else:
            self.sidebar_rows([(0, 'Welcome'), (1, 'Options'), (2, 'Install'), (3, 'Done')],
                              self.step)
            self.hero_with_art('This installs GameVIP as one ready-to-run program - '
                               'nothing else to download, no Python to install. Below '
                               'is what the setup checked on this PC.')
        self.check_frame = tk.Frame(self.stage, bg=C['bg'])
        self.check_frame.pack(fill='x', padx=34, pady=(4, 2))
        self.draw_checks()
        if uninstalling:
            self.hint.configure(text='Install folder: %s' % (self.installed or default_install_dir()))
            self.back_btn.configure(state='disabled')
            self.next_btn.configure(text='Remove', bg=C['bad'], fg='#1a0505',
                                    activebackground='#a33', command=self.go_next)
            return
        location = self.installed or self.options.get('dir') or default_install_dir()
        card = tk.Frame(self.stage, bg=C['row'],
                        highlightbackground=C['card_edge'],
                        highlightthickness=1)
        card.pack(fill='x', padx=34, pady=(2, 2), ipady=6)
        folder_icon = self.icon('folder.png')
        if folder_icon is not None:
            tk.Label(card, image=folder_icon, bg=C['row'], bd=0,
                     highlightthickness=0).pack(side='left', padx=(12, 4))
        else:
            tk.Label(card, text='\u25a3', bg=C['row'], fg=C['ink'],
                     font=('Segoe UI Semibold', 17), width=3).pack(side='left', padx=(8, 2))
        text = tk.Frame(card, bg=C['row'])
        text.pack(side='left', fill='x', expand=True)
        if self.installed:
            tk.Label(text, text='Already installed in %s' % self.installed,
                     bg=C['row'], fg=C['ink'],
                     font=('Segoe UI Semibold', 12), wraplength=640,
                     justify='left').pack(anchor='w')
        else:
            tk.Label(text, text='Installation location', bg=C['row'],
                     fg=C['ink'],
                     font=('Segoe UI Semibold', 12)).pack(anchor='w')
            tk.Label(text, text=location, bg=C['row'], fg=C['muted'],
                     font=('Consolas', 10), wraplength=640,
                     justify='left').pack(anchor='w')
        tk.Label(text, text='Installing again replaces those files and keeps your '
                            'shortcuts and rules.', bg=C['row'], fg=C['muted'],
                 font=('Segoe UI', 10), wraplength=640,
                 justify='left').pack(anchor='w')
        self.hint.configure(text='Checked now: %s' % self._check_summary())
        self.back_btn.configure(state='disabled')
        self.next_btn.configure(text='Continue', bg=C['brand'],
                                fg='#ffffff', activebackground=C['brand_hot'],
                                command=self.go_next, state='normal')

    def _check_summary(self):
        checks = requirements(self.options.get('dir') or default_install_dir())
        bad = [label for label, ok, _detail, _fix in checks
               if not ok and not label.lower().startswith('port')]
        if not bad:
            return 'everything this setup needs is in place.'
        return 'the setup will continue without: %s.' % ', '.join(bad)

    def run_fix(self, fix):
        """Repair a failed check, then redraw the list in place."""
        if fix == 'elevate':
            if not relaunch_elevated():
                self.hint.configure(text='Could not raise the administrator window.')
        elif fix == 'vcredist':
            import webbrowser
            try:
                webbrowser.open('https://aka.ms/vs/17/release/vc_redist.x64.exe')
                self.hint.configure(text='Opened the Microsoft VC++ download - install it, then press Continue.')
            except Exception as error:                      # shown, never swallowed
                self.hint.configure(text='Could not open the download: %s' % error)
        elif fix == 'free-port':
            stopped = stop_running()
            self.hint.configure(
                text=('Closed %s; rechecking.' % ', '.join(stopped)) if stopped
                else 'Whatever holds the port is not ours - close IIS, Skype or the other program, then continue.')
        self.draw_checks()

    def draw_checks(self):
        for child in self.check_frame.winfo_children():
            child.destroy()
        checks = requirements(self.options.get('dir') or default_install_dir())
        for label, ok, detail, fix in checks:
            icon_image = self.check_icon(label, ok)
            row = tk.Frame(self.check_frame, bg=C['row'],
                           highlightbackground=C['card_edge'],
                           highlightthickness=1)
            row.pack(fill='x', pady=2, ipady=4)
            if icon_image is not None:
                icon = tk.Label(row, image=icon_image, bg=C['row'], bd=0,
                                highlightthickness=0)
            else:
                icon = tk.Label(row, text='\u25a0', bg=C['row'],
                                fg=C['ok'] if ok else C['warn'],
                                font=('Segoe UI Semibold', 17), width=3)
            icon.pack(side='left', padx=(12, 4))
            text = tk.Frame(row, bg=C['row'])
            text.pack(side='left', fill='x', expand=True)
            tk.Label(text, text=label, bg=C['row'], fg=C['ink'],
                     font=('Segoe UI Semibold', 12)).pack(anchor='w')
            tk.Label(text, text=detail, bg=C['row'], fg=C['muted'],
                     font=('Segoe UI', 10), wraplength=560,
                     justify='left').pack(anchor='w')
            status = tk.Frame(row, bg=C['row'])
            status.pack(side='right', padx=14)
            badge = self.icon('check.png' if ok else 'warning.png')
            if badge is not None:
                tk.Label(status, image=badge, bg=C['row'], bd=0,
                         highlightthickness=0).pack(side='left', padx=(0, 8))
            if ok:
                tk.Label(status, text='OK', bg=C['row'], fg=C['ok'],
                         font=('Segoe UI', 11)).pack(side='left')
            else:
                if fix:
                    names = {'elevate': 'Relaunch as admin',
                             'vcredist': 'Get the runtime',
                             'free-port': 'Fix it'}
                    fix_btn = tk.Button(status, text=names.get(fix, 'Fix it'),
                                        command=lambda fix=fix: self.run_fix(fix),
                                        bg=C['row'], fg=C['warn'],
                                        activebackground=C['row'],
                                        activeforeground=C['warn'],
                                        relief='flat', bd=0,
                                        font=('Segoe UI', 11), cursor='hand2',
                                        highlightthickness=0, padx=4, pady=2)
                    fix_btn.pack(side='left')
                else:
                    tk.Label(status, text='!', bg=C['row'], fg=C['warn'],
                             font=('Segoe UI', 11)).pack(side='left')

    def recheck(self):
        self.draw_checks()
        self.hint.configure(text='Checked now: %s' % self._check_summary())

    # -- page 2: options ---------------------------------------------------
    def step_options(self):
        base = self.installed or default_install_dir()
        self.sidebar_rows([(0, 'Welcome'), (1, 'Options'), (2, 'Install'), (3, 'Done')], self.step)
        self.title_block('Where and how',
                         'The defaults are what most people want: the program lands in '
                         'this folder, beside the setup, with a Start menu entry and '
                         'the firewall opened for the PS4.')
        form = tk.Frame(self.stage, bg=C['bg'])
        form.pack(fill='x', padx=34, pady=(16, 0))
        tk.Label(form, text='INSTALL FOLDER', bg=C['bg'], fg=C['muted'],
                 font=('Segoe UI', 8)).pack(anchor='w')
        folder = tk.Frame(form, bg=C['bg'])
        folder.pack(fill='x', pady=(4, 12))
        self.dir_var = tk.StringVar(value=self.options.get('dir') or base)
        entry = tk.Entry(folder, textvariable=self.dir_var, bg=C['row'], fg=C['ink'],
                         insertbackground=C['ink'], relief='flat',
                         font=('Consolas', 10), width=44,
                         highlightbackground=C['card_edge'],
                         highlightthickness=1)
        entry.pack(side='left', ipady=8, padx=(0, 8))
        self._button(folder, 'Browse', self.browse, kind='ghost', width=9).pack(side='left')

        self.option_vars = {}
        choices = [('firewall', 'Open the firewall ports (53, 80, 8899)',
                    'Lets the PS4 reach this PC. Needs the administrator window.'),
                   ('startmenu', 'Add a Start menu shortcut',
                    'Start > %s.' % APP_NAME),
                   ('desktop', 'Add a desktop shortcut',
                    'Click it and the dashboard opens in your browser.'),
                   ('autostart', 'Start the panel with Windows',
                    'A logon task, so the PS4 always finds the PC ready.'),
                   ('launch', 'Open the dashboard when the setup finishes',
                    'Off by default: tick it to open the dashboard as soon as '
                    'the install is done.')]
        defaults = {'firewall': True, 'startmenu': True, 'desktop': True,
                    'autostart': False, 'launch': False}
        marker = read_marker(base) if self.installed else {}
        for key, label, detail in choices:
            if key in marker:
                defaults[key] = marker[key] == '1'
            var = tk.BooleanVar(value=self.options.get(key, defaults[key]))
            self.option_vars[key] = var
            row = tk.Frame(form, bg=C['row'],
                           highlightbackground=C['card_edge'],
                           highlightthickness=1)
            row.pack(fill='x', pady=3, ipady=6)
            box = tk.Checkbutton(row, text=label, variable=var, bg=C['row'], fg=C['ink'],
                                 activebackground=C['row'], activeforeground=C['brand_hot'],
                                 selectcolor=C['brand'], font=('Segoe UI Semibold', 11),
                                 highlightthickness=0, bd=0, anchor='w')
            box.pack(anchor='w', padx=(10, 0))
            tk.Label(row, text='     ' + detail, bg=C['row'], fg=C['muted'],
                     font=('Segoe UI', 10)).pack(anchor='w', padx=(10, 0))
        self.hint.configure(text='Nothing is written outside the folder above except the '
                                 'shortcuts, the firewall rules, the logon task and the '
                                 'install record in %%LOCALAPPDATA%%\\%s.' % DATA_FOLDER)
        self.back_btn.configure(state='normal', command=self.go_back)
        self.next_btn.configure(text='Install', bg=C['brand'], fg='#ffffff',
                                activebackground=C['brand_hot'], command=self.go_next,
                                state='normal')

    def browse(self):
        chosen = filedialog.askdirectory(title='Where should %s go?' % APP_NAME,
                                         initialdir=self.dir_var.get() or app_dir())
        if chosen:
            self.dir_var.set(os.path.normpath(chosen))

    # -- page 3: progress --------------------------------------------------
    def step_progress(self):
        removing = self.mode == 'uninstall'
        if removing:
            self.sidebar_rows([(0, 'Remove'), (1, 'Progress'), (2, 'Done')], 1)
        else:
            self.sidebar_rows([(0, 'Welcome'), (1, 'Options'), (2, 'Install'),
                               (3, 'Done')], 2)
        self.title_block('Removing' if removing else 'Installing',
                         'Every step is listed below as it happens. This window can be '
                         'left alone until it finishes.')
        wrap = tk.Frame(self.stage, bg=C['bg'])
        wrap.pack(fill='both', expand=True, padx=28, pady=(14, 16))
        style = ttk.Style(self)
        try:
            style.theme_use('clam')
        except tk.TclError:
            pass
        style.configure('gbt.Horizontal.TProgressbar', troughcolor=C['row'],
                        background=C['brand'], bordercolor=C['row'],
                        lightcolor=C['brand_hot'], darkcolor=C['brand'], thickness=12)
        self.bar = ttk.Progressbar(wrap, style='gbt.Horizontal.TProgressbar',
                                   orient='horizontal', mode='determinate', maximum=1.0)
        self.bar.pack(fill='x')
        self.progress_label = tk.Label(wrap, text='Starting...', bg=C['bg'], fg=C['muted'],
                                       font=('Segoe UI', 9))
        self.progress_label.pack(anchor='w', pady=(4, 8))
        self.log_box = tk.Text(wrap, height=11, bg='#0b0d12', fg=C['ink'], relief='flat',
                               font=('Consolas', 9), wrap='word', highlightthickness=0,
                               insertbackground=C['ink'])
        self.log_box.pack(fill='both', expand=True)
        self.log_box.configure(state='disabled')
        for line in self.log_lines:
            self.append(line)
        self.back_btn.configure(state='disabled')
        self.next_btn.configure(state='disabled', text='Working...')
        self.hint.configure(text='The setup never touches your own files outside the '
                                 'install folder.')
        self.busy = True
        self.progress_shown_at = time.monotonic()
        self.worker_options = self._collect_options()
        threading.Thread(target=self._work, daemon=True).start()

    def append(self, line):
        self.log_box.configure(state='normal')
        self.log_box.insert('end', line + '\n')
        self.log_box.see('end')
        self.log_box.configure(state='disabled')

    def _collect_options(self):
        """Snapshot the pages' choices -- on the UI thread, before any work.

        Tk variables cannot be read from the worker thread, and the removal
        walkthrough never builds the folder box at all, so both are read here
        while the widgets still belong to the thread that made them.
        """
        options = dict(self.options)
        folder = getattr(self, 'dir_var', None)
        typed = folder.get().strip() if folder is not None else ''
        options['dir'] = typed or options.get('dir') or default_install_dir()
        for key, var in getattr(self, 'option_vars', {}).items():
            options[key] = bool(var.get())
        return options

    def _work(self):
        """Run the install or the removal on a worker thread.

        The choices were taken by the UI thread (see _collect_options), so
        nothing in here touches a widget. The whole body is guarded: a failure
        has to report itself, because a thread that dies silently leaves the
        window sitting on 'Working...' with no way forward.
        """
        options = dict(getattr(self, 'worker_options', None) or self.options)

        def log(line):
            self.events.put(('log', line))

        def progress(done, total, label):
            self.events.put(('progress', (done, float(total), label)))

        try:
            if self.mode == 'uninstall':
                uninstall(self.installed or options['dir'], log, progress)
                self.events.put(('done', (True, 'Removed.', options)))
            else:
                install(options, log, progress)
                if options.get('launch'):
                    # Only when the person running the setup ticked the box.
                    # Open the page here, not a bare process start: the panel
                    # itself never opens a browser, so a log line alone would
                    # promise an open dashboard that never appears.
                    options['dashboard_opened'] = launch_panel_with_page(
                        os.path.join(options['dir'], PANEL_EXE), log=log)
                self.events.put(('done', (True, 'Installed.', options)))
        except Exception as error:                      # shown, never swallowed
            self.events.put(('log', 'ERROR: %s' % error))
            self.events.put(('done', (False, str(error), options)))

    def drain(self):
        """Move worker-thread events into the widgets, on the UI thread.

        A timer still pending is cancelled first, so this stays safe to call
        directly as well as from the timer that normally drives it.
        """
        if self._drain_job is not None:
            try:
                self.after_cancel(self._drain_job)
            except tk.TclError:
                pass
            self._drain_job = None
        if self._closing:
            return
        try:
            while True:
                kind, payload_value = self.events.get_nowait()
                if kind == 'log':
                    self.log_lines.append(payload_value)
                    if self.step == 2 and hasattr(self, 'log_box'):
                        self.append(payload_value)
                elif kind == 'progress':
                    done, total, label = payload_value
                    if hasattr(self, 'bar'):
                        self.bar['value'] = done / total
                        self.progress_label.configure(text=label)
                elif kind == 'done':
                    ok, message, options = payload_value
                    self.running = False
                    self.busy = False
                    self.result_ok = ok
                    self.options = options
                    self.dashboard_opened = bool(options.get('dashboard_opened'))
                    if ok:
                        if self.mode == 'uninstall':
                            self.installed = None
                        else:
                            self.installed = options['dir']
                        # A fast install would otherwise flash the log past; give
                        # the working page a moment so the steps can be read.
                        shown = getattr(self, 'progress_shown_at', time.monotonic())
                        remaining = (MIN_PROGRESS_MS / 1000.0) - (time.monotonic() - shown)
                        delay = max(0, int(remaining * 1000))
                        self._later(delay, lambda: self.show_step(3))
                    else:
                        self.hint.configure(text='The setup stopped: %s' % message)
                        self.back_btn.configure(state='normal', command=self.go_back)
                        self.next_btn.configure(state='normal', text='Close',
                                                bg=C['card'], fg=C['ink'],
                                                activebackground=C['line'],
                                                command=self.destroy)
        except queue.Empty:
            pass
        if not self._closing:
            self._drain_job = self.after(DRAIN_MS, self.drain)

    # -- page 4: done ------------------------------------------------------
    def step_finish(self):
        removing = self.mode == 'uninstall'
        rows = [(0, 'Remove'), (1, 'Progress'), (2, 'Done')] if removing else \
            [(0, 'Welcome'), (1, 'Options'), (2, 'Install'), (3, 'Done')]
        self.sidebar_rows(rows, len(rows) - 1)
        if removing:
            self.title_block('Removed',
                             '%s is off this PC. Its folder, shortcuts, firewall rules '
                             'and logon task are all gone.' % APP_NAME)
        else:
            self.title_block('Ready',
                             'Installed in %s. Start the dashboard from the shortcut, flip '
                             'the switch, then point the PS4\'s DNS at this PC.'
                             % self.installed)
        card = tk.Frame(self.stage, bg=C['row'],
                        highlightbackground=C['card_edge'],
                        highlightthickness=1)
        card.pack(fill='x', padx=34, pady=(4, 0), ipady=12)
        steps = [('1', 'Open the dashboard from the shortcut, or the Start menu.'),
                 ('2', 'Flip the switch - the panel opens the ports and starts the engine.'),
                 ('3', 'On the PS4: Settings > Network > Set up connection > manual DNS, '
                       'primary = this PC\'s address (the dashboard tile shows it), '
                       'secondary = 1.1.1.1 - never this PC in both fields.'),
                 ('4', 'Start the store app: the premium session is answered locally.'),
                 ('5', 'When you flip the switch OFF, set the PS4 DNS back to Auto.')]
        firewall_off = read_marker(self.installed or default_install_dir()).get('firewall') == '0'
        if firewall_off:
            steps.insert(0, ('!', 'Firewall was skipped: the PS4 cannot reach this PC until '
                                 'you press Allow through on the dashboard and approve '
                                 'the Windows prompt.'))
        if removing:
            steps = [('1', 'Anything the panel cached went with its folder.'),
                     ('2', 'Re-run this setup whenever you want it back.')]
        for number, text in steps:
            row = tk.Frame(card, bg=C['row'])
            row.pack(fill='x', padx=16, pady=3)
            tk.Label(row, text=number, bg=C['row'], fg=C['brand_hot'], width=2,
                     font=('Segoe UI Semibold', 11)).pack(side='left')
            tk.Label(row, text=text, bg=C['row'], fg=C['ink'], wraplength=640,
                     justify='left', font=('Segoe UI', 10)).pack(side='left')
        if removing:
            self.hint.configure(text='Nothing of yours was touched.')
        elif self.dashboard_opened:
            self.hint.configure(text='The dashboard is already open in your browser.')
        else:
            self.hint.configure(text='Install recorded: this setup can remove it '
                                     'again later.')
        # The working pages disable both buttons, so the last one has to be
        # brought back or the window would end with nothing clickable. The
        # 'launch' toggle is off unless it was ticked, so the button is the
        # normal way the page gets opened: one click, on purpose. It only
        # reads 'Finish' when the page was already opened for the user.
        self.back_btn.configure(state='disabled')
        self.next_btn.configure(
            text='Open the dashboard' if not (removing or self.dashboard_opened)
            else 'Finish',
            command=self.destroy if (removing or self.dashboard_opened)
            else self.finish_open,
            state='normal', bg=C['brand'], fg='#ffffff',
            activebackground=C['brand_hot'])
        self.next_btn.focus_set()

    def finish_open(self):
        """Start the panel and open its page without freezing the window."""
        if self.mode == 'uninstall':
            self.destroy()
            return
        target = self.installed or default_install_dir()
        self.next_btn.configure(state='disabled', text='Opening...')
        self.hint.configure(text='Starting the dashboard...')
        self._opened_at = time.monotonic()
        if not launch_panel(os.path.join(target, PANEL_EXE)):
            self.hint.configure(text='%s could not be started. Use the desktop or '
                                     'Start menu shortcut instead.' % PANEL_EXE)
            self.next_btn.configure(state='normal', text='Finish', command=self.destroy)
            return
        self._wait_for_panel()

    def _wait_for_panel(self):
        """Poll for the panel's page; the window stays live while waiting."""
        if self._closing:
            return
        if port_state(PANEL_PORT) == 'open':
            open_dashboard(PANEL_PORT)
            self.destroy()
            return
        if time.monotonic() - self._opened_at > PANEL_OPEN_TIMEOUT:
            # Started but silent: say so instead of leaving the button dead.
            self.hint.configure(text='%s is still starting. The shortcut opens the '
                                     'dashboard once it is up.' % PANEL_EXE)
            self.next_btn.configure(state='normal', text='Finish', command=self.destroy)
            return
        self._later(250, self._wait_for_panel)

    # -- navigation --------------------------------------------------------
    def go_back(self):
        if self.busy:
            return
        if self.step == 1:
            self.show_step(0)

    def go_next(self):
        if self.step == 0:
            if self.mode == 'uninstall':
                if self.installed is None:
                    self.installed = default_install_dir()
                self.show_step(2)
                return
            self.show_step(1)
            return
        if self.step == 1:
            self.show_step(2)
            return


def parse_arguments(argv):
    """Read the (few) command line switches; unknown ones are ignored."""
    options = {'desktop': True, 'startmenu': True, 'firewall': True,
               'autostart': False, 'launch': False, 'dir': default_install_dir()}
    mode = 'uninstall' if '--uninstall' in argv else 'install'
    for argument in argv:
        if argument.startswith('--dir='):
            options['dir'] = os.path.normpath(argument.split('=', 1)[1])
        elif argument == '--desktop':
            options['desktop'] = True
        elif argument == '--no-desktop':
            options['desktop'] = False
        elif argument == '--no-startmenu':
            options['startmenu'] = False
        elif argument == '--no-firewall':
            options['firewall'] = False
        elif argument == '--autostart':
            options['autostart'] = True
        elif argument == '--no-autostart':
            options['autostart'] = False
        elif argument == '--launch':
            options['launch'] = True
        elif argument == '--no-launch':
            options['launch'] = False
    return mode, options


def silent_run(mode, options):
    """Headless path, for scripted installs and for testing the same code."""
    def say(line):
        # A windowed build has no console at all, so there may be no stream to
        # write to; the work still happens, which is what a scripted run wants.
        if sys.stdout is not None:
            print(line, flush=True)

    def log(line):
        say(line)

    def progress(done, total, label):
        say('[%d/%d] %s' % (done, total, label))

    if mode == 'uninstall':
        target = existing_install() or options['dir']
        uninstall(target, log, progress)
        return 0
    try:
        install(options, log, progress)
    except Exception as error:                          # reported, never swallowed
        say('ERROR: %s' % error)
        return 1
    if options.get('launch'):
        # Only an explicit --launch opens a page; a scripted install otherwise
        # leaves the browser alone and prints what it did instead.
        launch_panel_with_page(os.path.join(options['dir'], PANEL_EXE), log=say)
    else:
        say('Dashboard not opened: use the shortcut, or run this with --launch.')
    return 0


def main():
    mode, options = parse_arguments(sys.argv[1:])
    if '--silent' in sys.argv[1:]:
        return silent_run(mode, options)
    if os.name == 'nt' and not is_admin() and '--no-elevate' not in sys.argv[1:]:
        # The manifest asks Windows for an administrator window; this covers a
        # run from source, where there is no manifest to ask for it. --no-elevate
        # is for developing the window itself, not for a real install.
        if relaunch_elevated():
            return 0
    wizard = Wizard(mode=mode, options=options)
    wizard.mainloop()
    return 0


if __name__ == '__main__':
    sys.exit(main())
