"""UI audit: dump widget geometry per wizard page, flag overflows."""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import setup_wizard as s


def audit(mode='install', step=0, label=''):
    w = s.Wizard(mode=mode, options={})
    w.show_step(step)
    try:
        w.deiconify()
    except Exception:
        pass
    try:
        w.geometry('+0+0')
    except Exception:
        pass
    import time as _time
    w.update()
    _time.sleep(0.4)
    w.update_idletasks()
    w.update()
    ww, wh = w.winfo_width(), w.winfo_height()
    print('=== %s window=%dx%d' % (label, ww, wh))
    problems = []
    in_stage = []

    def mark_stage(widget):
        in_stage.append(widget)
        for child in widget.winfo_children():
            mark_stage(child)

    try:
        mark_stage(w.stage_canvas)
    except AttributeError:
        pass
    stage_ids = set(map(id, in_stage))

    def walk(widget, path='root'):
        try:
            x, y = widget.winfo_rootx() - w.winfo_rootx(), widget.winfo_rooty() - w.winfo_rooty()
            wd, ht = widget.winfo_width(), widget.winfo_height()
        except Exception:
            return
        cls = widget.winfo_class()
        text = ''
        try:
            if cls in ('Label', 'Button', 'Entry', 'Checkbutton'):
                text = str(widget.cget('text'))[:50]
        except Exception:
            pass
        # overflow: widget extends past window bounds. The stage canvas
        # scrolls by design, so only its width is checked, never height.
        if id(widget) in stage_ids:
            if x < 0 or x + wd > ww + 2:
                if wd > 1 and ht > 1:
                    problems.append('%s %s too wide (%d+%d > %d) text=%r'
                                    % (cls, path, x, wd, ww, text))
        elif x < 0 or y < 0 or x + wd > ww + 2 or y + ht > wh + 2:
            # ignore the window itself and zero-size containers
            if not (path == 'root' and x <= 0 and y <= 0) and wd > 1 and ht > 1:
                problems.append('%s %s at (%d,%d) size %dx%d text=%r EXCEEDS %dx%d'
                                % (cls, path, x, y, wd, ht, text, ww, wh))
        for i, child in enumerate(widget.winfo_children()):
            walk(child, '%s/%s%d' % (path, child.winfo_class(), i))
        # label text wider than its own widget (clipped text)
        if cls == 'Label' and text:
            try:
                need = widget.tk.call('font', 'measure', widget.cget('font'), text)
                if need > wd + 2 and wd > 10:
                    problems.append('%s %s text clipped: needs %dpx in %dpx: %r'
                                    % (cls, path, need, wd, text))
            except Exception:
                pass

    walk(w)
    for problem in problems:
        try:
            print('  PROBLEM:', problem)
        except UnicodeEncodeError:
            print('  PROBLEM:', problem.encode('ascii', 'replace').decode())
    if not problems:
        print('  clean')
    # footer check
    print('  footer next: %r mapped=%s' % (w.next_btn.cget('text'), bool(w.next_btn.winfo_ismapped())))
    w.destroy()
    return problems


all_problems = []
all_problems += audit('install', 0, 'welcome')
all_problems += audit('install', 1, 'options')
all_problems += audit('install', 3, 'finish')
all_problems += audit('uninstall', 0, 'uninstall-welcome')
print('\nTOTAL PROBLEMS: %d' % len(all_problems))
