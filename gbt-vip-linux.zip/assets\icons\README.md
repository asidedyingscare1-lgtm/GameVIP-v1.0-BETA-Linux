# Reference icon crops

These files preserve the actual visible raster icons from the approved screenshot, including local background and glow. They are not vector files or original transparent icons. Source crop coordinates and native sizes are recorded in `../asset-manifest.json`.

Map windows to OS, shield to admin rights, gear to runtime, code to no-Python, network to port 80, panel-port to panel 8899, disk to available space, and folder to installation location. Use check, warning, and info with live status labels. The chevron-right image comes from the red Continue button and has its red background. Title-bar images still require genuine window controls behind them.

There is no refresh icon in this approved reference. Do not import one from an older mockup or assume a missing file is required.
