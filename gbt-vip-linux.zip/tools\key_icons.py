"""Make row/status icons transparent: flood-fill the near-black backdrop.

Reference crops ship with their local background baked in. This keys out
the backdrop (corner-flood, tolerance ramp) while keeping glyph + glow,
writing assets/icons_t/*.png. Originals stay untouched.
"""
import os
from collections import deque
from PIL import Image

SRC = os.path.join('assets', 'icons')
DST = os.path.join('assets', 'icons_t')
FILES = ('windows.png', 'shield.png', 'gear.png', 'code.png', 'network.png',
         'panel-port.png', 'disk.png', 'folder.png', 'check.png',
         'warning.png', 'info.png', 'chevron-right.png')


def transparentize(path):
    img = Image.open(path).convert('RGBA')
    pixels = img.load()
    w, ht = img.size
    # backdrop sample: median of the four corners
    corners = [pixels[0, 0][:3], pixels[w - 1, 0][:3], pixels[0, ht - 1][:3],
               pixels[w - 1, ht - 1][:3]]
    base = tuple(sum(channel) // 4 for channel in zip(*corners))
    inside = bytearray(w * ht)
    queue = deque()
    for x in range(w):
        queue += [(x, 0), (x, ht - 1)]
    for y in range(ht):
        queue += [(0, y), (w - 1, y)]

    def near(pixel):
        return all(abs(pixel[i] - base[i]) <= 34 for i in range(3))

    while queue:
        x, y = queue.popleft()
        if not (0 <= x < w and 0 <= y < ht) or inside[y * w + x]:
            continue
        inside[y * w + x] = 1
        if near(pixels[x, y][:3]):
            pixels[x, y] = (pixels[x, y][0], pixels[x, y][1],
                             pixels[x, y][2], 0)
            queue += [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]
    return img


def main():
    os.makedirs(DST, exist_ok=True)
    for name in FILES:
        src = os.path.join(SRC, name)
        if not os.path.isfile(src):
            print('missing', name)
            continue
        transparentize(src).save(os.path.join(DST, name))
        print('keyed', name)


if __name__ == '__main__':
    main()
