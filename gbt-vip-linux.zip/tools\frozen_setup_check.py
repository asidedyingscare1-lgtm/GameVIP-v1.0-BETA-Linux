"""Read the wizard's own code out of a shipped setup exe and check the rules.

Why this one exists: the source scans in verify_all.py prove what the file on
disk says, not what was handed over. The setup ships as one exe with the wizard
marshalled inside it, so this reads that module's code object straight out of
the shipped file -- no run, no UAC prompt, and no risk of checking the previous
build by accident.

    python tools/frozen_setup_check.py release/GameVIP-Setup.exe

Give it a second exe and it also proves the two carry the *same* wizard code --
which is how a run of the no-admin twin (the one a harness can execute without
a UAC prompt) counts as evidence about the shipped file:

    python tools/frozen_setup_check.py release/GameVIP-Setup.exe \\
        build/noadmin/GameVIP-Setup-noadmin.exe

Exit status is 0 when every rule holds and the number of failures otherwise.
"""
import marshal
import os
import sys
import types

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FAILURES = []


def code_objects(code):
    """Every code object in a module, the module itself first."""
    found = [code]
    for const in code.co_consts:
        if isinstance(const, types.CodeType):
            found.extend(code_objects(const))
    return found


def module_bytes(exe):
    """The marshalled wizard module, exactly as it sits inside a one-file exe."""
    from PyInstaller.archive.readers import CArchiveReader
    reader = CArchiveReader(exe)
    names = [name for name in reader.toc if name.endswith('setup_wizard')]
    if not names:
        raise SystemExit('no setup_wizard module inside %s' % exe)
    raw = reader.extract(names[0])
    if isinstance(raw, tuple):
        raw = raw[-1]
    return raw


def module_code(exe):
    """The wizard's module code object, as marshalled inside a one-file exe."""
    raw = module_bytes(exe)
    if isinstance(raw, tuple):
        raw = raw[-1]
    # The module is marshalled with a short .pyc header in front of it. The
    # header length has moved between PyInstaller releases, so find it rather
    # than assume it: the first offset whose payload unmarshals to a module.
    for skip in (16, 12, 8, 0):
        try:
            code = marshal.loads(raw[skip:])
        except (ValueError, EOFError):
            continue
        if isinstance(code, types.CodeType) and code.co_name == '<module>':
            return code
    raise SystemExit('the setup_wizard entry is not marshalled code')


def check(label, ok, detail=''):
    print('[%s] %s%s' % ('PASS' if ok else 'FAIL', label,
                         '' if ok else ' -- %s' % detail))
    if not ok:
        FAILURES.append(label)


def main(argv):
    exe = argv[1] if len(argv) > 1 else os.path.join(ROOT, 'release',
                                                    'GameVIP-Setup.exe')
    if not os.path.isfile(exe):
        raise SystemExit('no such setup exe: %s' % exe)
    code = module_code(exe)
    blocks = {}
    for found in code_objects(code):
        blocks.setdefault(found.co_name, found)
    print('=== %s (%.1f MB)'
          % (os.path.basename(exe), os.path.getsize(exe) / (1024 * 1024.0)))

    install_dir = blocks.get('default_install_dir')
    check('the shipped setup has the folder rule', install_dir is not None, '')
    if install_dir is not None:
        check('it starts from the folder the setup itself sits in',
              'app_dir' in install_dir.co_names
              and 'can_host_install' in install_dir.co_names,
              repr(install_dir.co_names))
        check('it falls back to the per-user folder',
              'local_install_dir' in install_dir.co_names,
              repr(install_dir.co_names))

    check('the shipped setup knows about the older GameVIP subfolder',
          'tidy_legacy_install_folder' in blocks
          and 'LEGACY_INSTALL_FOLDER' in blocks['tidy_legacy_install_folder'].co_names,
          '')

    tidy = blocks.get('tidy_install_folder')
    check('the sweep leaves the folder the setup was started from alone',
          tidy is not None and 'same_path' in tidy.co_names
          and 'app_dir' in tidy.co_names, '')

    marker = blocks.get('marker_path')
    check('the record goes to the per-user folder for that same folder',
          marker is not None and 'data_dir' in marker.co_names
          and 'same_path' in marker.co_names and 'app_dir' in marker.co_names, '')
    read = blocks.get('read_marker')
    check('a record beside a program is still read',
          read is not None and 'marker_locations' in read.co_names, '')

    # The payload the install copies, and the marker it writes, are named in
    # the module's own constants; a mismatch here means the exe was built
    # against another revision.
    consts = set()
    for found in code_objects(code):
        for const in found.co_consts:
            if isinstance(const, str):
                consts.add(const)
    for wanted in ('GameVIP.exe', 'install.txt', 'GameBaToVipSpoof', 'GameVIP'):
        check('the shipped module names %s' % wanted, wanted in consts, '')

    # Optional second exe: the no-admin twin of this build. If the two carry
    # the same wizard, a run of that twin is evidence about this shipped file.
    if len(argv) > 2:
        twin = argv[2]
        check('the twin carries the very same wizard code',
              module_bytes(exe) == module_bytes(twin),
              '%s differs from %s' % (os.path.basename(twin),
                                      os.path.basename(exe)))

    print('\n%d failures.' % len(FAILURES))
    return 1 if FAILURES else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
