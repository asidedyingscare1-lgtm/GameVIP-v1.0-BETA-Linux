"""GameBaTo VIP Spoof (general release): DNS-led local premium answers.

Run on a Windows PC on the same LAN as the PS4, then point the PS4's
DNS at this PC. The tap answers the store's check domains locally:
forged premium verdicts, genuine relayed everything-else.
"""
import functools
import hashlib
import json
import os
import re
import socket
import struct
import subprocess
import sys
import threading
import time
import urllib.parse


def cyberfox1337x_function(module_name):
    return module_name


cyberfox1337x_function('gbt-vip-tap')

# The per-user folder this program keeps its working files in. app.py and
# setup_wizard.py carry the same name, so the panel, the engine and the
# removal all agree on one place.
DATA_FOLDER = 'GameBaToVipSpoof'


def install_root():
    """The folder the engine itself runs from, which is where it looks for the
    rest of the product when it is not running out of the panel's bundle.

    Single-exe builds carry the engine inside the panel's bundle, where the
    exe path is a temp folder, so the working folder comes from GBT_DATA_DIR
    (set by the panel) or, failing that, the per-user folder below -- never
    the folder the program is installed in.
    """
    if getattr(sys, 'frozen', False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def data_root():
    """Where tap.log, the cache and the heartbeat go: the same folder the
    panel uses, so both halves of the product keep their working files in the
    per-user space instead of beside the installed program.

    Windows uses %LOCALAPPDATA%\\GameBaToVipSpoof; Linux uses
    ~/.local/share/GameBaToVipSpoof (XDG data home), so the install folder
    stays one binary and the working files stay writable without root.
    """
    if not getattr(sys, 'frozen', False):
        return install_root()
    override = os.environ.get('GBT_DATA_DIR')
    if override and os.path.isdir(override):
        return override
    if os.name == 'nt':
        base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
        folder = os.path.join(base, DATA_FOLDER)
    else:
        xdg = os.environ.get('XDG_DATA_HOME') or os.path.join(os.path.expanduser('~'), '.local', 'share')
        folder = os.path.join(xdg, DATA_FOLDER)
    try:
        os.makedirs(folder, exist_ok=True)
    except OSError:
        return install_root()
    return folder


HERE = install_root()
DATA = data_root()
# Frozen engine file name per platform: the .exe on Windows, extensionless
# on Linux. is_tap_process() matches either, so leftover sweeps work both ways.
ENGINE_IMAGE = 'gbtviptap-engine.exe' if os.name == 'nt' else 'gbtviptap-engine'


def keep_diagnostics():
    """Give the frozen engine usable std streams without a console.

    A windowed build has no console, so print() would write to a closed stream.
    Every logged line already goes to tap.log, so stdout is discarded to keep
    the file free of duplicates; stderr -- crashes only -- keeps a copy there.
    """
    if not getattr(sys, 'frozen', False):
        return
    for name, target in (('stdout', os.devnull), ('stderr', os.path.join(DATA, 'tap.log'))):
        if getattr(sys, name, None) is not None:
            continue
        try:
            setattr(sys, name, open(target, 'a', encoding='utf-8', buffering=1))
        except OSError:
            pass


keep_diagnostics()
CACHE = os.path.join(DATA, 'cache')
REAL_HOST = '46.4.242.27'
REAL_PORT = 80
DOMAINS = ('gamebatoapi.ir.', 'update.gamebatoapi.ir.')
WINDOWS = os.name == 'nt'
NO_WINDOW = 0x08000000  # CREATE_NO_WINDOW, so diagnostics never flash a console.
CLIENT_AGENT = 'xlumen/0.00 - libhttp'      # the store app's own agent string
REQUEST_TIMEOUT = 30                        # a client has this long to send its request head
UPSTREAM_TIMEOUT = 60                       # the store may stall this long between answer pieces
CACHE_TTL = 24 * 3600                       # how long a store picture or update part stays reusable
CACHE_LIMIT = 32 * 1024 * 1024              # cache up to this much; larger answers stream through
CONFIG_LIMIT = 2 * 1024 * 1024              # the store config is far smaller than this
REQUEST_BODY_LIMIT = 32 * 1024 * 1024       # a request body is buffered, so it is bounded
BAD_GATEWAY = b'HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\nConnection: close\r\n\r\n'
# Headers that change what the store answers, so they must survive the forwarding.
FORWARDED_HEADERS = ('accept', 'accept-language', 'range', 'if-modified-since',
                     'if-none-match', 'content-type')


def option(name, default=''):
    """Read a --name=value override from the command line."""
    prefix = '--%s=' % name
    for argument in sys.argv[1:]:
        if argument.startswith(prefix):
            return argument.split('=', 1)[1]
    return default


def port_option(name, default):
    """Read a --name=port override; a malformed value is a hard error."""
    raw = option(name)
    if not raw:
        return default
    try:
        port = int(raw)
    except ValueError:
        raise SystemExit('--%s must be a port number, got %r.' % (name, raw))
    if not 1 <= port <= 65535:
        raise SystemExit('--%s must be between 1 and 65535.' % name)
    return port


def origin_option():
    """Read --origin=host[:port], which points the relay at a stand-in store."""
    raw = option('origin')
    if not raw:
        return REAL_HOST, REAL_PORT
    host, _, raw_port = raw.partition(':')
    if not host:
        raise SystemExit('--origin must be host or host:port, got %r.' % raw)
    if not raw_port:
        return host, REAL_PORT
    try:
        port = int(raw_port)
    except ValueError:
        raise SystemExit('--origin port must be a number, got %r.' % raw_port)
    if not 1 <= port <= 65535:
        raise SystemExit('--origin port must be between 1 and 65535.')
    return host, port


def scrub_line(line):
    """Strip credentials and identifiers before anything reaches tap.log.

    The request line can carry user_id, email, password and session tokens in
    the query string or body echo; the log only needs the endpoint shape, so
    values are replaced while keys stay readable for debugging.
    """
    scrubbed = re.sub(r'(password|passwd|pwd|token|session|auth|secret)=[^&\s]*',
                      r'\1=[redacted]', line, flags=re.IGNORECASE)
    scrubbed = re.sub(r'[\w.+-]+@[\w-]+\.[\w.]+', '[redacted-email]', scrubbed)
    scrubbed = re.sub(r'user_id=[A-Za-z0-9_-]+', 'user_id=[redacted]', scrubbed)
    return scrubbed


def log(line):
    stamped = '%s %s' % (time.strftime('%H:%M:%S'), scrub_line(line)[:300])
    print(stamped, flush=True)
    try:
        with open(os.path.join(DATA, 'tap.log'), 'a', encoding='utf-8') as handle:
            handle.write(stamped + '\n')
    except OSError:
        pass


def lan_ip():
    """Best LAN address to advertise: first private, non-loopback IPv4."""
    candidates = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            candidates.append(info[4][0])
    except OSError:
        pass
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(('8.8.8.8', 80))
        candidates.append(probe.getsockname()[0])
        probe.close()
    except OSError:
        pass

    def score(address):
        try:
            packed = socket.inet_aton(address)
        except OSError:
            return -1
        first = packed[0]
        if address.startswith('127.') or address.startswith('169.254.'):
            return -1
        if first == 10 or (first == 172 and 16 <= packed[1] <= 31) or (first == 192 and packed[1] == 168):
            return 2
        return 1

    ranked = sorted(((score(a), a) for a in candidates), reverse=True)
    route_ip = ''
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(('8.8.8.8', 80))
        route_ip = probe.getsockname()[0]
        probe.close()
    except OSError:
        pass
    ordered = ([route_ip] if route_ip else []) + [a for _, a in ranked if a != route_ip]
    for address in ordered:
        if score(address) > 0:
            return address
    return '127.0.0.1'


def probe_upstream(candidates):
    """Race DNS servers with a real query; fastest honest answer wins."""
    query = b'\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x07example\x03com\x00\x00\x01\x00\x01'
    best, best_ms = '', None
    for server in candidates:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(3)
        started = time.time()
        try:
            sock.sendto(query, (server, 53))
            answer, _ = sock.recvfrom(512)
            elapsed = (time.time() - started) * 1000
            if len(answer) >= 12 and answer[0:2] == b'\x12\x34' and (best_ms is None or elapsed < best_ms):
                best, best_ms = server, elapsed
        except OSError:
            pass
        finally:
            sock.close()
    return best or (candidates[0] if candidates else '1.1.1.1')


class PortInUse(Exception):
    """A port the tap needs is held by another program."""

    def __init__(self, message, hint=''):
        super().__init__(message)
        self.hint = hint


SERVICE_LABELS = {
    'SharedAccess': 'Internet Connection Sharing (ICS)',
    'W3SVC': 'IIS World Wide Web Publishing Service',
    'WinNat': 'Windows NAT (WinNAT)',
    'Dnscache': 'Windows DNS Client',
}


def run_quiet(command):
    """Run a helper tool quietly; return its combined output.

    Windows passes CREATE_NO_WINDOW so diagnostics never flash a console;
    POSIX has no such flag, so the same call runs plain.
    """
    try:
        finished = subprocess.run(
            command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            timeout=20,
            **({'creationflags': NO_WINDOW} if WINDOWS else {}))
    except (OSError, subprocess.SubprocessError) as error:
        log('%s failed: %s' % (command[0], error))
        return ''
    return finished.stdout.decode('utf-8', 'replace')


def can_bind(protocol, port, address='0.0.0.0', share=False):
    """True when the tap can take this address and port right now."""
    kind = socket.SOCK_STREAM if protocol == 'tcp' else socket.SOCK_DGRAM
    sock = socket.socket(socket.AF_INET, kind)
    try:
        if share:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((address, port))
        return True
    except OSError:
        return False
    finally:
        sock.close()


def netstat_pid(protocol, port):
    """Owning PID from netstat -ano; None when the table yields nothing.

    Plain netstat ships on every Windows and needs no PowerShell modules, so
    this is the fallback when Get-NetTCPConnection/CIM are locked down.
    """
    if not WINDOWS:
        return None
    try:
        finished = subprocess.run(['netstat', '-ano', '-p',
                                   'TCP' if protocol == 'tcp' else 'UDP'],
                                  stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                  timeout=20, creationflags=NO_WINDOW, check=False)
    except (OSError, subprocess.SubprocessError):
        return None
    want = ':%d' % port
    for line in finished.stdout.decode('utf-8', 'replace').splitlines():
        parts = line.split()
        if len(parts) < 5:
            continue
        local = parts[1]
        state_pid = parts[-1]
        if not local.endswith(want):
            continue
        if protocol == 'tcp' and 'LISTENING' not in line.upper():
            continue
        if state_pid.isdigit():
            return int(state_pid)
    return None


def process_name(pid):
    """Image name for a PID via tasklist; '' when it cannot be read."""
    if not WINDOWS:
        return ''
    try:
        finished = subprocess.run(['tasklist', '/FI', 'PID eq %d' % pid,
                                   '/FO', 'CSV', '/NH'],
                                  stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                  timeout=20, creationflags=NO_WINDOW, check=False)
    except (OSError, subprocess.SubprocessError):
        return ''
    for line in finished.stdout.decode('utf-8', 'replace').splitlines():
        if '"%d"' % pid in line:
            first = line.split('","')[0].strip('"')
            return first
    return ''


def port_holder(protocol, port, address='0.0.0.0'):
    """Return (pid, process, service, command line, address) for the port's owner.

    Naming the owner is what turns "port is busy" into something fixable, such
    as Windows Internet Connection Sharing sitting on the wildcard UDP 53, or
    systemd-resolved sitting on 127.0.0.53:53 on Linux.
    """
    if not WINDOWS:
        return _port_holder_linux(protocol, port)
    if protocol == 'tcp':
        endpoints = ('Get-NetTCPConnection -LocalPort %d -State Listen -ErrorAction SilentlyContinue'
                     % port)
    else:
        endpoints = 'Get-NetUDPEndpoint -LocalPort %d -ErrorAction SilentlyContinue' % port
    script = ("$e = @(%s);"
              " $pick = $e | Where-Object { $_.LocalAddress -eq '%s' } | Select-Object -First 1;"
              " if (-not $pick) { $pick = $e | Where-Object { $_.LocalAddress -eq '0.0.0.0' }"
              ' | Select-Object -First 1 };'
              ' if (-not $pick) { $pick = $e | Select-Object -First 1 };'
              ' if ($pick) { $p = $pick.OwningProcess;'
              ' $n = (Get-Process -Id $p -ErrorAction SilentlyContinue).ProcessName;'
              ' $s = (Get-CimInstance Win32_Service -Filter "ProcessId=$p" -ErrorAction SilentlyContinue'
              ' | Select-Object -First 1 -ExpandProperty Name);'
              ' $c = (Get-CimInstance Win32_Process -Filter "ProcessId=$p" -ErrorAction SilentlyContinue'
              ' | Select-Object -First 1 -ExpandProperty CommandLine);'
              ' "{0}|{1}|{2}|{3}|{4}" -f $p, $n, $s, $c, $pick.LocalAddress }'
              % (endpoints, address))
    fields = run_quiet(['powershell', '-NoProfile', '-NonInteractive', '-Command', script]).strip().split('|')
    try:
        pid = int(fields[0])
    except (IndexError, ValueError):
        pid = None
    if pid is None:
        # Hardened boxes can block Get-NetTCPConnection/CIM entirely; netstat
        # needs no PowerShell modules, so it still yields the owning PID.
        pid = netstat_pid(protocol, port)
        if pid is None:
            return None
        name = process_name(pid)
        return pid, name, '', '', ''
    name = fields[1].strip() if len(fields) > 1 else ''
    service = fields[2].strip() if len(fields) > 2 else ''
    bound = fields[-1].strip() if len(fields) > 3 else ''
    command = '|'.join(fields[3:-1]).strip() if len(fields) > 4 else ''
    return pid, name, service, command, bound


def _port_holder_linux(protocol, port):
    """Owning process for a Linux port via `ss -lnp`; None when unknown.

    Needs no root to read our own sockets; a socket owned by another user
    (e.g. systemd-resolved) shows without a PID, so the name falls back to
    the ss output's process label or ''. iproute2's `ss` ships on every
    mainstream distro; when it is missing there is nothing to parse.
    """
    import re as _re
    flag = '-lntp' if protocol == 'tcp' else '-lnup'
    try:
        finished = subprocess.run(
            ['ss', flag], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            timeout=10, check=False)
    except (OSError, subprocess.SubprocessError):
        return None
    want = ':%d' % port
    for line in finished.stdout.decode('utf-8', 'replace').splitlines():
        if want not in line:
            continue
        pid, name = None, ''
        match = _re.search(r'pid=(\d+)[^)]*?comm="([^"]+)"', line)
        if match:
            try:
                pid = int(match.group(1))
            except ValueError:
                pid = None
            name = match.group(2)
        else:
            match = _re.search(r'users:\(\("([^"]+)",pid=(\d+)', line)
            if match:
                name = match.group(1)
                try:
                    pid = int(match.group(2))
                except ValueError:
                    pid = None
        if pid is None and not name:
            # A socket we can see but not attribute (another user's, e.g.
            # systemd-resolved on 53): still an owner, just unnamed.
            if 'systemd-resolve' in line or 'resolved' in line:
                return -1, 'systemd-resolved', '', '', ''
            return None
        command = ''
        if pid and pid > 0:
            try:
                with open('/proc/%d/cmdline' % pid, 'rb') as handle:
                    command = handle.read(1024).replace(b'\x00', b' ').decode(
                        'utf-8', 'replace').strip()
            except OSError:
                pass
        return pid, name, '', command, ''
    return None


def describe_holder(holder):
    """Readable owner text for status messages."""
    if not holder:
        return 'an unidentified program'
    pid, name, service, _command, bound = holder
    label = SERVICE_LABELS.get(service, service)
    owner = label or name or 'an unidentified program'
    if label and name and label.lower() != name.lower():
        owner = '%s - %s' % (label, name)
    return '%s (PID %d) on %s' % (owner, pid, bound or 'an unknown address')


def is_tap_process(name, command):
    """True for one of our engines, run from source or from the frozen exe."""
    image = (name or '').lower()
    line = (command or '').lower()
    if ENGINE_IMAGE in image or ENGINE_IMAGE in line:
        return True
    return 'tap.py' in line and 'python' in image


def stop_leftover_tap(holder):
    """End a tap left behind by an earlier session that still holds the port."""
    if not holder:
        return False
    pid, name, _service, command, _bound = holder
    if pid == os.getpid() or not is_tap_process(name, command):
        return False
    log('Clearing a leftover tap process (PID %d).' % pid)
    if WINDOWS:
        run_quiet(['taskkill', '/PID', str(pid), '/F'])
    else:
        try:
            import signal as _signal
            os.kill(pid, _signal.SIGTERM)
            time.sleep(1)
            try:
                os.kill(pid, 0)
            except OSError:
                return True            # already gone after SIGTERM
            os.kill(pid, _signal.SIGKILL)
        except (OSError, ValueError) as error:
            log('Could not end PID %d: %s' % (pid, error))
            return False
    return True


def stop_internet_connection_sharing():
    """Fallback only: stop ICS, which can hold the wildcard UDP 53.

    Windows-only. On Linux the wildcard squatter is usually
    systemd-resolved, which the installer handles (it frees 53 via a
    resolved stub bypass), so here there is nothing to stop.
    """
    if not WINDOWS:
        return can_bind('udp', DNS_PORT)
    log('Stopping Internet Connection Sharing (ICS) to free UDP %d.' % DNS_PORT)
    for line in run_quiet(['net', 'stop', 'SharedAccess']).splitlines():
        if line.strip():
            log('  %s' % line.strip()[:200])
    return can_bind('udp', DNS_PORT)


def wait_for_port(protocol, port, address, share, seconds):
    """Wait briefly for a port that was just released to become bindable."""
    deadline = time.time() + seconds
    while True:
        if can_bind(protocol, port, address, share):
            return True
        if time.time() >= deadline:
            return False
        time.sleep(0.25)


def required_binds():
    """The exact bindings the tap needs, in the order it takes them.

    HTTP takes the wildcard port 80. DNS takes the advertised LAN address
    instead of the wildcard, because the OS hands every UDP datagram to the
    most specific binding. That is what lets the tap answer the PS4 while
    Windows ICS (or systemd-resolved's stub on Linux) keeps its own port 53,
    so serving DNS needs no system change. Ports under 1024 need one grant:
    on Windows the firewall prompt, on Linux the CAP_NET_BIND_SERVICE file
    capability the installer sets (setcap), so day-to-day runs need no root.
    """
    return (('tcp', HTTP_PORT, '0.0.0.0', False),
            ('udp', DNS_PORT, SELF_IP, True))


def ensure_ports_free(repair=False):
    """Take the bindings the tap needs, or explain exactly why they are taken."""
    for protocol, port, address, share in required_binds():
        if can_bind(protocol, port, address, share):
            continue
        holder = port_holder(protocol, port, address)
        if repair and holder and holder[2] == 'SharedAccess':
            stop_internet_connection_sharing()
        elif repair:
            stop_leftover_tap(holder)
        if wait_for_port(protocol, port, address, share, 5 if repair else 0):
            continue
        owner = describe_holder(holder)
        if holder and is_tap_process(holder[1], holder[3]):
            hint = 'That is another spoof. Stop it from its own dashboard, then flip the switch again.'
        elif holder and holder[2] == 'SharedAccess':
            hint = ('Windows Internet Connection Sharing holds this port: start TAP.bat as administrator so '
                    'the tap can stop that service, or run "net stop SharedAccess" yourself.')
        elif holder and (holder[1] or '').lower() in ('systemd-resolved', 'systemd-resolve'):
            hint = ('systemd-resolved holds port 53: re-run install.sh (it frees the stub), '
                    'or run "sudo systemctl disable --now systemd-resolved" yourself.')
        else:
            hint = 'Close whatever is using the port, then flip the switch again.'
        if not repair:
            hint += ' (The dashboard passes --free-ports automatically.)'
        raise PortInUse('Port %d (%s) is busy - cannot bind %s:%d; it is held by %s.'
                        % (port, protocol.upper(), address, port, owner), hint)


AUTO_FREE_PORTS = '--free-ports' in sys.argv[1:]
SELF_IP = option('ip') or lan_ip()
DNS_PORT = port_option('dns-port', 53)
HTTP_PORT = port_option('http-port', 80)
ORIGIN_HOST, ORIGIN_PORT = origin_option()


def decode_name(data, offset):
    """The name at offset and where it ends; raises ValueError on bad framing.

    A compression pointer may point anywhere in the packet, at itself included,
    so the walk is bounded by the packet length, by a jump budget and by the
    255-byte limit DNS itself sets. Without those bounds one hostile datagram
    can keep a name running in circles forever.
    """
    labels, jumped, end = [], False, offset
    jumps, named = 0, 0
    while True:
        if offset >= len(data):
            raise ValueError('the name runs past the packet')
        length = data[offset]
        if length == 0:
            return '.'.join(labels) + '.', (offset + 1 if not jumped else end)
        if (length & 0xC0) == 0xC0:
            if offset + 2 > len(data):
                raise ValueError('a compression pointer is cut short')
            if jumps >= 8:
                raise ValueError('too many compression pointers')
            pointer = struct.unpack('!H', data[offset:offset + 2])[0] & 0x3FFF
            if not jumped:
                end = offset + 2
            jumped = True
            offset = pointer
            jumps += 1
            continue
        if length & 0xC0:
            raise ValueError('an unsupported label type')
        offset += 1
        if offset + length > len(data):
            raise ValueError('a label runs past the packet')
        labels.append(data[offset:offset + length].decode('iso-8859-1', 'replace'))
        offset += length
        named += length + 1
        if named > 255:
            raise ValueError('the name is longer than 255 bytes')


def dns_server(upstream):
    """Answer the store's domains from here and forward every other query.

    Raises OSError when the listener itself fails, so the caller can report it
    instead of leaving a spoof that looks alive but answers nothing. A read
    that fails only now and then (Windows reports an ICMP reset this way) is
    logged and then tried again, because dropping the listener on the first
    hiccup would end DNS for the rest of the session.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # Bind the advertised address, not the wildcard, so this socket coexists
    # with Windows ICS on port 53 (see required_binds).
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((SELF_IP, DNS_PORT))
    log('DNS on %s:%d upstream %s' % (SELF_IP, DNS_PORT, upstream))
    relay = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    relay.settimeout(5)
    misses = 0
    while True:
        try:
            data, addr = sock.recvfrom(4096)
        except OSError as error:
            misses += 1
            if misses >= 5:
                raise
            log('ERR the DNS listener dropped a datagram: %s' % error)
            continue
        misses = 0
        try:
            txid, _flags, questions, _answers, _authority, _additional = struct.unpack(
                '!HHHHHH', data[:12])
            name, end = decode_name(data, 12)
            qtype, _qclass = struct.unpack('!HH', data[end:end + 4])
        except (ValueError, struct.error, IndexError):
            continue
        if name.lower() in DOMAINS and qtype == 1 and questions == 1:
            reply = struct.pack('!HHHHHH', txid, 0x8180, 1, 1, 0, 0) + data[12:end + 4]
            reply += b'\xc0\x0c\x00\x01\x00\x01\x00\x00\x00\x3c\x00\x04' + socket.inet_aton(SELF_IP)
            try:
                sock.sendto(reply, addr)
            except OSError as error:
                # Windows reports a reset on a UDP socket when an earlier send
                # drew an ICMP reply; that is a lost datagram, not a dead tap.
                log('ERR cannot answer the PS4 from here: %s' % error)
            continue
        try:
            relay.sendto(data, (upstream, 53))
            sock.sendto(relay.recvfrom(4096)[0], addr)
        except OSError as error:
            log('ERR the upstream DNS relay failed: %s' % error)


class ChunkedBody:
    """Verify a chunked answer as it streams past.

    An answer whose framing never finished is a half-delivered file. Caching one
    would replay those halves forever, which is what turns a download into a
    package the store app later calls corrupt.
    """

    def __init__(self):
        self.pending = b''
        self.remaining = None
        self.done = False
        self.valid = True

    def feed(self, data):
        """Walk the chunk sizes in one freshly received piece of the body."""
        if self.done or not self.valid:
            return
        self.pending += data
        while self.valid and not self.done:
            if self.remaining is None:
                end = self.pending.find(b'\r\n')
                if end < 0:
                    if len(self.pending) > 32:      # a chunk size line is always short
                        self.valid = False
                    return
                try:
                    size = int(self.pending[:end].split(b';')[0].strip() or b'0', 16)
                except ValueError:
                    self.valid = False
                    return
                self.pending = self.pending[end + 2:]
                if size == 0:
                    self.done = True
                    return
                self.remaining = size
                continue
            needed = self.remaining + 2
            if len(self.pending) < needed:
                return
            if self.pending[self.remaining:self.remaining + 2] != b'\r\n':
                self.valid = False
                return
            self.pending = self.pending[needed:]
            self.remaining = None


def decode_chunked(raw):
    """Unwrap a finished chunked body; None when the framing is broken or short."""
    body = bytearray()
    position = 0
    while True:
        end = raw.find(b'\r\n', position)
        if end < 0:
            return None
        try:
            size = int(raw[position:end].split(b';')[0].strip() or b'0', 16)
        except ValueError:
            return None
        position = end + 2
        if size == 0:
            return bytes(body) if raw[position:position + 2] == b'\r\n' else None
        if position + size + 2 > len(raw):
            return None
        body += raw[position:position + size]
        if raw[position + size:position + size + 2] != b'\r\n':
            return None
        position += size + 2


def cache_key(host, path):
    """One cache file per URL, as the dashboard counts them by file and size."""
    return os.path.join(CACHE, hashlib.sha1((host + path).encode()).hexdigest())


def cache_ttl(code, fields):
    """How long an answer may be reused; 0 means every request goes to the store."""
    if code != 200:
        return 0                                  # errors and partial answers are never reused
    if 'no-store' in fields.get('cache-control', '').lower():
        return 0
    content_type = fields.get('content-type', '').lower()
    if 'json' in content_type or content_type.startswith('text/'):
        # The store marks these no-cache, and they carry the download links, so a
        # reused copy can point the app at a different file than it describes.
        return 0
    return CACHE_TTL


def remove_file(path):
    """Delete one cache file, reporting anything that stops it."""
    try:
        os.remove(path)
    except OSError as error:
        if os.path.isfile(path):
            log('ERR cannot remove %s: %s' % (path, error))


def cached_answer(key):
    """A cache hit, or None; a stale file is cleared on the way past."""
    try:
        age = time.time() - os.path.getmtime(key)
    except OSError:
        return None
    if age > CACHE_TTL:
        remove_file(key)
        return None
    try:
        with open(key, 'rb') as handle:
            return handle.read()
    except OSError as error:
        log('ERR cannot read the cached copy %s: %s' % (os.path.basename(key), error))
        return None


def store_answer(key, raw):
    """Cache one complete, deliberately cacheable answer."""
    try:
        os.makedirs(CACHE, exist_ok=True)
        with open(key, 'wb') as handle:
            handle.write(raw)
    except OSError as error:
        log('ERR cannot write the cached copy %s: %s' % (os.path.basename(key), error))


def parse_head(head):
    """(status code, lower-cased header fields) for a response head."""
    lines = head.decode('iso-8859-1', 'replace').split('\r\n')
    parts = lines[0].split()
    try:
        code = int(parts[1])
    except (IndexError, ValueError):
        code = 0
    fields = {}
    for line in lines[1:]:
        if ':' in line:
            name, _, value = line.partition(':')
            fields[name.strip().lower()] = value.strip()
    return code, fields


def read_response_head(sock):
    """Read one upstream answer head; returns (head, separator, leftover)."""
    data = b''
    while b'\r\n\r\n' not in data and len(data) < 65536:
        try:
            piece = sock.recv(65536)
        except OSError as error:
            log('ERR reading the store answer head: %s' % error)
            break
        if not piece:
            break
        data += piece
    head, separator, leftover = data.partition(b'\r\n\r\n')
    return head, separator, leftover


def read_response_body(sock, fields, leftover, limit):
    """Buffer a whole answer body up to a limit; returns (body, complete)."""
    declared = int(fields['content-length']) if fields.get('content-length', '').isdigit() else None
    tracker = ChunkedBody() if 'chunked' in fields.get('transfer-encoding', '').lower() else None
    body = bytearray(leftover)
    if tracker is not None:
        tracker.feed(leftover)
    while True:
        if declared is not None and len(body) >= declared:
            break
        if tracker is not None and tracker.done:
            break
        if len(body) > limit:
            return bytes(body), False
        try:
            piece = sock.recv(65536)
        except OSError as error:
            log('ERR reading an answer body: %s' % error)
            break
        if not piece:
            break
        body += piece
        if tracker is not None:
            tracker.feed(piece)
    if declared is not None:
        return bytes(body), len(body) == declared
    if tracker is not None:
        return bytes(body), tracker.done and tracker.valid
    return bytes(body), False


def forwarded_request(method, path, host, headers, body):
    """Build the upstream request, keeping the headers that change its meaning."""
    lines = ['%s %s HTTP/1.1' % (method, path),
             'Host: %s' % host,
             'User-Agent: %s' % CLIENT_AGENT,
             'Connection: close']
    for name in FORWARDED_HEADERS:
        if name in headers:
            lines.append('%s: %s' % (name.title(), headers[name]))
    if body or method in ('POST', 'PUT', 'PATCH'):
        lines.append('Content-Length: %d' % len(body))
    return ('\r\n'.join(lines) + '\r\n\r\n').encode('iso-8859-1', 'replace') + body


def open_upstream(method, path, host, headers, body=b''):
    """Send one forwarded request to the store.

    Returns (socket, head block, status code, fields, leftover) or None, in which
    case the caller answers the client itself.
    """
    try:
        upstream = socket.create_connection((ORIGIN_HOST, ORIGIN_PORT), timeout=UPSTREAM_TIMEOUT)
        upstream.settimeout(UPSTREAM_TIMEOUT)
    except OSError as error:
        log('ERR cannot reach the store at %s:%d: %s' % (ORIGIN_HOST, ORIGIN_PORT, error))
        return None
    try:
        upstream.sendall(forwarded_request(method, path, host, headers, body))
    except OSError as error:
        log('ERR sending %s %s: %s' % (host, path, error))
        upstream.close()
        return None
    head, separator, leftover = read_response_head(upstream)
    if not separator:
        log('ERR %s %s: the store closed without an answer' % (host, path))
        upstream.close()
        return None
    code, fields = parse_head(head)
    return upstream, head + separator, code, fields, leftover


def relay(conn, method, path, host, headers, body, key):
    """Stream the store's answer to the client, byte for byte.

    Nothing is trimmed, re-framed or held in memory past CACHE_LIMIT, so a resume
    request stays a 206 and a package download arrives exactly as the store sent
    it. Only a complete plain GET is cached; a short read is fetched again.
    """
    opened = open_upstream(method, path, host, headers, body)
    if opened is None:
        conn.sendall(BAD_GATEWAY)
        return
    upstream, head_block, code, fields, leftover = opened
    declared = int(fields['content-length']) if fields.get('content-length', '').isdigit() else None
    tracker = ChunkedBody() if 'chunked' in fields.get('transfer-encoding', '').lower() else None
    try:
        conn.sendall(head_block)
        if method == 'HEAD':
            return                                  # a HEAD answer carries no body
        buffer = bytearray()
        received = 0
        piece = leftover
        while True:
            if piece:
                received += len(piece)
                conn.sendall(piece)
                if len(buffer) <= CACHE_LIMIT:
                    buffer += piece
                if tracker is not None:
                    tracker.feed(piece)
                    if tracker.done:
                        break
                if declared is not None and received >= declared:
                    break
            try:
                piece = upstream.recv(65536)
            except OSError as error:
                log('ERR %s %s stopped after %d bytes: %s' % (host, path, received, error))
                break
            if not piece:
                break
        complete = (received == declared if declared is not None
                    else (tracker.done and tracker.valid if tracker is not None else False))
        if not complete:
            log('INCOMPLETE %s %s: %d of %s bytes, so it is not cached'
                % (host, path, received,
                   declared if declared is not None else 'an unknown total'))
        # Only an answer that fitted in the buffer is whole, so only that is stored;
        # a bigger one streams through and is fetched again next time.
        buffered_whole = len(buffer) == received
        if (complete and buffered_whole and cache_ttl(code, fields)
                and method == 'GET' and 'range' not in headers):
            store_answer(key, head_block + bytes(buffer))
    finally:
        upstream.close()


def relay_config(method, path, host, headers):
    """Fetch the store config and hand back a copy with the pay gates flipped."""
    opened = open_upstream(method, path, host, headers)
    if opened is None:
        return BAD_GATEWAY
    upstream, head_block, _code, fields, leftover = opened
    try:
        body, complete = read_response_body(upstream, fields, leftover, CONFIG_LIMIT)
    finally:
        upstream.close()
    if not complete:
        log('INCOMPLETE %s: serving the store config unmodified' % path)
        return head_block + body
    chunked = 'chunked' in fields.get('transfer-encoding', '').lower()
    raw = decode_chunked(body) if chunked else body
    forged = forge_config(raw) if raw is not None else None
    if forged is None:
        log('CONFIG %s: nothing to flip, serving it genuine' % path)
        return head_block + body
    log('CONFIG %s: pay gates flipped free' % path)
    return forged


def unusable_reason(path):
    """Why a cached answer may not be served again, or '' while it is still good."""
    try:
        if time.time() - os.path.getmtime(path) > CACHE_TTL:
            return 'older than the cache lifetime'
        with open(path, 'rb') as handle:
            raw = handle.read()
    except OSError as error:
        return 'unreadable (%s)' % error
    head, separator, body = raw.partition(b'\r\n\r\n')
    if not separator:
        return 'stored without headers'
    code, fields = parse_head(head)
    if cache_ttl(code, fields) == 0:
        return 'live store data that must not be reused'
    declared = fields.get('content-length', '')
    if declared.isdigit() and len(body) != int(declared):
        return 'stored after a partial download'
    if 'chunked' in fields.get('transfer-encoding', '').lower() and decode_chunked(body) is None:
        return 'stored after a partial download'
    return ''


def prune_cache():
    """Clear cached answers that are stale or were stored from a partial read."""
    if not os.path.isdir(CACHE):
        return
    dropped = {}
    for name in sorted(os.listdir(CACHE)):
        path = os.path.join(CACHE, name)
        if not os.path.isfile(path):
            continue
        reason = unusable_reason(path)
        if reason:
            remove_file(path)
            dropped[reason] = dropped.get(reason, 0) + 1
    for reason, count in sorted(dropped.items()):
        log('Cleared %d cached answers: %s.' % (count, reason))


def read_request_head(conn):
    """Read a client's request head; empty when it sent nothing."""
    data = b''
    while b'\r\n\r\n' not in data and len(data) < 65536:
        piece = conn.recv(65536)
        if not piece:
            break
        data += piece
    return data


def read_request_body(conn, headers, leftover):
    """Read a client's request body as far as its Content-Length asks for.

    That length is a claim made by the client and the body is held in memory
    before it is forwarded, so the claim is capped: without a cap one request
    could ask this process to buffer however much it liked.
    """
    if not headers.get('content-length', '').isdigit():
        return b''
    wanted = int(headers['content-length'])
    if wanted > REQUEST_BODY_LIMIT:
        log('REFUSED a request body of %d bytes; only the first %d are forwarded.'
            % (wanted, REQUEST_BODY_LIMIT))
        wanted = REQUEST_BODY_LIMIT
    body = leftover
    while len(body) < wanted:
        piece = conn.recv(min(65536, wanted - len(body)))
        if not piece:
            break
        body += piece
    return body[:wanted]


def json_answer(payload):
    """A small forged JSON answer, framed for a connection that then closes.

    The body is serialised rather than pasted together, so a quote or a
    backslash in a value the client supplied cannot break the framing and hand
    the app a body it cannot parse.
    """
    body = json.dumps(payload, separators=(',', ':')).encode()
    return (b'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: '
            + str(len(body)).encode() + b'\r\nConnection: close\r\n\r\n' + body)


def forged_subscription(request_line):
    """Premium, always, for whichever account the store app asks about."""
    match = re.search(r'user_id=([A-Za-z0-9_-]+)', request_line)
    return json_answer({
        'package_title': 'Premium',
        'status': 'active',
        'expire_date': '07-10-2126',
        'user_id': match.group(1) if match else '0',
    })


def forged_login(form):
    """A successful login for whatever credentials the app offers."""
    fields = urllib.parse.parse_qs(form.decode('iso-8859-1', 'replace'))
    email = fields.get('email', [''])[0]
    user = re.sub(r'[^A-Za-z0-9_-]', '', email.split('@')[0]) or '0'
    return json_answer({
        'status': 'success',
        'user_id': user,
        'name': '',
        'email': email,
        'gender': '',
        'join_date': '',
        'last_login': '',
    })


def forge_config(raw):
    """Flip every pay gate in a genuine config body; None when there is none.

    The store sends this answer chunked, so the body must be unwrapped before it
    can be read as JSON; reading the framing as JSON is why the gates used to
    reach the app unfipped.
    """
    try:
        data = json.loads(raw.decode('utf-8'))
    except (ValueError, UnicodeDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    flipped = 0
    ads = data.get('ads_config')
    if isinstance(ads, dict):
        for key in ('DownloadMoviePaid', 'DownloadTvseriesPaid', 'TvPaymentEnabled'):
            if key in ads:
                ads[key] = '0'
                flipped += 1
    config = data.get('app_config')
    if isinstance(config, dict) and 'TitanUrl' in config:
        titan = config['TitanUrl'].replace('#free#false#free#', '#free#true#free#')
        titan = titan.replace('#upgrade#true#upgrade#', '#upgrade#false#upgrade#')
        if titan != config['TitanUrl']:
            config['TitanUrl'] = titan
            flipped += 1
    if not flipped:
        return None
    forged = json.dumps(data, separators=(',', ':')).encode()
    return (b'HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: '
            + str(len(forged)).encode() + b'\r\nConnection: close\r\n\r\n' + forged)


def handle_client(conn, addr):
    try:
        peer = conn.getpeername()[0]
    except OSError:
        peer = '?'
    try:
        conn.settimeout(REQUEST_TIMEOUT)
        head, _separator, leftover = read_request_head(conn).partition(b'\r\n\r\n')
        lines = head.decode('iso-8859-1', 'replace').split('\r\n')
        first = lines[0]
        request = first.split()
        method = request[0].upper() if request else 'GET'
        path = request[1] if len(request) > 1 else '/'
        headers = {}
        for line in lines[1:]:
            if ':' in line:
                name, _, value = line.partition(':')
                headers[name.strip().lower()] = value.strip()
        host = headers.get('host') or 'gamebatoapi.ir'
        log('%s %s %s' % (peer, host, first[:120]))
        if 'check_user_subscription_status' in first:
            conn.sendall(forged_subscription(first))
            return
        if re.search(r'/config[?&]', first):
            conn.sendall(relay_config(method, path, host, headers))
            return
        if '/login' in first:
            conn.sendall(forged_login(read_request_body(conn, headers, leftover)))
            return
        body = (read_request_body(conn, headers, leftover)
                if method in ('POST', 'PUT', 'PATCH') else b'')
        key = cache_key(host, path)
        if method == 'GET' and 'range' not in headers:
            hit = cached_answer(key)
            if hit:
                conn.sendall(hit)
                return
        relay(conn, method, path, host, headers, body, key)
    except OSError as error:
        log('ERR %s' % error)
    finally:
        try:
            conn.close()
        except OSError:
            pass


def serve(port):
    """Accept store traffic and answer each connection on its own thread.

    Like dns_server, this raises when the listener itself fails and only retries
    a single failed accept, so a panel that reports a running spoof always has
    a listener behind it.
    """
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(('0.0.0.0', port))
    server.listen(50)
    log('HTTP on %s:%s' % (SELF_IP, port))
    misses = 0
    while True:
        try:
            client, addr = server.accept()
        except OSError as error:
            misses += 1
            if misses >= 5:
                raise
            log('ERR the HTTP listener dropped a connection: %s' % error)
            continue
        misses = 0
        threading.Thread(target=handle_client, args=(client, addr), daemon=True).start()


HEALTH_FILE = os.path.join(DATA, 'engine_health.json')
HEALTH_TTL = 30  # panel treats a heartbeat older than this as a dead engine


def write_health(process_ok, dns_ok, http_ok, note=''):
    """One JSON heartbeat the panel reads for its three-dot health.

    process_ok: the engine process is alive (always True from in here).
    dns_ok: a loopback query for a store domain got the LAN address back.
    http_ok: a loopback subscription check got a forged Premium answer back.
    A crash leaves a stale file behind; HEALTH_TTL is what declares it dead.
    """
    try:
        with open(HEALTH_FILE, 'w', encoding='utf-8') as handle:
            json.dump({'at': time.time(), 'process': bool(process_ok),
                       'dns': bool(dns_ok), 'http': bool(http_ok),
                       'note': note[:200]}, handle)
    except OSError:
        pass


def probe_dns_self():
    """LAN-address DNS check: does our listener answer a store domain?

    The listener binds SELF_IP (not the wildcard) so it coexists with ICS,
    so the probe asks that same address -- loopback would miss the socket.
    """
    try:
        query = (b'\xab\xcd\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x0b'
                 b'gamebatoapi\x02ir\x00\x00\x01\x00\x01')
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(3)
        try:
            sock.sendto(query, (SELF_IP, DNS_PORT))
            answer, _ = sock.recvfrom(512)
        finally:
            sock.close()
        return (len(answer) >= 12 and answer[0:2] == b'\xab\xcd'
                and socket.inet_aton(SELF_IP) in answer)
    except (OSError, ValueError):
        return False


def probe_http_self():
    """Loopback HTTP check: does the relay forge a subscription verdict?"""
    try:
        sock = socket.create_connection(('127.0.0.1', HTTP_PORT), timeout=5)
        sock.settimeout(5)
        try:
            sock.sendall(b'GET /check_user_subscription_status?user_id=healthcheck '
                         b'HTTP/1.1\r\nHost: gamebatoapi.ir\r\n'
                         b'Connection: close\r\n\r\n')
            raw = b''
            while len(raw) < 65536:
                try:
                    piece = sock.recv(65536)
                except OSError:
                    break
                if not piece:
                    break
                raw += piece
        finally:
            sock.close()
        return b'"status":"active"' in raw
    except OSError:
        return False


def health_loop():
    """Refresh the heartbeat every 10s; each probe failure is its own dot."""
    while True:
        dns_ok, http_ok = probe_dns_self(), probe_http_self()
        note = ''
        if not dns_ok:
            note = 'DNS self-probe failed'
        elif not http_ok:
            note = 'HTTP self-probe failed'
        write_health(True, dns_ok, http_ok, note)
        time.sleep(10)


def read_health():
    """(process, dns, http, note, age_s) from the heartbeat, or all-False."""
    try:
        with open(HEALTH_FILE, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        age = time.time() - float(data.get('at', 0))
        if age > HEALTH_TTL:
            return False, False, False, 'heartbeat stale', age
        return (bool(data.get('process')), bool(data.get('dns')),
                bool(data.get('http')), str(data.get('note', ''))[:200], age)
    except (OSError, ValueError, TypeError):
        return False, False, False, 'no heartbeat yet', -1


def serve_forever(worker, name):
    """Run one serving loop until it fails, then say so and end the tap.

    Both loops run in daemon threads. A failure inside one of them would
    otherwise leave the panel showing a spoof that is running but answering
    nothing, so it is reported in the FATAL/FIX shape the dashboard already
    reads, and the process ends so the panel shows it stopped with the reason.
    """
    try:
        worker()
    except OSError as error:
        log('FATAL the %s listener stopped: %s' % (name, error))
        log('FIX Flip the switch off and on again; if it keeps failing, close whatever holds the port.')
        os._exit(2)


def main():
    upstream = option('upstream')
    if not upstream:
        bare = [arg for arg in sys.argv[1:] if not arg.startswith('--')]
        upstream = bare[0] if bare else probe_upstream(['8.8.8.8', '1.1.1.1', '9.9.9.9'])
    # Check the ports before the slow upstream probe so a failure is immediate
    # and explains itself in the dashboard instead of dying silently.
    try:
        ensure_ports_free(AUTO_FREE_PORTS)
    except PortInUse as error:
        log('FATAL %s' % error)
        if error.hint:
            log('FIX %s' % error.hint)
        raise SystemExit(2)
    prune_cache()
    write_health(True, False, False, 'starting listeners')
    threading.Thread(target=serve_forever, args=(functools.partial(dns_server, upstream), 'DNS'),
                     daemon=True).start()
    threading.Thread(target=serve_forever, args=(functools.partial(serve, HTTP_PORT), 'HTTP'),
                     daemon=True).start()
    threading.Thread(target=health_loop, daemon=True).start()
    log('VIP Spoof live. Point PS4 DNS at %s. Upstream DNS %s.' % (SELF_IP, upstream))
    if (ORIGIN_HOST, ORIGIN_PORT) != (REAL_HOST, REAL_PORT):
        log('Relaying store traffic to %s:%d instead of the real store.' % (ORIGIN_HOST, ORIGIN_PORT))
    while True:
        time.sleep(60)


if __name__ == '__main__':
    main()
