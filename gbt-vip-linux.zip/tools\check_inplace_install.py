"""Install through a real setup exe in a scratch folder and look at the result.

The wizard ships as one exe, so the only honest way to check where it installs
is to run one. This runs a *copy* of the setup inside a scratch folder and
points LOCALAPPDATA at a second scratch folder beside it, so the program lands
in the first and the install record in the second: neither of this machine's
real folders is written to.

    python tools/check_inplace_install.py <setup.exe> [scratch folder]

What it asserts:
  * the program lands beside the setup, in the folder the setup was run from
  * no GameVIP subfolder is made inside it
  * no install.txt (or any other file of ours) appears beside the setup
  * the install record goes to the per-user folder, and names that folder

The removal leg is deliberately not run here: a removal deletes this machine's
GameVIP firewall rules, whatever folder it is aimed at, and those belong to the
install the user actually has.
"""
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FAILURES = []
RECORD = os.path.join('GameBaToVipSpoof', 'install.txt')


def check(label, ok, detail=''):
    print('[%s] %s%s' % ('PASS' if ok else 'FAIL', label,
                         '' if ok else ' -- %s' % detail))
    if not ok:
        FAILURES.append(label)


def running_panel():
    """A GameVIP.exe process, which an install would end. Not our business."""
    try:
        out = subprocess.run(['tasklist', '/FI', 'IMAGENAME eq GameVIP.exe'],
                             stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                             timeout=60).stdout.decode('utf-8', 'replace')
    except (OSError, subprocess.SubprocessError):
        return False
    return 'GameVIP.exe' in out


def main(argv):
    setup = os.path.abspath(argv[1] if len(argv) > 1
                            else os.path.join(ROOT, 'build', 'noadmin',
                                              'GameVIP-Setup-noadmin.exe'))
    scratch = os.path.abspath(argv[2] if len(argv) > 2
                              else os.path.join(ROOT, 'build', 'e2e-inplace'))
    if not os.path.isfile(setup):
        raise SystemExit('no such setup exe: %s' % setup)
    if running_panel():
        raise SystemExit('a GameVIP.exe is running; an install would close it, '
                         'so this check stops here')
    # Two folders: the one handed over, and the per-user folder this machine's
    # real one is swapped for. They are kept apart so the handover folder can
    # be listed as a whole.
    local = scratch + '-userdata'
    for folder in (scratch, local):
        shutil.rmtree(folder, ignore_errors=True)
    os.makedirs(scratch)
    os.makedirs(local)

    planted = os.path.join(scratch, 'GameVIP-Setup.exe')
    shutil.copy2(setup, planted)
    # Only the per-user data folder is redirected. Pointing USERPROFILE at the
    # scratch folder as well makes Tk (which the wizard imports) create its own
    # AppData folder there, which is an artefact of the harness, not an install.
    env = dict(os.environ)
    env['LOCALAPPDATA'] = local
    command = [planted, '--silent', '--no-firewall', '--no-startmenu',
               '--no-desktop', '--no-autostart']
    print('=== %s' % ' '.join(command))
    finished = subprocess.run(command, cwd=scratch, env=env,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              timeout=600)
    output = finished.stdout.decode('utf-8', 'replace')
    print(output.strip()[-2000:])

    check('the setup ran and reported success', finished.returncode == 0,
          'exit %d' % finished.returncode)
    listed = sorted(os.listdir(scratch))
    check('the program lands in the folder the setup was run from',
          os.path.isfile(os.path.join(scratch, 'GameVIP.exe')),
          repr(listed))
    check('no GameVIP subfolder is made', 'GameVIP' not in listed, repr(listed))
    check('no install.txt beside the setup',
          not os.path.isfile(os.path.join(scratch, 'install.txt')), repr(listed))
    check('the folder holds the program and the setup and nothing else',
          listed == ['GameVIP-Setup.exe', 'GameVIP.exe'], repr(listed))
    check('no shortcut was written for the scratch install',
          not any(name.endswith('.lnk') for name in listed), repr(listed))

    record = os.path.join(local, RECORD)
    check('the install record went to the per-user folder',
          os.path.isfile(record), record)
    if os.path.isfile(record):
        with open(record, encoding='utf-8') as handle:
            text = handle.read()
        check('the record names the folder the setup was run from',
              ('dir=%s' % scratch) in text, text.strip())
        check('the record says one program, with its digest',
              'panel_digest=' in text and 'engine_digest=' in text, '')
    print('\n%d failures.' % len(FAILURES))
    return 1 if FAILURES else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
