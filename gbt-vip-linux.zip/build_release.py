"""Build the whole release: icon, panel exe, engine exe, one-file setup exe.

    python build_release.py            build everything into release/
    python build_release.py --fast     skip the icon and reuse built exes

Each PyInstaller run is a separate step so a failure names what failed instead
of leaving a half-updated release/ folder. Nothing here is needed to run the
product; it only exists to rebuild the shipped files after a source change.
"""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
RELEASE = os.path.join(ROOT, 'release')
WORK = os.path.join(ROOT, 'build', 'work')
SPECS = os.path.join(ROOT, 'build')
ICON = os.path.join(ROOT, 'assets', 'gbt.ico')
PANEL = 'GameVIP.exe'
ENGINE = 'GBTVipTap-Engine.exe'
SETUP = 'GameVIP-Setup.exe'


def pyinstaller(name, script, extra):
    """Run one PyInstaller build and fail loudly if it did not produce a file."""
    command = [sys.executable, '-m', 'PyInstaller', '--noconfirm', '--onefile',
               '--noconsole', '--name', name, '--icon', ICON,
               '--distpath', RELEASE, '--workpath', WORK, '--specpath', SPECS]
    command += extra + [script]
    print('=== %s' % name, flush=True)
    finished = subprocess.run(command, cwd=ROOT)
    if finished.returncode != 0:
        raise SystemExit('PyInstaller failed for %s (exit %d)' % (name, finished.returncode))
    built = os.path.join(RELEASE, name + '.exe')
    if not os.path.isfile(built):
        raise SystemExit('%s was not written to %s' % (name, RELEASE))
    return built


def size_text(path):
    return '%.1f MB' % (os.path.getsize(path) / (1024 * 1024.0))


def main():
    fast = '--fast' in sys.argv[1:]
    os.makedirs(RELEASE, exist_ok=True)
    os.makedirs(WORK, exist_ok=True)
    os.makedirs(SPECS, exist_ok=True)

    if not fast:
        print('=== icon', flush=True)
        subprocess.run([sys.executable, os.path.join(ROOT, 'tools', 'make_icon.py')],
                       cwd=ROOT, check=True)

    panel = os.path.join(RELEASE, PANEL)
    engine = os.path.join(RELEASE, ENGINE)
    if not fast or not os.path.isfile(engine):
        engine = pyinstaller('GBTVipTap-Engine', os.path.join(ROOT, 'tap.py'), [])
    if not fast or not os.path.isfile(panel):
        # Single-exe install: the engine rides inside the panel's bundle, so
        # the installed folder holds one program and the setup ships one file.
        panel = pyinstaller(os.path.splitext(PANEL)[0], os.path.join(ROOT, 'app.py'), [
            '--add-binary', '%s;.' % engine,
            # The control window's branding art and its own icon. The setup
            # ships the same folder for its pages, so both windows read as one
            # product; nothing else from assets/ is carried in here. The
            # branding_t copy is the same artwork with its frame composited
            # into the window's grey, which the window prefers.
            '--add-data', '%s%sassets%cbranding' % (os.path.join(ROOT, 'assets', 'branding'),
                                                    os.pathsep, os.sep),
            '--add-data', '%s%sassets%cbranding_t' % (os.path.join(ROOT, 'assets', 'branding_t'),
                                                      os.pathsep, os.sep),
            '--add-data', '%s%sassets' % (ICON, os.pathsep),
        ])

    setup = pyinstaller(os.path.splitext(SETUP)[0], os.path.join(ROOT, 'setup_wizard.py'), [
        '--uac-admin',                                   # one consent prompt, at install time
        '--add-binary', '%s;.' % panel,
        '--add-data', '%s;.' % os.path.join(ROOT, 'README.md'),
        '--add-data', '%s;.' % ICON,
        # Reference artwork the installer paints at runtime: logo, hero,
        # branding, row icons, sidebar fragments. Lands in bundle/assets/.
        '--add-data', '%s%sassets' % (os.path.join(ROOT, 'assets'), os.pathsep),
    ])

    print('\nBuilt into %s:' % RELEASE, flush=True)
    import hashlib
    sums = []
    for name in (PANEL, ENGINE, SETUP):
        path = os.path.join(RELEASE, name)
        print('  %-28s %s' % (name, size_text(path) if os.path.isfile(path) else 'MISSING'),
              flush=True)
        if os.path.isfile(path):
            digest = hashlib.sha256()
            with open(path, 'rb') as handle:
                for chunk in iter(lambda: handle.read(1048576), b''):
                    digest.update(chunk)
            sums.append('%s  %s' % (digest.hexdigest(), name))
    # What the folder shows: the one program beside the setup that installs it,
    # and the setup itself. The panel still rides inside the setup and still
    # installs as one file, but it is also left standing here, so the program
    # can be run from this folder without installing anything -- and so the
    # folder handed over holds the program, not just a way to get it. Staged
    # copies stay under build/ for source-run installs and the checks.
    import shutil
    stage = os.path.join(ROOT, 'build', 'stage')
    os.makedirs(stage, exist_ok=True)
    for name in (PANEL, ENGINE):
        staged = os.path.join(stage, name)
        try:
            if os.path.isfile(os.path.join(RELEASE, name)):
                shutil.copy2(os.path.join(RELEASE, name), staged)
        except OSError:
            pass
    # The engine rides inside the panel's bundle, so the loose copy is only a
    # build input: it stays out of the released folder.
    try:
        if os.path.isfile(os.path.join(RELEASE, ENGINE)):
            os.remove(os.path.join(RELEASE, ENGINE))
    except OSError:
        pass
    # Only the files that stay in the folder: the engine was just removed, and
    # a sum for a file that is not there is worse than no sum at all.
    sums = [line for line in sums if not line.endswith('  ' + ENGINE)]
    with open(os.path.join(RELEASE, 'SHA256SUMS.txt'), 'w', encoding='utf-8') as handle:
        handle.write('\n'.join(sums) + '\n')
    print('  %-28s written' % 'SHA256SUMS.txt', flush=True)
    print('  NOTE: exes are unsigned. Publisher identity needs an Authenticode',
          flush=True)
    print('  cert (signtool sign /fd SHA256 /a <exe>); the sums above only prove',
          flush=True)
    print('  the files stopped changing, not who built them.', flush=True)
    if not os.path.isfile(setup):
        raise SystemExit('The setup exe is missing.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
