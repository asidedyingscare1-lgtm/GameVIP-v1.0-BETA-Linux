#!/usr/bin/env bash
# GameVIP — run from source on Linux. Mirrors TAP.bat on Windows.
#
#   ./tap.sh              panel + control window, opens the page when ready
#   ./tap.sh --headless   page only, no Tk window (scripts / services)
#
# Needs: python3 (3.9+) + python3-tk for the window. Ports 53/80 need one
# grant — install.sh sets the setcap bit so day-to-day runs need no sudo.
# Anything this script would have printed lands in panel.log beside it.
set -euo pipefail
cd "$(dirname "$0")"

PY=""
for cmd in python3 python; do
    if command -v "$cmd" >/dev/null 2>&1; then PY="$cmd"; break; fi
done
if [ -z "$PY" ]; then
    echo "Python 3.9+ is required. Install it (sudo apt install python3 python3-tk), then run ./tap.sh again." >&2
    exit 1
fi

if ! "$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)'; then
    echo "Python 3.9+ is required (found $("$PY" --version 2>&1))." >&2
    exit 1
fi

HEADLESS=0
for arg in "$@"; do
    [ "$arg" = "--headless" ] && HEADLESS=1
done
if [ "$HEADLESS" -eq 0 ] && ! "$PY" -c 'import tkinter' 2>/dev/null; then
    echo "python3-tk is missing — the control window needs it." >&2
    echo "Install: sudo apt install python3-tk   (or run ./tap.sh --headless for page-only)" >&2
    exit 1
fi

# Ports 53/80 under 1024: without the setcap bit (or root) the bind fails
# with a FATAL the panel then shows. Say it up front instead.
CAN_BIND=0
if "$PY" -c 'import socket; s=socket.socket(); s.bind(("127.0.0.1", 80)); s.close()' 2>/dev/null; then
    CAN_BIND=1
elif [ -x ./gamevip-panel ] && getcap ./gamevip-panel 2>/dev/null | grep -q cap_net_bind_service; then
    CAN_BIND=1
fi
if [ "$CAN_BIND" -eq 0 ] && [ "$(id -u)" -ne 0 ]; then
    echo "NOTE: binding ports 53/80 needs one grant. Run ./install.sh once (sets setcap), or run with sudo." >&2
fi

# Headless, like TAP.bat's pythonw: no console stays open, output to panel.log.
nohup "$PY" app.py "$@" >> panel.log 2>&1 &
PANEL_PID=$!

# Wait for the panel to answer before opening it — never land on a refusal.
for _ in $(seq 1 50); do
    if "$PY" -c 'import socket; socket.create_connection(("127.0.0.1", 8899), timeout=1).close()' 2>/dev/null; then
        break
    fi
    sleep 0.3
done

if command -v xdg-open >/dev/null 2>&1; then
    xdg-open 'http://127.0.0.1:8899/' >/dev/null 2>&1 &
elif command -v sensible-browser >/dev/null 2>&1; then
    sensible-browser 'http://127.0.0.1:8899/' >/dev/null 2>&1 &
else
    echo "Open http://127.0.0.1:8899/ in your browser." >&2
fi

echo "Panel running (PID $PANEL_PID). Close its window or run: kill $PANEL_PID"
wait "$PANEL_PID"
