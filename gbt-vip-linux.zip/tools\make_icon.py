"""Build assets/gbt.ico and assets/gamevip.ico from the hooded logo.

Windows draws an icon over whatever is behind it: white in a light Explorer, a
dark tone in a dark one. The logo ships as artwork painted on a flat black
plate, which shows up as a black square against any of them, so the plate is
keyed *out* here rather than composited into a tone.

Only alpha changes. The flood starts at the frame's edge and stops where the
artwork begins, so every surviving pixel keeps the logo's own colour, and the
figure, its glow and the ring are carried through untouched. Sizes are made by
premultiplied resampling, so no dark fringe bleeds into the soft edge.

The hood then sits on the panel's own mark tile -- the one the dashboard paints
beside its title (app.py's .mark rule: a #03090c rounded square, a 1px green
rim and a soft green glow) -- so the icon reads the way the product already
looks instead of as a bare cut-out. Set TILE to 'none' for the bare hood.

Run: python tools/make_icon.py

Uses PIL when available; falls back to the drawn phosphor mark when PIL or the
logo is missing, so the build never fails on a fresh checkout.
"""
import os
import struct
from collections import deque

SIZES = (16, 24, 32, 48, 64, 128, 256)
SOURCES = (('gbt.ico', 'logo.png'), ('gamevip.ico', 'gamevip-logo.png'))
TOLERANCE = 8   # how far from the plate's own colour still counts as plate
FEATHER = 2     # pixels of alpha ramp where the artwork meets the keyed plate

# The mark tile, copied from app.py's .mark rule rather than imported (that
# file is a stdlib program with no importable stylesheet), so the icon and the
# dashboard cannot drift apart silently.
TILE = 'mark'
MARK_FILL = '#03090c'        # .mark{background-color:#03090c}
MARK_INK = '#63dca6'         # .mark{border:1px solid rgba(99,220,166,.45)}
MARK_RIM = 0.45              # ...that border's alpha
MARK_RADIUS = 15 / 52.0      # .mark{border-radius:15px} on a 52px tile
MARK_GLOW = 0.25             # .mark{box-shadow:0 0 22px rgba(99,220,166,.25)}
MARK_SIDE = 0.86             # the tile's share of the icon, its glow the rest

# Small sizes get their own treatment, because the composition above is drawn
# for 48px and up. Downscaled to 16 or 32, the hood's detail is a couple of
# pixels wide and its own colours are dark on a dark tile: what is left in an
# Explorer list is a murky square. Below SMALL_MAX the rim is drawn thicker and
# brighter, the artwork is lifted so its red ring and eyes carry, and the outer
# glow is dropped, because a halo at that size is just haze around the shape.
SMALL_MAX = 32
SMALL_RIM = 3 / 52.0         # rim width at small sizes, in tile units
SMALL_RIM_ALPHA = 0.9
SMALL_GAIN = 1.9             # how much the artwork is brightened


# -- keying ------------------------------------------------------------------

def plate_colour(pixels, width, height):
    """The backdrop's own colour: the median of the four corners."""
    corners = (pixels[0, 0], pixels[width - 1, 0],
               pixels[0, height - 1], pixels[width - 1, height - 1])
    return tuple(sorted(colour[index] for colour in corners)[1]
                 for index in range(3))


def key_plate(image, tolerance=TOLERANCE, feather=FEATHER):
    """Alpha-key the flat plate: return an RGBA copy, colours unchanged."""
    rgba = image.convert('RGBA')
    width, height = rgba.size
    pixels = rgba.load()
    base = plate_colour(pixels, width, height)

    def plate(pixel):
        return all(abs(pixel[index] - base[index]) <= tolerance
                   for index in range(3))

    # Flood inward from the frame's edge. It stops at the first pixel that is
    # not plate, which is where the artwork starts; enclosed plate (inside the
    # ring) stays put, because the ring blocks the water.
    seen = bytearray(width * height)
    keyed = bytearray(width * height)
    stack = []
    for x in range(width):
        stack += [x, (height - 1) * width + x]
    for y in range(height):
        stack += [y * width, y * width + width - 1]
    while stack:
        index = stack.pop()
        if seen[index]:
            continue
        seen[index] = 1
        x, y = index % width, index // width
        pixel = pixels[x, y]
        if not plate(pixel):
            continue
        keyed[index] = 1
        pixels[x, y] = (pixel[0], pixel[1], pixel[2], 0)
        if x > 0:
            stack.append(index - 1)
        if x + 1 < width:
            stack.append(index + 1)
        if y > 0:
            stack.append(index - width)
        if y + 1 < height:
            stack.append(index + width)

    # Soft edge: ramp alpha up over a couple of pixels so the seam does not
    # survive the downscale as a dark outline.
    handled = bytearray(keyed)
    frontier = [index for index in range(len(keyed)) if keyed[index]]
    for step in range(1, feather):
        alpha = 255 * step // feather
        following = []
        for index in frontier:
            x, y = index % width, index // width
            for nx, ny in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
                if not (0 <= nx < width and 0 <= ny < height):
                    continue
                neighbour = ny * width + nx
                if handled[neighbour]:
                    continue
                handled[neighbour] = 1
                pixels[nx, ny] = (pixels[nx, ny][0], pixels[nx, ny][1],
                                  pixels[nx, ny][2], alpha)
                following.append(neighbour)
        frontier = following
    return rgba


# -- the mark tile ------------------------------------------------------------

def _hex(text):
    """'#rrggbb' as an integer triple."""
    return tuple(int(text[index:index + 2], 16) for index in (1, 3, 5))


def _blend(under, over, cover):
    """over at `cover` alpha, laid on under."""
    return tuple(int(under[index] + (over[index] - under[index]) * cover)
                 for index in range(3))


def lift_art(image, gain):
    """The artwork brightened, alpha untouched.

    Alpha only ever gets more opaque, never less, so a lifted pixel can never
    leak into the transparent corners.
    """
    from PIL import Image
    red, green, blue, alpha = image.split()

    def boost(band):
        return band.point(lambda value: min(255, int(round(value * gain))))

    return Image.merge('RGBA', (boost(red), boost(green), boost(blue), alpha))


def mark_tile(keyed, size):
    """The keyed hood on the panel's own tile, corners left transparent."""
    from PIL import Image, ImageDraw, ImageFilter
    small = size <= SMALL_MAX
    side = max(6, int(round(size * MARK_SIDE)))
    left = (size - side) // 2
    radius = int(round(side * MARK_RADIUS))
    # the 1px border at 52px; thicker at sizes where 1px would vanish
    rim = (max(2, int(round(side * SMALL_RIM))) if small
           else max(1, int(round(side * 2 / 52.0))))
    box = [left, left, left + side - 1, left + side - 1]

    # The glow first: the rim's colour, spread past the tile and softened. At
    # small sizes it is skipped outright -- it costs the crisp edge that is the
    # only thing a 16px icon has to say.
    plate = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    ImageDraw.Draw(plate).rounded_rectangle(
        box, radius=radius, fill=_hex(MARK_FILL) + (255,))
    if small:
        tile = plate
    else:
        glow = Image.new('RGBA', (size, size), (0, 0, 0, 0))
        spread = max(1, int(round(size * 0.05)))
        ImageDraw.Draw(glow).rounded_rectangle(
            [box[0] - spread, box[1] - spread, box[2] + spread, box[3] + spread],
            radius=radius + spread, fill=_hex(MARK_INK) + (255,))
        glow = glow.filter(ImageFilter.GaussianBlur(spread * 1.4))
        glow.putalpha(glow.getchannel('A').point(
            lambda cover: int(cover * MARK_GLOW)))
        tile = Image.alpha_composite(glow, plate)

    # The keyed hood inside the tile: the art's own black plate is gone, so the
    # tile shows through the cloak and no seam appears where the plate ended.
    hood = resize_rgba(keyed, side)
    tile.alpha_composite(lift_art(hood, SMALL_GAIN) if small else hood,
                         (left, left))

    ImageDraw.Draw(tile).rounded_rectangle(
        box, radius=radius, width=rim,
        outline=_blend(_hex(MARK_FILL), _hex(MARK_INK),
                       SMALL_RIM_ALPHA if small else MARK_RIM) + (255,))

    # The glow spreads past the tile, so the icon's own corners would carry a
    # few percent of it and no longer be transparent at all. Clip the four
    # corner curves away: they are the furthest points from the tile, where the
    # halo is faintest, so nothing visible is lost and Explorer gets a clean
    # cut-out on every background.
    from PIL import ImageChops
    corners = Image.new('L', (size, size), 0)
    ImageDraw.Draw(corners).rounded_rectangle(
        [0, 0, size - 1, size - 1], radius=int(round(size * MARK_RADIUS)),
        fill=255)
    tile.putalpha(ImageChops.multiply(tile.getchannel('A'), corners))
    return tile


# -- sizes -------------------------------------------------------------------

def resize_rgba(image, size):
    """Resample to size x size with premultiplied alpha (no dark fringe)."""
    from PIL import Image, ImageChops
    red, green, blue, alpha = image.split()
    premultiplied = Image.merge('RGBA', (
        ImageChops.multiply(red, alpha), ImageChops.multiply(green, alpha),
        ImageChops.multiply(blue, alpha), alpha))
    small = premultiplied.resize((size, size), Image.LANCZOS)
    red, green, blue, alpha = small.split()
    channels = (red.load(), green.load(), blue.load(), alpha.load())
    flat = []
    for y in range(size):
        for x in range(size):
            cover = channels[3][x, y]
            if cover == 0:
                flat.append((0, 0, 0, 0))
                continue
            # premultiplied colour back to straight, then clamped
            flat.append((min(255, channels[0][x, y] * 255 // cover),
                         min(255, channels[1][x, y] * 255 // cover),
                         min(255, channels[2][x, y] * 255 // cover), cover))
    out = Image.new('RGBA', (size, size))
    out.putdata(flat)
    return out


# -- container ---------------------------------------------------------------

def bmp_entry(size, colour):
    """One 32-bit icon image, bottom-up BGRA plus the (unused) AND mask."""
    header = struct.pack('<IiiHHIIiiII', 40, size, size * 2, 1, 32, 0,
                         size * size * 4, 0, 0, 0, 0)
    body = bytearray()
    for y in range(size - 1, -1, -1):
        for x in range(size):
            red, green, blue, alpha = colour((x, y))
            body += bytes((blue, green, red, alpha))
    mask_row = ((size + 31) // 32) * 4
    return header + bytes(body) + bytes(mask_row * size)


def write_icon(target, payloads):
    """Write a multi-size icon from (size, image bytes) pairs."""
    out = bytearray(struct.pack('<HHH', 0, 1, len(payloads)))
    offset = 6 + 16 * len(payloads)
    for size, payload in payloads:
        out += struct.pack('<BBBBHHII', size % 256, size % 256, 0, 0, 1, 32,
                           len(payload), offset)
        offset += len(payload)
    for _, payload in payloads:
        out += payload
    with open(target, 'wb') as handle:
        handle.write(out)
    return len(out)


def from_logo(target, logo_path):
    """Key the logo's plate and write every size, alpha intact."""
    from PIL import Image
    keyed = key_plate(Image.open(logo_path))
    payloads = []
    for size in SIZES:
        small = (mark_tile(keyed, size) if TILE == 'mark'
                 else resize_rgba(keyed, size))
        if size >= 256:
            # Windows reads a PNG payload from Vista on; it keeps the entry
            # a fraction of the size of raw 32-bit pixels.
            import io
            buffer = io.BytesIO()
            small.save(buffer, 'PNG')
            payloads.append((size, buffer.getvalue()))
        else:
            payloads.append((size, bmp_entry(size, small.load().__getitem__)))
    written = write_icon(target, payloads)
    cover = keyed.getchannel('A').histogram()[0]
    print('Wrote %s from %s (%d bytes, %d sizes, %.0f%% of the plate keyed '
          'out, tile %s, small sizes <= %dpx lifted %.1fx)'
          % (target, os.path.basename(logo_path), written, len(SIZES),
             100.0 * cover / (keyed.size[0] * keyed.size[1]), TILE,
             SMALL_MAX, SMALL_GAIN))


# -- no-PIL / no-logo fallback ----------------------------------------------

def pixel(size, x, y):
    cx = cy = (size - 1) / 2.0
    radius = size * 0.44
    dx, dy = x - cx, y - cy
    distance = (dx * dx + dy * dy) ** 0.5
    if distance > radius + 0.75:
        return None
    if distance > radius:
        return (24, 78, 54, 128)
    ring_mid = size * 0.30
    ring_half = max(0.8, size * 0.055)
    if abs(distance - ring_mid) <= ring_half:
        return (74, 232, 148, 255)
    if distance <= size * 0.11:
        return (196, 255, 222, 255)
    return (5, 16, 12, 255)


def fallback(target):
    payloads = []
    for size in SIZES:
        payloads.append((size, bmp_entry(
            size, lambda position, size=size: (pixel(size, position[0],
                                                      position[1])
                                                or (0, 0, 0, 0)))))
    written = write_icon(target, payloads)
    print('Wrote %s (%d bytes, fallback mark)' % (target, written))


def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for target_name, logo_name in SOURCES:
        target = os.path.join(root, 'assets', target_name)
        logo = os.path.join(root, 'assets', logo_name)
        if os.path.isfile(logo):
            try:
                from_logo(target, logo)
                continue
            except Exception as error:
                print('Logo build failed for %s (%s); using fallback.'
                      % (target_name, error))
        fallback(target)


if __name__ == '__main__':
    main()
