"""Full verification suite for the 10-findings pass. stdlib only.

Run:  python verify_all.py   (exit 0 = all green, exit 1 = failures listed)
Covers: compile, log scrub, health fns, marker digests, shortcut guard,
rollback ledger, uninstall allowlist, firewall scope, health wiring,
privilege flag, panel bind, engine binds, DNS copy, crash sweep, sums,
wizard timers, dashboard launch toggle.

The live half of the wizard checks -- timers, launch toggle, open flow -- runs
in tools/check_launch_flow.py, which drives the real window with fakes.
"""
import os
import py_compile
import re
import sys
import tempfile

ROOT = os.path.dirname(os.path.abspath(__file__))
FAILURES = []


def check(name, condition, detail=''):
    status = 'PASS' if condition else 'FAIL'
    print('[%s] %s%s' % (status, name, (' -- ' + detail) if detail else ''),
          flush=True)
    if not condition:
        FAILURES.append(name)


def read(name):
    with open(os.path.join(ROOT, name), 'r', encoding='utf-8') as handle:
        return handle.read()


def _resource_blob(path, kind):
    """The first resource of one kind inside a PE, or None off Windows.

    Read through the resource API rather than by parsing the file: this is the
    same view Explorer and the shell take, so an icon that is here is the icon
    that shows.
    """
    import ctypes
    if os.name != 'nt':
        return None
    k32 = ctypes.windll.kernel32
    k32.LoadLibraryExW.restype = ctypes.c_void_p
    k32.FindResourceW.restype = ctypes.c_void_p
    k32.FindResourceW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
    k32.SizeofResource.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    k32.LoadResource.restype = ctypes.c_void_p
    k32.LoadResource.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    k32.LockResource.restype = ctypes.c_void_p
    k32.LockResource.argtypes = [ctypes.c_void_p]
    handle = k32.LoadLibraryExW(str(path), None, 0x2)   # LOAD_LIBRARY_AS_DATAFILE
    if not handle:
        return None
    found = []

    def collect(module, group, name, _param):
        if not found and (group or 0) == kind:
            res = k32.FindResourceW(module, name, ctypes.c_void_p(kind))
            if res:
                size = k32.SizeofResource(module, res)
                found.append(ctypes.string_at(
                    k32.LockResource(k32.LoadResource(module, res)), size))
        return 1

    callback = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_void_p,
                                  ctypes.c_void_p, ctypes.c_void_p,
                                  ctypes.c_void_p)(collect)
    k32.EnumResourceNamesW(ctypes.c_void_p(handle), ctypes.c_void_p(kind),
                           callback, None)
    k32.FreeLibrary(ctypes.c_void_p(handle))
    return found[0] if found else None


def ico_sizes(path):
    """(width, height) for every image in an .ico file."""
    import struct
    with open(path, 'rb') as handle:
        blob = handle.read()
    sizes = []
    for index in range(struct.unpack_from('<H', blob, 4)[0]):
        width, height = struct.unpack_from('<BB', blob, 6 + index * 16)
        sizes.append((width or 256, height or 256))
    return sizes


def exe_icon_sizes(path):
    """(width, height) for every image in an exe's own icon group."""
    import struct
    blob = _resource_blob(path, 14)                     # RT_GROUP_ICON
    if not blob:
        return None
    sizes = []
    for index in range(struct.unpack_from('<H', blob, 4)[0]):
        width, height = struct.unpack_from('<BB', blob, 6 + index * 14)
        sizes.append((width or 256, height or 256))
    return sizes


def exe_manifest(path):
    """An exe's manifest text, which is where the elevation request lives."""
    blob = _resource_blob(path, 24)                     # RT_MANIFEST
    return blob.decode('utf-8', 'replace') if blob else None


def main():
    # 0. everything compiles
    try:
        for name in ('app.py', 'tap.py', 'setup_wizard.py', 'build_release.py'):
            py_compile.compile(os.path.join(ROOT, name), doraise=True)
        check('compile all four files', True)
    except py_compile.PyCompileError as error:
        check('compile all four files', False, str(error))
        return 1

    sys.path.insert(0, ROOT)
    import tap
    import setup_wizard

    # 8. log scrub
    scrubbed = tap.scrub_line(
        'GET /check?user_id=abc123&password=hunter2&token=xyz user@host.com')
    check('scrub user_id', 'user_id=[redacted]' in scrubbed, scrubbed)
    check('scrub password', 'hunter2' not in scrubbed, scrubbed)
    check('scrub token', 'xyz' not in scrubbed, scrubbed)
    check('scrub email', 'user@host.com' not in scrubbed, scrubbed)
    check('scrub keeps keys', 'password=[redacted]' in scrubbed, scrubbed)

    # 7. health functions exist and behave
    check('health fns present',
          all(callable(getattr(tap, name, None)) for name in (
              'write_health', 'probe_dns_self', 'probe_http_self',
              'read_health', 'health_loop')), '')
    tap.write_health(True, True, True, 'verify probe')
    process, dns, http, note, age = tap.read_health()
    check('heartbeat round-trip', process and dns and http, note)
    check('heartbeat fresh', 0 <= age < tap.HEALTH_TTL, '%.1fs' % age)
    tap.write_health(True, False, True, 'DNS self-probe failed')
    _, dns2, _, note2, _ = tap.read_health()
    check('dns failure distinct from http', not dns2, note2)
    # stale heartbeat reads dead
    import json
    import time
    with open(tap.HEALTH_FILE, 'w', encoding='utf-8') as handle:
        json.dump({'at': time.time() - 999, 'process': True,
                   'dns': True, 'http': True, 'note': ''}, handle)
    stale = tap.read_health()
    check('stale heartbeat reads dead',
          stale[:3] == (False, False, False), stale[3])
    os.remove(tap.HEALTH_FILE)

    # 9. marker preserves digests, bools stay 0/1
    tmp = tempfile.mkdtemp()
    try:
        setup_wizard.MARKER_FILE = 'install.txt'
        orig_marker = setup_wizard.marker_path
        setup_wizard.marker_path = lambda d: os.path.join(d, 'install.txt')
        setup_wizard.write_marker(tmp, {'desktop': True, 'firewall': False,
                                        'panel_digest': 'abcdef1234567890',
                                        'engine_digest': '0987654321fedcba'})
        with open(os.path.join(tmp, 'install.txt'), encoding='utf-8') as h:
            marker = h.read()
        check('marker digest preserved', 'abcdef1234567890' in marker, marker.strip())
        check('marker bools numeric',
              'desktop=1' in marker and 'firewall=0' in marker, '')
        check('marker round-trip', setup_wizard.read_marker(tmp).get('panel_digest') == 'abcdef1234567890', '')
    finally:
        setup_wizard.marker_path = orig_marker
        try:
            os.remove(os.path.join(tmp, 'install.txt'))
            os.rmdir(tmp)
        except OSError:
            pass

    # 6. shortcut guard + long-path fix
    src = read('setup_wizard.py')
    check('long_path helper present', 'def long_path(' in src, '')
    check('guard uses long_path', 'long_path(install_dir)' in src, '')
    check('uninstall allowlist present',
          all(token in src for token in (
              'Only product files go', "'engine_health.json'",
              'kept %d file(s)')), '')

    # 5. rollback ledger
    check('rollback ledger', 'made = {' in src and "'shortcuts'" in src, '')
    check('rollback function', 'def rollback(log)' in src, '')
    check('rollback re-raises', 'raise' in src[src.index('def rollback(log)'):src.index('def rollback(log)') + 4000], '')

    # 3. firewall scope
    app_src = read('app.py')
    check('panel rules localsubnet', 'remoteip=localsubnet' in app_src, '')
    check('setup rules localsubnet',
          "'remoteip=localsubnet'" in src or '"remoteip=localsubnet"' in src or 'remoteip=localsubnet' in src, '')
    check('panel binds loopback only',
          "ThreadingHTTPServer(('127.0.0.1', port)" in app_src, '')

    # 7b. health wired into panel payload + page + JS
    check('payload carries health',
          all(k in app_src for k in (
              "'health_process'", "'health_dns'", "'health_http'",
              "'health_note'")), '')
    check('health text helper', 'def health_text(' in app_src, '')

    # 1. privilege flag
    check('elevated in payload', "'elevated': elevated" in app_src, '')

    # 9b. digests in payload + sums in build
    check('digests in payload',
          'panel_digest' in app_src and 'engine_digest' in app_src, '')
    build_src = read('build_release.py')
    check('sums manifest in build', 'SHA256SUMS.txt' in build_src, '')
    check('signing noted', 'Authenticode' in build_src, '')

    # 2. DNS copy honest
    check('secondary bypass note',
          'Secondary stays 1.1.1.1' in app_src, '')
    check('expected-not-leak note',
          'expected, not a leak' in app_src, '')

    # 4. crash sweep on start
    check('orphan sweep on start',
          'release_engine_ports()' in app_src
          and 'Cleared an engine left behind by a crash' in app_src, '')

    # engine binds: wildcard HTTP + LAN-address DNS
    check('http binds wildcard',
          "server.bind(('0.0.0.0', port))" in read('tap.py'), '')
    check('dns binds LAN address',
          'sock.bind((SELF_IP, DNS_PORT))' in read('tap.py'), '')

    # 13. the setup installs in its own folder when it can, and always falls
    # back to the per-user one. It does not make a GameVIP subfolder: the folder
    # handed over holds the setup and the program side by side.
    here = setup_wizard.app_dir()
    check('the folder the setup was started from can host an install',
          setup_wizard.can_host_install(here) or not os.access(here, os.W_OK),
          here)
    if setup_wizard.can_host_install(here):
        check("the install sits in the setup's own folder",
              setup_wizard.default_install_dir() == here,
              setup_wizard.default_install_dir())
        check('no GameVIP subfolder is made beside it',
              setup_wizard.default_install_dir()
              != os.path.join(here, setup_wizard.LEGACY_INSTALL_FOLDER),
              setup_wizard.default_install_dir())
    else:
        check('the install falls back to the per-user folder',
              setup_wizard.default_install_dir() == setup_wizard.local_install_dir(),
              setup_wizard.default_install_dir())
    check('the per-user folder is still looked in',
          setup_wizard.local_install_dir() in setup_wizard.install_candidates(),
          '')
    check('an install left in the older GameVIP subfolder is still found',
          os.path.join(here, setup_wizard.LEGACY_INSTALL_FOLDER)
          in setup_wizard.install_candidates(), '')
    check('installing sweeps that older subfolder away',
          'def tidy_legacy_install_folder(' in src
          and 'tidy_legacy_install_folder(target, log)' in src, '')
    check('the program is never copied onto itself',
          'os.path.samefile(source, destination)' in src, '')
    check('temporary folders cannot host an install',
          not setup_wizard.can_host_install(tempfile.gettempdir()),
          tempfile.gettempdir())
    if os.environ.get('ProgramFiles'):
        check('system folders cannot host an install',
              not setup_wizard.can_host_install(os.environ['ProgramFiles']),
              os.environ['ProgramFiles'])
    try:
        sys_shipped_in_release = os.path.join(ROOT, 'release',
                                              'GameVIP-Setup.exe')
        real_executable = sys.executable
        setup_wizard.sys.frozen = True          # what a bundled setup sees
        setup_wizard.sys.executable = sys_shipped_in_release
        resolved = setup_wizard.default_install_dir()
    finally:
        setup_wizard.sys.frozen = False
        setup_wizard.sys.executable = real_executable
    if setup_wizard.can_host_install(os.path.join(ROOT, 'release')):
        check('a setup run from release installs into release itself',
              resolved == os.path.join(ROOT, 'release'), resolved)

    # release artifacts: the program itself beside the setup that installs it,
    # which is the folder that gets handed over. The engine is not loose in
    # there -- it rides inside the panel's bundle.
    for name in ('GameVIP.exe', 'GameVIP-Setup.exe', 'SHA256SUMS.txt'):
        check('release has ' + name,
              os.path.isfile(os.path.join(ROOT, 'release', name)), '')
    check('release holds the program beside the setup',
          sorted(os.path.basename(path) for path in
                 __import__('glob').glob(os.path.join(ROOT, 'release', '*.exe')))
          == ['GameVIP-Setup.exe', 'GameVIP.exe'], '')
    check('the loose engine stays out of the released folder',
          not os.path.isfile(os.path.join(ROOT, 'release', 'GBTVipTap-Engine.exe')),
          '')

    # sums match the actual files
    import hashlib
    sums_path = os.path.join(ROOT, 'release', 'SHA256SUMS.txt')
    try:
        with open(sums_path, encoding='utf-8') as handle:
            lines = [line.strip() for line in handle if line.strip()]
        ok = True
        for line in lines:
            digest, name = line.split(None, 1)
            path = os.path.join(ROOT, 'release', name.strip())
            hasher = hashlib.sha256()
            with open(path, 'rb') as handle:
                for chunk in iter(lambda: handle.read(1048576), b''):
                    hasher.update(chunk)
            if hasher.hexdigest() != digest:
                ok = False
        # One line per file that stays in the folder: the program and the setup.
        check('sums match files', ok and len(lines) == 2,
              '%d lines' % len(lines))
    except OSError as error:
        check('sums match files', False, str(error))

    # 14. the shipped exes themselves: the drawn icon at every size, so the
    # small sizes in an Explorer list are the treated ones and not the murky
    # downscale, and the elevation request the firewall needs.
    if os.name == 'nt':
        wanted_sizes = ico_sizes(os.path.join(ROOT, 'assets', 'gbt.ico'))
        check('the icon file holds the seven sizes',
              wanted_sizes == [(16, 16), (24, 24), (32, 32), (48, 48),
                               (64, 64), (128, 128), (256, 256)],
              repr(wanted_sizes))
        for name in ('GameVIP.exe', 'GameVIP-Setup.exe'):
            got_sizes = exe_icon_sizes(os.path.join(ROOT, 'release', name))
            check('%s carries every icon size' % name,
                  got_sizes == wanted_sizes, repr(got_sizes))
        manifest = exe_manifest(os.path.join(ROOT, 'release', 'GameVIP-Setup.exe'))
        check('the setup asks for the administrator window',
              'requireAdministrator' in (manifest or ''), '')

    # single-exe shape: engine rides inside the panel bundle
    check('panel embeds engine at build',
          "'--add-binary', '%s;.'" % 'engine' in build_src
          or '--add-binary' in build_src, '')
    check('panel launches bundled engine',
          'def bundled_engine(' in app_src, '')
    check('engine honors data-dir override',
          'GBT_DATA_DIR' in read('tap.py'), '')
    check('setup copies one program',
          'Copying the one program' in src, '')
    check('setup removes stale sibling engine',
          'stale_engine' in src, '')
    check('uninstall never restarts ICS',
          'net start' not in src.lower()
          or src.lower().count('net start') == 0, '')
    uninstall_body = src[src.index('def uninstall('):src.index('class Wizard')]
    check('uninstall kills only ours',
          'stop_running()' in uninstall_body, '')
    check('uninstall removes only named rules',
          'remove_firewall_rules(log)' in uninstall_body, '')

    # 10. wizard timers die with the window (no 'invalid command name' spew)
    check('wizard remembers every timer',
          all(token in src for token in (
              'self._drain_job = self.after(DRAIN_MS, self.drain)',
              'self._delayed_jobs', 'def _later(')), '')
    check('wizard cancels its timers on close',
          'after_cancel(job)' in src and 'self._closing = True' in src, '')
    check('no bare after left in the wizard',
          'self.after(80, self.drain)' not in src
          and 'self._later(delay,' in src, '')
    check('wizard unbinds the wheel on close',
          "self.unbind_all('<MouseWheel>')" in src, '')
    check('live launch check harness shipped',
          os.path.isfile(os.path.join(ROOT, 'tools', 'check_launch_flow.py')), '')

    # 11. opening the page is the end user's decision: nothing opens a browser
    # unless it was asked for, so both the window's toggle and a scripted run
    # start out off and the only way on is to tick the box or pass --launch.
    check('opening the dashboard is off by default in the window',
          "'autostart': False, 'launch': False}" in src, '')
    check('opening the dashboard is off by default for a scripted run',
          "'autostart': False, 'launch': False, 'dir'" in src, '')
    check('the wizard paints no sidebar decoration art',
          'sidebar-decoration.png' not in src, '')
    check('--launch is the explicit opt-in',
          "elif argument == '--launch':" in src
          and "options['launch'] = True" in src, '')
    check('launch toggle opens the page',
          "options['dashboard_opened'] = launch_panel_with_page(" in src, '')
    check('running panel is reused not restarted',
          "if port_state(port) == 'open':" in src, '')
    worker_body = src[src.index('def _work('):src.index('def drain(')]
    check('install worker opens the page',
          'launch_panel_with_page(' in worker_body, '')
    check('silent run opens the page',
          'launch_panel_with_page(' in src[src.index('def silent_run('):], '')
    check('worker reads no Tk variable',
          'def _collect_options(' in src
          and 'self.worker_options = self._collect_options()' in src
          and 'self.dir_var.get()' not in worker_body, '')
    check('worker failure is reported',
          'The setup stopped' in src, '')
    check('done button tracks the open page',
          'self.dashboard_opened' in src, '')

    # 12. the installed program has its own window with the on/off switch
    panel_src = read('app.py')
    control_src = read('control.py')
    check('control window module present',
          all(token in control_src for token in (
              'class ControlPanel(', 'def run(', 'def available(')), '')
    check('control window is wired to the panel',
          'control.run(state=control_state' in panel_src
          and 'def control_state(' in panel_src, '')
    check('switch on opens the page',
          'open_page=lambda: open_panel_page(port)' in panel_src, '')
    check('switch off stops the engine',
          'stop=stop_tap' in panel_src and 'start=start_tap' in panel_src, '')
    check('closing the window ends the panel',
          "quit_panel=lambda: quit_panel('the window')" in panel_src
          and 'def quit_panel(from_where=' in panel_src, '')
    check('headless escape hatch kept',
          "'--headless' in sys.argv[1:]" in panel_src
          and 'control_available()' in panel_src, '')
    check('window lives on the main thread',
          'threading.Thread(target=server.serve_forever, daemon=True).start()'
          in panel_src, '')
    check('control window owns no engine logic',
          all('import %s' % module not in control_src
              for module in ('subprocess', 'socket', 'urllib.request')), '')
    check('control window cancels its timers',
          'after_cancel(self._poll_job)' in control_src
          and 'after_cancel(job)' in control_src, '')
    check('panel build carries the branding art',
          'assets%cbranding' in build_src, '')
    check('control window prefers the cleared art',
          "asset('branding_t', name)" in control_src, '')
    check('cleared branding art is present',
          os.path.isfile(os.path.join(ROOT, 'assets', 'branding_t',
                                      'sidebar-emblem.png'))
          and os.path.isfile(os.path.join(ROOT, 'assets', 'branding_t',
                                          'sidebar-wordmark.png')), '')
    check('panel build carries the cleared art',
          'assets%cbranding_t' in build_src, '')
    check('control window audit shipped',
          os.path.isfile(os.path.join(ROOT, 'tools', 'control_audit.py')), '')

    # the icon Windows actually shows: the logo's plate is keyed to real
    # transparency, so Explorer, the taskbar and the title bar draw the
    # artwork over whatever is behind it instead of a black square.
    import struct
    import zlib

    def png_alphas(payload, size):
        """The alpha channel of one PNG icon image, unfiltered."""
        depth, colour, interlace = payload[24], payload[25], payload[28]
        if (depth, colour, interlace) != (8, 6, 0):
            return None
        raw = b''
        at = 8                       # past the signature: length, type, data
        while at + 8 <= len(payload):
            size_of = struct.unpack('>I', payload[at:at + 4])[0]
            if payload[at + 4:at + 8] == b'IDAT':
                raw += payload[at + 8:at + 8 + size_of]
            at += 12 + size_of
        raw = zlib.decompress(raw)
        alphas = []
        previous = bytearray(size * 4)
        at = 0
        for _ in range(size):
            step = raw[at]
            line = bytearray(raw[at + 1:at + 1 + size * 4])
            at += 1 + size * 4
            for index in range(len(line)):
                left = line[index - 4] if index >= 4 else 0
                up = previous[index]
                up_left = previous[index - 4] if index >= 4 else 0
                if step == 0:
                    value = line[index]
                elif step == 1:
                    value = line[index] + left
                elif step == 2:
                    value = line[index] + up
                elif step == 3:
                    value = line[index] + (left + up) // 2
                elif step == 4:
                    guess = left + up - up_left
                    distances = (abs(guess - left), abs(guess - up),
                                 abs(guess - up_left))
                    if distances[0] <= distances[1] and distances[0] <= distances[2]:
                        value = line[index] + left
                    elif distances[1] <= distances[2]:
                        value = line[index] + up
                    else:
                        value = line[index] + up_left
                else:
                    return None
                line[index] = value & 0xFF
            alphas += list(line[3::4])
            previous = line
        return alphas

    def icon_layers(path):
        """Per-size (size, alpha_min, alpha_max, corner_alphas) off a .ico."""
        with open(path, 'rb') as handle:
            data = handle.read()
        reserved, kind, count = struct.unpack('<HHH', data[:6])
        if reserved or kind != 1 or count == 0:
            return None
        layers = []
        for layer in range(count):
            width, height, _, _, _, bits, length, offset = struct.unpack(
                '<BBBBHHII', data[6 + 16 * layer:22 + 16 * layer])
            payload = data[offset:offset + length]
            size = width or 256
            if payload[:8] == b'\x89PNG\r\n\x1a\n':
                # PNG payload (Vista and later): 8-bit RGBA, no interlace.
                alphas = png_alphas(payload, size)
                if alphas is None:
                    return None
            else:
                # 32-bit bottom-up BGRA bitmap: alpha is every fourth byte.
                alphas = list(payload[40:40 + size * size * 4][3::4])
            corners = (alphas[0], alphas[size - 1],
                       alphas[size * (size - 1)], alphas[-1])
            layers.append((size, min(alphas), max(alphas), corners))
        return layers

    layers = None
    icon_error = ''
    try:
        layers = icon_layers(os.path.join(ROOT, 'assets', 'gbt.ico'))
    except Exception as error:
        icon_error = '%s: %s' % (type(error).__name__, error)
    check('icon readable as a real .ico', bool(layers), icon_error)
    if layers:
        check('icon has every size', [layer[0] for layer in layers]
              == [16, 24, 32, 48, 64, 128, 256],
              '%s' % [layer[0] for layer in layers])
        check('icon carries alpha at every size',
              all(layer[1] == 0 and layer[2] == 255 for layer in layers),
              '%s' % [(layer[0], layer[1], layer[2]) for layer in layers])
        check('icon plate transparent at every corner',
              all(max(layer[3]) == 0 for layer in layers),
              '%s' % [(layer[0], layer[3]) for layer in layers])
    icon_tool = read(os.path.join('tools', 'make_icon.py'))
    check('icon tool keys the plate instead of shipping it',
          'def key_plate(' in icon_tool and 'key_plate(' in icon_tool.split(
              'def from_logo')[1], '')
    check('both shipped icons built from the keyed plate',
          "('gbt.ico', 'logo.png'), ('gamevip.ico', 'gamevip-logo.png')"
          in icon_tool, '')
    # The icon sits on the dashboard's own mark tile. Its values are copied
    # into the icon tool, so this fails the moment one side moves without the
    # other and the icon starts to look like a different product.
    mark_tokens = ('#03090c', '15px', '52px', 'rgba(99,220,166,.45)', '22px')
    drifted = [token for token in mark_tokens
               if not (token in app_src and token in icon_tool)]
    check('icon tile uses the dashboard mark values', not drifted,
          'missing from app.py and/or make_icon.py: %s' % ', '.join(drifted))
    check('icon tile is the mark tile',
          "TILE = 'mark'" in icon_tool and 'def mark_tile(' in icon_tool, '')
    # An Explorer list draws 16 and 32px, and at those sizes the tile's own rim
    # and the hood's detail are a pixel or two wide. Without the small-size
    # treatment the icon is a murky square there, which is exactly what a
    # freshly installed exe was showing.
    check('the icon has a small-size treatment',
          'SMALL_MAX = 32' in icon_tool and 'def lift_art(' in icon_tool
          and 'small = size <= SMALL_MAX' in icon_tool
          and 'SMALL_RIM_ALPHA' in icon_tool, '')

    # 13. the install folder holds the program and nothing else. The log, the
    # cache and the heartbeat are working files, not the program, so a frozen
    # build keeps them in the per-user folder and a run from source keeps them
    # beside the script; the copies of the readme and the icon are not
    # installed at all, and the marker is hidden.
    # Scoped to the copy step on purpose: the setup still reads its own window
    # icon out of the bundle, which is not an install. What matters is that the
    # step that puts files in the folder puts exactly one there.
    copy_step = src[src.index("step('Copying the one program')"):
                    src.index('tidy_install_folder(target, log)')]
    check('the setup installs the one program',
          'payload(PANEL_EXE)' in copy_step
          and 'payload(README_FILE)' not in copy_step
          and 'payload(ICON_FILE)' not in copy_step, '')
    check('the record is hidden when it sits beside the program',
          'def hide(' in src and 'hide(record)' in src
          and 'same_path(os.path.dirname(record), target)' in src, '')
    check('no record is written into the folder the setup was started from',
          'def marker_path(' in src
          and 'if install_dir and same_path(install_dir, app_dir()):' in src
          and 'os.path.join(data_dir(), MARKER_FILE)' in src, '')
    check('a record left beside a program is still read',
          'def marker_locations(' in src
          and 'os.path.join(install_dir, MARKER_FILE)' in src
          and 'for path in marker_locations(install_dir):' in src, '')
    check('the folder the setup was started from is never swept',
          'def tidy_install_folder(' in src
          and 'if same_path(install_dir, app_dir()):' in src, '')
    # Read from the live module, not the source: the record has to land in the
    # per-user folder for the handover folder and beside the program anywhere
    # else, or the folder handed over shows an install.txt again.
    handover_dir = os.path.join(ROOT, 'build', 'fake-elsewhere')
    elsewhere = setup_wizard.marker_path(handover_dir)
    check('a program in a folder of its own keeps its record beside it',
          os.path.dirname(elsewhere) == handover_dir, elsewhere)
    in_handover = setup_wizard.marker_path(setup_wizard.app_dir())
    check('the handover folder gets no record of ours',
          os.path.dirname(in_handover) == setup_wizard.data_dir(), in_handover)
    check('a previous install is swept out of the folder',
          'def tidy_install_folder(' in src
          and 'tidy_install_folder(target, log)' in src
          and 'LEGACY_WORKING_FILES' in src, '')
    check('a removal takes the working files with it',
          'folder = data_dir()' in src
          and src.count('shutil.rmtree(folder') >= 1, '')
    check('all three agree on the working folder',
          all("DATA_FOLDER = 'GameBaToVipSpoof'" in text
              for text in (src, read('app.py'), read('tap.py'))), '')
    for name, text in (('app.py', read('app.py')), ('tap.py', read('tap.py'))):
        stale = [line.strip() for line in text.splitlines()
                 if 'os.path.join(HERE,' in line
                 and any(key in line for key in ('panel.log', 'tap.log',
                                                 'engine_health.json', 'cache'))]
        check('%s keeps no working file beside the program' % name, not stale,
              '; '.join(stale))
    build_src = read('build_release.py')
    check('the built folder holds the program beside the setup',
          'os.remove(os.path.join(RELEASE, PANEL))' not in build_src
          and "sums = [line for line in sums if not line.endswith('  ' + ENGINE)]"
          in build_src, '')

    print('\n%d failures.' % len(FAILURES), flush=True)
    return 1 if FAILURES else 0


if __name__ == '__main__':
    sys.exit(main())
