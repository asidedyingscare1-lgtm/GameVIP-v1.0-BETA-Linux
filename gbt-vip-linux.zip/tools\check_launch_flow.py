"""Live check of the wizard's timer lifecycle and its open-the-dashboard flow.

Runs the real Wizard window through the real buttons, but with the install
body, the panel start, the port probe and the browser open replaced by
recorders, so nothing is installed, no process is left behind and no browser
tab appears.

    python tools/check_launch_flow.py     (exit 0 = all green)
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import setup_wizard as s

FAILURES = []


def check(name, condition, detail=''):
    print('[%s] %s%s' % ('PASS' if condition else 'FAIL', name,
                         (' -- ' + detail) if detail else ''), flush=True)
    if not condition:
        FAILURES.append(name)


def watch_errors(window, sink):
    """Capture Tk's background errors -- the 'invalid command name' ones."""
    window.tk.createcommand('bgerror', lambda message: sink.append(str(message)))


def pump(window, seconds):
    deadline = time.time() + seconds
    while time.time() < deadline:
        window.update()
        time.sleep(0.02)


def timers(window):
    """Tcl ids of the timers still scheduled for this window."""
    return window.tk.call('after', 'info')


def alive(window):
    try:
        return bool(window.winfo_exists())
    except Exception:
        return False


PANEL_DIR = s.app_dir()
calls = {'install': [], 'uninstall': [], 'started': [], 'opened': [], 'probed': []}


def reset_calls():
    for value in calls.values():
        value.clear()


def fake_install(options, log, progress):
    calls['install'].append(dict(options))
    log('checked the install body instead of running it')


def fake_uninstall(target, log, progress, remove_dir=True, keep_shortcuts=False):
    calls['uninstall'].append(target)
    log('checked the removal body instead of running it')


s.install = fake_install
s.uninstall = fake_uninstall
s.launch_panel = lambda panel: (calls['started'].append(panel), True)[1]
s.open_dashboard = lambda port=s.PANEL_PORT: (calls['opened'].append(port), True)[1]
s.wait_for_port = lambda port, seconds=15: True


# -- 1. the queue pump must not outlive the window ----------------------------
# The design loop (tools/ui_audit.py) builds and drops four windows in a row.
# Each drop used to leave its 80 ms drain timer running, so Tk reported the
# dead callback on stderr on the next window's turn. The control below leaks a
# timer on purpose, which proves the recorder sees exactly that error.
errors = []
for round_number in range(3):
    window = s.Wizard(mode='install', options={})
    watch_errors(window, errors)
    pump(window, 0.3)
    check('drain is running (round %d)' % round_number, bool(timers(window)), '')
    window.destroy()
    check('destroy cancels every timer (round %d)' % round_number,
          not timers(window), repr(timers(window)))
    survivor = s.Wizard(mode='install', options={})
    watch_errors(survivor, errors)
    pump(survivor, 0.4)
    survivor.destroy()

control = []
window = s.Wizard(mode='install', options={})
watch_errors(window, control)
window.after(80, window.drain)               # deliberate leak, never cancelled
window.destroy()
survivor = s.Wizard(mode='install', options={})
watch_errors(survivor, control)
pump(survivor, 0.4)
survivor.destroy()
check('recorder catches a leaked timer (control)', bool(control), '')
check('no Tcl background errors from the wizard', not errors, '; '.join(errors[:2]))


# -- 1b. the sidebar footer: no decoration art, the version at the bottom ----
# The window used to end its sidebar in the smoky red art from the reference
# screenshot. It carried no information, so it is gone; the version line is the
# lowest thing in the sidebar now. Both are geometry facts about the real
# window, which is why they are checked here rather than in the source scan.
window = s.Wizard(mode='install', options={})
window.show_step(0)
window.deiconify()
pump(window, 0.4)
height = window.winfo_height()
images, texts = [], {}
for child in window.sidebar.winfo_children():
    if child.winfo_class() != 'Label':
        continue
    top = child.winfo_rooty() - window.winfo_rooty()
    try:
        if child.cget('image'):
            images.append(top)
    except Exception:
        pass
    try:
        text = child.cget('text')
    except Exception:
        text = ''
    if text:
        texts[text] = top
version = [top for text, top in texts.items() if text.startswith('Version')]
check('no decoration art below the sidebar title',
      all(top < height * 0.2 for top in images),
      'image labels at %s of %d' % (images, height))
check('the version line sits at the bottom of the sidebar',
      bool(version) and version[0] > height * 0.8,
      'version at %s of %d' % (version, height))
check('the version line is the lowest text in the sidebar',
      bool(version) and version[0] == max(texts.values()),
      'sidebar text at %s' % texts)
window.destroy()


# -- 2. the launch toggle: on opens the page, off starts nothing --------------
def walk_install(launch, port, folder=None):
    """Press the real buttons from Welcome to the working page."""
    reset_calls()
    s.port_state = lambda p: (calls['probed'].append(p), port)[1]
    window = s.Wizard(mode='install', options={'dir': PANEL_DIR})
    window.installed = None
    window.show_step(1)
    window.dir_var.set(folder or os.path.join(s.app_dir(), 'build', 'fake-install'))
    window.option_vars['launch'].set(launch)
    window.go_next()                          # the Install button
    pump(window, 2.5)
    step = window.step
    if alive(window):
        window.destroy()
    return step


# The toggle has to arrive unticked: an installer that opens a browser tab the
# moment it finishes is exactly what a fresh install must not do.
fresh = s.Wizard(mode='install', options={})
fresh.show_step(1)
check('the launch toggle starts unticked',
      fresh.option_vars['launch'].get() is False,
      repr(fresh.option_vars['launch'].get()))
fresh.destroy()
check('a scripted run does not open the page',
      s.parse_arguments([])[1]['launch'] is False,
      repr(s.parse_arguments([])[1]['launch']))
check('--launch is the way to ask for it',
      s.parse_arguments(['--launch'])[1]['launch'] is True,
      repr(s.parse_arguments(['--launch'])[1]['launch']))
check('--no-launch still says no',
      s.parse_arguments(['--launch', '--no-launch'])[1]['launch'] is False, '')

step = walk_install(False, 'free')
check('toggle off ran the install', len(calls['install']) == 1, repr(calls['install']))
check('toggle off starts nothing', not calls['started'], repr(calls['started']))
check('toggle off opens no page', not calls['opened'], repr(calls['opened']))
check('toggle off still reaches the done page', step == 3, 'step=%s' % step)

step = walk_install(True, 'free')
check('toggle on ran the install', len(calls['install']) == 1, repr(calls['install']))
check('toggle on starts the installed panel',
      [os.path.basename(path) for path in calls['started']] == [s.PANEL_EXE],
      repr(calls['started']))
check('toggle on opens the dashboard url',
      calls['opened'] == [s.PANEL_PORT], repr(calls['opened']))
check('toggle on finishes on the done page', step == 3, 'step=%s' % step)

step = walk_install(True, 'open')
check('a panel already answering is reused, not restarted',
      not calls['started'] and calls['opened'] == [s.PANEL_PORT],
      'started=%r opened=%r' % (calls['started'], calls['opened']))
check('reuse still reaches the done page', step == 3, 'step=%s' % step)


# -- 3. the remove walkthrough must reach the same end ------------------------
# Its page never builds the folder box, so anything read from that box on the
# worker thread used to kill the removal silently.
reset_calls()
s.port_state = lambda p: (calls['probed'].append(p), 'free')[1]
window = s.Wizard(mode='uninstall', options={'dir': os.path.join(s.app_dir(), 'build')})
window.installed = os.path.join(s.app_dir(), 'build')
window.show_step(2)                           # the Remove button lands here
pump(window, 2.0)
check('removal ran', len(calls['uninstall']) == 1, repr(calls['uninstall']))
check('removal reaches the done page', window.step == 3, 'step=%s' % window.step)
check('removal page has no folder box to read',
      not hasattr(window, 'dir_var'), 'dir_var exists on the removal page')
check('removal never starts the panel', not calls['started'], repr(calls['started']))
if alive(window):
    window.destroy()


# -- 4. a worker that explodes must say so, not hang on 'Working...' ----------
def exploding_install(options, log, progress):
    raise RuntimeError('the check made this fail')


s.install = exploding_install
reset_calls()
window = s.Wizard(mode='install', options={'dir': os.path.join(s.app_dir(), 'build')})
window.show_step(1)
window.show_step(2)
pump(window, 1.5)
check('a failed install reports on the page',
      window.hint.cget('text').startswith('The setup stopped:'), window.hint.cget('text'))
check('a failed install leaves a usable button',
      str(window.next_btn.cget('state')) == 'normal'
      and window.next_btn.cget('text') == 'Close',
      '%s/%s' % (window.next_btn.cget('state'), window.next_btn.cget('text')))
check('a failed install keeps the window open', alive(window), '')
window.destroy()
s.install = fake_install


# -- 5. the Done page button: 'Finish' when the page is already open ----------
window = s.Wizard(mode='install', options={})
window.installed = PANEL_DIR
window.dashboard_opened = True
window.show_step(3)
check('done page says Finish when the dashboard is open',
      window.next_btn.cget('text') == 'Finish', window.next_btn.cget('text'))
check('done page says the dashboard is already open',
      'already open' in window.hint.cget('text'), window.hint.cget('text'))
window.destroy()

window = s.Wizard(mode='install', options={})
window.installed = PANEL_DIR
window.show_step(3)
check('done page offers the dashboard when it is not',
      window.next_btn.cget('text') == 'Open the dashboard',
      window.next_btn.cget('text'))
check('done page says the install was recorded',
      'recorded' in window.hint.cget('text'), window.hint.cget('text'))

# -- 6. that button waits without freezing the window ------------------------
reset_calls()
s.port_state = lambda p: 'free'
window.next_btn.invoke()
pump(window, 0.5)
check('button starts the panel', bool(calls['started']), repr(calls['started']))
check('button leaves the window live while it waits', alive(window), '')
s.port_state = lambda p: 'open'
pump(window, 1.0)
check('button opens the page once the panel answers',
      calls['opened'] == [s.PANEL_PORT], repr(calls['opened']))
check('button closes the window after opening', not alive(window), '')

# -- 7. a panel that never answers leaves a usable window ---------------------
s.PANEL_OPEN_TIMEOUT = 0.5
s.port_state = lambda p: 'free'
window = s.Wizard(mode='install', options={})
window.installed = PANEL_DIR
window.show_step(3)
window.next_btn.invoke()
pump(window, 1.5)
check('a silent panel is reported, not waited out',
      str(window.next_btn.cget('state')) == 'normal'
      and window.next_btn.cget('text') == 'Finish',
      '%s/%s' % (window.next_btn.cget('state'), window.next_btn.cget('text')))
check('a silent panel opens no dead url',
      calls['opened'] == [s.PANEL_PORT], repr(calls['opened']))
window.destroy()

print('\n%d failures.' % len(FAILURES), flush=True)
sys.exit(1 if FAILURES else 0)
