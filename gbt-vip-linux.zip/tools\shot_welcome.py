"""Render the wizard welcome page and screenshot it (preview, no install)."""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import setup_wizard as s

w = s.Wizard(mode='install', options={})
w.update_idletasks()
w.lift()
w.focus_force()
w.attributes('-topmost', True)
w.update()
time.sleep(1.5)
w.update_idletasks()
x, y = w.winfo_rootx(), w.winfo_rooty()
wd, ht = w.winfo_width(), w.winfo_height()
from PIL import ImageGrab
shot = ImageGrab.grab(bbox=(x, y, x + wd, y + ht))
shot.save('build/welcome_shot.png')
print('saved build/welcome_shot.png', shot.size)
w.destroy()
