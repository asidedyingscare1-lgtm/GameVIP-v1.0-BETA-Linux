# GameVIP spoof: read-only network triage.
#
# Run this on the Windows PC that is meant to be serving the console, while the
# dashboard says the switch is ON. It changes nothing: it reads processes, ports,
# the firewall rules, the heartbeat and the engine's log, then prints what it
# found and what to do about it.
#
#   powershell -NoProfile -ExecutionPolicy Bypass -File tools\diagnose_network.ps1
#   powershell -NoProfile -ExecutionPolicy Bypass -File tools\diagnose_network.ps1 -SpeedTest
#
# -SpeedTest adds a ten second download measurement of this PC's raw internet
# speed, which is what a crawling console download is usually limited by.
# Reading the firewall rules needs an elevated window on some Windows builds;
# every other check works as a normal user.

param(
    [string]$DataFolder = '',
    [switch]$SpeedTest
)
$ErrorActionPreference = 'SilentlyContinue'
$DATA_NAME = 'GameBaToVipSpoof'
$STORE_HOST = '46.4.242.27'          # the real store the relay needs
$CHECK_NAMES = @('gamebatoapi.ir', 'update.gamebatoapi.ir')
$RULE_SETS = [ordered]@{
    'installed program' = @('GameVIP DNS', 'GameVIP HTTP', 'GameVIP Panel')
    'source checkout'   = @('GBTTap DNS', 'GBTTap HTTP', 'GBTTap Panel')
}
$ENGINE_NAMES = @('gbtviptap-engine', 'GameVIP', 'python', 'pythonw')

$script:problems = New-Object System.Collections.Generic.List[string]

function Say([string]$Text) { Write-Host $Text }
function Section([string]$Title) {
    Say ''
    Say ('=== ' + $Title + ' ' + ('=' * [Math]::Max(0, 62 - $Title.Length)))
}
function Problem([string]$Text) {
    $script:problems.Add($Text)
    Say ('  [problem] ' + $Text)
}
function Good([string]$Text) { Say ('  [ok]      ' + $Text) }
function Note([string]$Text) { Say ('            ' + $Text) }

# A TCP connect with our own deadline, so a filtered port does not hang the run.
function Test-Tcp([string]$Target, [int]$Port, [int]$TimeoutMs = 2500) {
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $wait = $client.BeginConnect($Target, $Port, $null, $null)
        if (-not $wait.AsyncWaitHandle.WaitOne($TimeoutMs)) { return $false }
        $client.EndConnect($wait)
        return $true
    } catch { return $false } finally { $client.Close() }
}

# Ask one server for an A record ourselves, so a silent or blocked server is a
# two second answer rather than a nslookup that waits out its own retries.
function Resolve-AtServer([string]$Name, [string]$Server, [int]$TimeoutMs = 2500) {
    $packet = New-Object System.Collections.Generic.List[byte]
    $packet.AddRange([byte[]]@(0x47, 0x42, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00))
    foreach ($label in $Name.TrimEnd('.').Split('.')) {
        $packet.Add([byte]$label.Length)
        $packet.AddRange([System.Text.Encoding]::ASCII.GetBytes($label))
    }
    $packet.Add(0)
    $packet.AddRange([byte[]]@(0x00, 0x01, 0x00, 0x01))
    $udp = New-Object System.Net.Sockets.UdpClient
    $udp.Client.ReceiveTimeout = $TimeoutMs
    try {
        $udp.Connect($Server, 53)
        $udp.Send($packet.ToArray(), $packet.Count) | Out-Null
        $remote = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Any, 0)
        $reply = $udp.Receive([ref]$remote)
        if ($reply.Length -lt 12) { return '' }
        $answers = ($reply[6] * 256) + $reply[7]
        if ($answers -lt 1) { return 'no answer for this name' }
        if ($answers -eq 1 -and $reply.Length -ge 16) { return (($reply[-4..-1]) -join '.') }
        return ('a reply with ' + $answers + ' answers')
    } catch { return '' } finally { $udp.Close() }
}

Section 'The dashboard PC'
Say ("  computer      : " + $env:COMPUTERNAME + "   user " + $env:USERNAME)
Say ("  when          : " + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'))

# -- working folder ---------------------------------------------------------
# An installed build keeps its files in the per-user folder; a source run keeps
# them beside the script. Read whichever tap.log was written most recently, so
# the log printed below is the one from the run that just happened.
$candidates = New-Object System.Collections.Generic.List[string]
if ($DataFolder) { $candidates.Add($DataFolder) }
$candidates.Add((Join-Path $env:LOCALAPPDATA $DATA_NAME))
$candidates.Add((Resolve-Path (Join-Path $PSScriptRoot '..')).Path)
$data = ''
$freshest = [DateTime]::MinValue
foreach ($candidate in $candidates) {
    $file = Join-Path $candidate 'tap.log'
    if (Test-Path $file) {
        $stamp = (Get-Item $file).LastWriteTime
        if ($stamp -gt $freshest) { $freshest = $stamp; $data = $candidate }
    }
}
if (-not $data) {
    $data = $candidates[1]
    Say ('  working files : no tap.log in ' + ($candidates -join ' nor '))
}
Say ("  working files : " + $data)
foreach ($candidate in $candidates) {
    if ($candidate -ne $data -and (Test-Path (Join-Path $candidate 'tap.log'))) {
        Note ('older log also at ' + (Join-Path $candidate 'tap.log'))
    }
}
$logPath = Join-Path $data 'tap.log'
$healthPath = Join-Path $data 'engine_health.json'

# -- the advertised address -------------------------------------------------
Section 'The address this PC advertises to the console'
$route = Get-NetRoute -DestinationPrefix '0.0.0.0/0' |
    Where-Object { $_.NextHop -ne '0.0.0.0' } |
    Sort-Object RouteMetric, ifMetric | Select-Object -First 1
$advertised = ''
if ($route) {
    $address = Get-NetIPAddress -InterfaceIndex $route.InterfaceIndex -AddressFamily IPv4 |
        Where-Object { $_.IPAddress -notlike '169.254.*' } | Select-Object -First 1
    if ($address) {
        $advertised = $address.IPAddress
        $alias = (Get-NetAdapter -InterfaceIndex $route.InterfaceIndex).Name
        Say ("  internet route : " + $advertised + "   on '" + $alias + "'")
    }
} else {
    Problem 'This PC has no default route, so it has no internet and no address to advertise.'
}
$others = Get-NetIPAddress -AddressFamily IPv4 |
    Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' -and $_.IPAddress -ne $advertised }
foreach ($other in $others) {
    $name = (Get-NetAdapter -InterfaceIndex $other.InterfaceIndex).Name
    Note ("other address  : " + $other.IPAddress + "   on '" + $name + "'")
}
if (($others | Measure-Object).Count -gt 0) {
    Note 'A VPN, tether or virtual adapter beside the real one is how the wrong address'
    Note 'gets advertised. The console must be given the address the engine logged below.'
}

# -- is anything serving ----------------------------------------------------
Section 'Is the tap serving right now'
$engine = Get-Process -Name $ENGINE_NAMES
if ($engine) {
    foreach ($process in $engine) {
        Good ($process.ProcessName + ' is running (PID ' + $process.Id + ')')
    }
} else {
    Problem 'No engine or dashboard process is running: the switch is off, or the panel was closed.'
}

$dnsEndpoints = @(Get-NetUDPEndpoint -LocalPort 53)
foreach ($endpoint in ($dnsEndpoints | Select-Object -First 4)) {
    $owner = (Get-Process -Id $endpoint.OwningProcess).ProcessName
    Say ("  UDP 53        : " + $endpoint.LocalAddress + " -> " + $owner + " (PID " + $endpoint.OwningProcess + ")")
}
# The tap binds this PC's own address, never the wildcard, so a bind on a real
# address is the proof that name interception is up.
$tapDns = @($dnsEndpoints | Where-Object { $_.LocalAddress -ne '0.0.0.0' })
if ($tapDns.Count -gt 0) {
    Good ('Interception is bound for DNS on ' + $tapDns[0].LocalAddress + '  (Internet Connection Sharing on 0.0.0.0 is normal and harmless)')
} else {
    Problem 'No listener on UDP 53 is bound to this PC''s own address, so no name is intercepted.'
}

$httpOwner = Get-NetTCPConnection -LocalPort 80 -State Listen
foreach ($endpoint in $httpOwner) {
    $owner = (Get-Process -Id $endpoint.OwningProcess).ProcessName
    Say ("  TCP 80        : " + $endpoint.LocalAddress + " -> " + $owner + " (PID " + $endpoint.OwningProcess + ")")
}
if (-not $httpOwner) { Problem 'Nothing is listening on TCP 80, so store answers and downloads are not served.' }
if ($engine -and -not $httpOwner -and $tapDns.Count -eq 0) {
    Note 'A program of ours is running but no port is bound: the switch is OFF, or the engine stopped.'
    Note 'The dashboard''s "Why it stopped" card names the reason.'
}

# -- the engine's own opinion ----------------------------------------------
Section 'What the engine says about itself'
if (Test-Path $healthPath) {
    $health = Get-Content $healthPath -Raw | ConvertFrom-Json
    $age = [Math]::Round(((Get-Date) - (Get-Item $healthPath).LastWriteTime).TotalSeconds, 0)
    Say ("  heartbeat     : written " + $age + "s ago (30s means dead)")
    Say ("  dns / http    : " + $health.dns + " / " + $health.http)
    if ($health.note) { Say ("  note          : " + $health.note) }
    if ($age -gt 40) {
        Problem ('The heartbeat is ' + $age + 's old, so the engine has stopped answering.')
    } elseif ($health.dns -eq $false) {
        Problem 'The engine fails its own DNS self-probe.'
    } elseif ($health.http -eq $false) {
        Problem 'The engine fails its own HTTP self-probe.'
    } else {
        Good 'The engine reports both listeners healthy.'
    }
} else {
    Note ('No heartbeat file at ' + $healthPath + ': the engine has not run with the switch ON.')
}

# -- the log, which is the decisive evidence -------------------------------
Section 'The engine log'
if (Test-Path $logPath) {
    Say ("  file          : " + $logPath)
    Say ("  last written  : " + (Get-Item $logPath).LastWriteTime)
    $start = Select-String -Path $logPath -Pattern 'VIP Spoof live' | Select-Object -Last 1
    if ($start) {
        Say ("  started       : " + $start.Line)
        if ($advertised -and $start.Line -notmatch [regex]::Escape($advertised)) {
            Problem ('The engine started on a different address than this PC has now (' + $advertised + ').')
            Problem 'The console is probably pointed at the old one: read the PS4 DNS line in the panel.'
        }
    }
    $tail = Get-Content $logPath -Tail 12
    Say '  last lines:'
    foreach ($line in $tail) { Say ('  | ' + $line) }

    $requests = Select-String -Path $logPath -Pattern 'HTTP/1.' -SimpleMatch |
        Where-Object { $_.Line -match '^\S+\s+(\d{1,3}\.){3}\d{1,3}\s' }
    $fromConsole = $requests | Where-Object { $_.Line -notmatch '^\S+\s+127\.0\.0\.1\s' }
    if ($fromConsole) {
        $peers = ($fromConsole | ForEach-Object { ($_.Line -split '\s+')[1] } | Sort-Object -Unique) -join ', '
        Good ('Requests arrived from: ' + $peers + '  (anything other than 127.0.0.1 is the console)')
        Say '  most recent:'
        foreach ($line in ($fromConsole | Select-Object -Last 3)) { Say ('  > ' + $line.Line) }
    } else {
        Problem 'Only this PC''s own loopback probe is in this log, so the console has not reached this PC.'
    }

    $trouble = Select-String -Path $logPath -Pattern 'INCOMPLETE|ERR |stopped after|cannot reach the store'
    if ($trouble) {
        $count = ($trouble | Measure-Object).Count
        Say ''
        Say ('  ' + $count + ' error or incomplete lines, most recent:')
        foreach ($line in ($trouble | Select-Object -Last 5)) { Say ('  ! ' + $line.Line) }
        Note 'Repeated incomplete or stopped lines mean the PC''s own link to the store is dropping'
        Note 'mid transfer, which is what a crawling or restarting console download looks like.'
    }
} else {
    Problem ('No tap.log at ' + $logPath + ', so the engine has never written a log here.')
}

# -- the firewall -----------------------------------------------------------
Section 'The inbound firewall rules the console needs'
$foundSets = @()
foreach ($set in $RULE_SETS.Keys) {
    $present = @()
    foreach ($name in $RULE_SETS[$set]) {
        $shown = netsh advfirewall firewall show rule name="$name"
        if ($shown -match 'Ok\.') { $present += $name }
    }
    if ($present.Count -gt 0) {
        $foundSets += $set
        Say ("  " + $set.PadRight(18) + ": " + ($present -join ', '))
    }
}
if ($foundSets.Count -eq 0) {
    $blank = (netsh advfirewall firewall show rule name="GameVIP DNS") -join "`n"
    if ($blank -match 'denied|requires elevation') {
        Problem 'Reading the firewall needs an elevated window: rerun this as administrator.'
    } else {
        Problem 'None of the three inbound rules exist, so the console cannot get past the firewall.'
        Note 'Fix: press "Allow through" on the dashboard, or run these in an elevated window:'
        Note '  netsh advfirewall firewall add rule name="GameVIP DNS" dir=in action=allow protocol=UDP localport=53 remoteip=localsubnet'
        Note '  netsh advfirewall firewall add rule name="GameVIP HTTP" dir=in action=allow protocol=TCP localport=80 remoteip=localsubnet'
        Note '  netsh advfirewall firewall add rule name="GameVIP Panel" dir=in action=allow protocol=TCP localport=8899 remoteip=localsubnet'
    }
} else {
    Note 'These rules cover every profile and trust only the local subnet, so the console must'
    Note 'be on the same subnet as this PC: another VLAN, guest network or hotspot is blocked.'
}
foreach ($profile in (Get-NetConnectionProfile)) {
    Say ("  profile          : '" + $profile.InterfaceAlias + "' is " + $profile.NetworkCategory)
}

# -- the local proof --------------------------------------------------------
Section 'Proof from this PC'
if ($advertised) {
    foreach ($name in $CHECK_NAMES) {
        $answer = Resolve-AtServer $name $advertised
        if ($answer -eq $advertised) {
            Good ($name + ' -> ' + $answer + '  (the tap intercepted it)')
        } elseif ($answer -eq $STORE_HOST) {
            Problem ($name + ' -> ' + $answer + '  (the real store, not the tap)')
        } elseif ([string]::IsNullOrEmpty($answer)) {
            Problem ($name + ' -> no answer from ' + $advertised + ' within 2.5s')
        } else {
            Problem ($name + ' -> ' + $answer)
        }
    }
    if (Test-Tcp $advertised 80) { Good ('TCP ' + $advertised + ':80 answers') }
    else { Problem ('TCP ' + $advertised + ':80 does not answer, so nothing can pass through this PC') }
    Say ''
    Say ('  Put this exact address in the PS4: ' + $advertised)
    Say '  Primary DNS = it, Secondary DNS = empty. A real resolver in the second slot lets'
    Say '  the console bypass this PC and talk to the store that grants nothing.'
} else {
    Problem 'No address to test against.'
}

Section 'The PC''s own way out'
if (Test-Tcp $STORE_HOST 80) { Good ('The real store answers at ' + $STORE_HOST + ':80') }
else { Problem ('This PC cannot reach the real store at ' + $STORE_HOST + ':80, so relayed content stalls') }
if (Test-Tcp '1.1.1.1' 53) { Good 'Upstream DNS (1.1.1.1:53) answers' }
else { Problem 'This PC cannot reach an upstream DNS server, so every forwarded name fails' }

if ($SpeedTest) {
    Section 'This PC''s raw internet speed (ten seconds)'
    $client = New-Object System.Net.WebClient
    # A plain browser agent: some speed endpoints answer 403 to unknown clients.
    $client.Headers.Add('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)')
    $bytes = 0
    $watch = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        # 50 MB, not more: the endpoint refuses a larger request, and this fills the
        # ten seconds at anything up to 5 MB/s and ends early on a faster link.
        $stream = $client.OpenRead('https://speed.cloudflare.com/__down?bytes=50000000')
        $buffer = New-Object byte[] 262144
        while ($watch.Elapsed.TotalSeconds -lt 10) {
            $read = $stream.Read($buffer, 0, $buffer.Length)
            if ($read -le 0) { break }
            $bytes += $read
        }
        $stream.Close()
        $rate = [Math]::Round(($bytes / 1MB) / $watch.Elapsed.TotalSeconds, 2)
        Say ('  pulled        : ' + [Math]::Round($bytes / 1MB, 1) + ' MB in ' + [Math]::Round($watch.Elapsed.TotalSeconds, 1) + 's')
        Say ('  speed         : ' + $rate + ' MB/s')
        if ($rate -lt 1) {
            Problem ('This PC pulls only ' + $rate + ' MB/s from the internet, and that is what caps the console')
        } else {
            Good 'This PC''s own link is fast, so a crawling console download is not limited by this PC''s internet'
        }
    } catch {
        Note ('Could not measure: ' + $_.Exception.Message)
    } finally { $client.Dispose() }
}

Section 'Verdict'
if ($script:problems.Count -eq 0) {
    Say '  Nothing on this PC is broken. If the console still fails, it is not reaching this PC:'
    Say '  check that the PS4 DNS is the address above, that its second DNS slot is empty, and'
    Say '  that the console sits on the same subnet as this PC.'
} else {
    foreach ($problem in $script:problems) { Say ('  - ' + $problem) }
}
Say ''

