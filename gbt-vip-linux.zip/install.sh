#!/usr/bin/env bash
# GameVIP — Linux installer. Mirrors GameVIP-Setup.exe on Windows.
#
#   ./install.sh                        interactive install, then starts + opens
#   ./install.sh --dir=DIR               scripted install to DIR, then starts
#   ./install.sh --no-launch              install without starting the panel
#   ./install.sh --launch                 same as default (kept for scripts)
#   ./install.sh --uninstall              remove the product
#   ./install.sh --silent --dir=DIR       scripted, no questions (still starts)
#   ./install.sh --silent --uninstall     scripted removal
#
# What it does, in order — same steps as the Windows setup:
#   1. checks (python3.9+, ports 53/80/8899 free, disk room, Tk for window)
#   2. stops a running panel/engine so files can be replaced
#   3. copies the ONE program (gamevip-panel; engine rides inside it)
#   4. frees port 53 from systemd-resolved's stub when it squats there
#   5. grants low-port bind via setcap (no root needed day to day)
#   6. opens the firewall for LAN only (ufw or nftables, whichever answers)
#   7. writes the .desktop launcher (+ autostart entry when asked)
#   8. records the install in install.txt (hidden dotfile beside program
#      is skipped when installed into the folder this script runs from —
#      same rule as Windows: that folder stays program + script only)
#
# Working files (tap.log, panel.log, cache/, engine_health.json) live in
# ~/.local/share/GameBaToVipSpoof — never beside the program. Same as
# %LOCALAPPDATA%\GameBaToVipSpoof on Windows.
set -euo pipefail

APP_NAME="GameVIP"
PANEL_BIN="gamevip-panel"
MARKER="install.txt"
DATA_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/GameBaToVipSpoof"
VERSION="1.0"
PANEL_PORT=8899
MIN_FREE_KB=$((120 * 1024))

SILENT=0
LAUNCH=1
UNINSTALL=0
TARGET_DIR=""
NO_SHORTCUT=0
NO_AUTOSTART=0
NO_FIREWALL=0
ASK_AUTOSTART=1

for arg in "$@"; do
    case "$arg" in
        --silent) SILENT=1 ;;
        --launch) LAUNCH=1 ;;       # kept: launching is now the default
        --no-launch) LAUNCH=0 ;;
        --uninstall) UNINSTALL=1 ;;
        --dir=*) TARGET_DIR="${arg#--dir=}" ;;
        --no-shortcut) NO_SHORTCUT=1 ;;
        --no-autostart) NO_AUTOSTART=1; ASK_AUTOSTART=0 ;;
        --autostart) ASK_AUTOSTART=0 ;;
        --no-firewall) NO_FIREWALL=1 ;;
        --help|-h)
            sed -n '2,30p' "$0"; exit 0 ;;
        *) echo "Unknown option: $arg (try --help)" >&2; exit 1 ;;
    esac
done

HERE="$(cd "$(dirname "$0")" && pwd)"
[ -n "$TARGET_DIR" ] || TARGET_DIR="$HERE"

log()  { echo "[setup] $*"; }
warn() { echo "[setup] WARNING: $*" >&2; }

# -- sudo is asked ONCE, up front, like the Windows UAC prompt --------------
have_sudo() { command -v sudo >/dev/null 2>&1; }
SUDO_KEEPER_PID=""
trap 'kill "$SUDO_KEEPER_PID" 2>/dev/null || true' EXIT
ensure_sudo() {
    if [ "$(id -u)" -eq 0 ]; then return 0; fi
    if ! have_sudo; then
        warn "sudo not found — firewall/setcap steps will be skipped; run as root to get them."
        return 1
    fi
    sudo -v || { warn "sudo refused."; return 1; }
    # Keep the timestamp alive while we work; the EXIT trap kills it.
    ( while true; do sudo -nv true 2>/dev/null || break; sleep 50; done ) &
    SUDO_KEEPER_PID=$!
    return 0
}
SUDO=""
if [ "$(id -u)" -eq 0 ]; then SUDO="";
elif have_sudo; then SUDO="sudo"; fi

# -- dependencies: install what's missing so a bare paste just works ---------
ensure_deps() {
    local missing=""
    command -v python3 >/dev/null 2>&1 || missing="$missing python3"
    python3 -c 'import tkinter' 2>/dev/null || missing="$missing python3-tk"
    command -v ss >/dev/null 2>&1 || missing="$missing iproute2"
    [ -z "$missing" ] && return 0
    log "Installing missing packages:$missing ..."
    if command -v apt-get >/dev/null 2>&1; then
        $SUDO apt-get update -qq 2>&1 | tail -1 || true
        $SUDO apt-get install -y -qq python3 python3-tk iproute2 2>&1 | tail -2 || true
    elif command -v dnf >/dev/null 2>&1; then
        $SUDO dnf install -y -q python3 python3-tkinter iproute 2>&1 | tail -2 || true
    elif command -v pacman >/dev/null 2>&1; then
        $SUDO pacman -Sy --noconfirm --needed python python-tk iproute2 2>&1 | tail -2 || true
    elif command -v zypper >/dev/null 2>&1; then
        $SUDO zypper install -y python3 python3-tk iproute2 2>&1 | tail -2 || true
    else
        warn "no supported package manager (apt/dnf/pacman/zypper) — install$missing by hand."
        return 1
    fi
    return 0
}

# -- checks ------------------------------------------------------------------
check_python() {
    command -v python3 >/dev/null 2>&1 || { echo "missing (need python3 3.9+)"; return 1; }
    python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null \
        || { echo "too old (need 3.9+)"; return 1; }
    echo "found ($(python3 --version 2>&1))"
    return 0
}
check_tk() {
    python3 -c 'import tkinter' 2>/dev/null && echo "present" || echo "missing (window needs: sudo apt install python3-tk)"
}
port_busy() { # $1 = port — true when something answers on TCP loopback
    python3 -c 'import socket,sys; s=socket.socket(); s.settimeout(0.4); sys.exit(0 if s.connect_ex(("127.0.0.1", int(sys.argv[1]))) == 0 else 1)' "$1" 2>/dev/null
}
check_ports() {
    # 53/UDP + 80/TCP are the engine's; 8899/TCP is the panel's.
    # NOTE: binding 53 to "test" it lies when non-root (no permission even
    # when free), so 53 is read from ss instead — a LISTEN line means busy.
    local busy=""
    if command -v ss >/dev/null 2>&1; then
        ss -lnup 2>/dev/null | grep -qE ':(53)\s' && busy="$busy 53"
    fi
    for p in 80 "$PANEL_PORT"; do
        port_busy "$p" && busy="$busy $p"
    done
    if [ -z "$busy" ]; then echo "free (53 / 80 / $PANEL_PORT)"; else echo "BUSY:$busy"; fi
}
check_space() {
    local free_kb
    free_kb=$(df -k "$TARGET_DIR" 2>/dev/null | awk 'NR==2 {print $4}')
    if [ -z "$free_kb" ]; then echo "unknown"; return 0; fi
    if [ "$free_kb" -ge "$MIN_FREE_KB" ]; then echo "$((free_kb / 1024)) MB free"; else echo "LOW ($((free_kb / 1024)) MB)"; fi
}

# -- process handling ----------------------------------------------------------
stop_running() {
    # End our own panel/engine by image name; never touch anything else.
    local stopped=""
    for pat in "$PANEL_BIN" "gbtviptap-engine" "GameVIP"; do
        if pkill -f "$pat" 2>/dev/null; then stopped="$stopped $pat"; sleep 1; fi
    done
    # A source-run panel is a python3 holding 8899 — end it too, ours only:
    # match app.py on that port via /proc scan (no lsof/ss dependency).
    for pid in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
        if tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null | grep -q "app.py"; then
            if kill "$pid" 2>/dev/null; then stopped="$stopped panel(PID $pid)"; fi
        fi
    done
    echo "$stopped"
}

# -- systemd-resolved stub on port 53 ------------------------------------------
free_resolved_stub() {
    # Ubuntu/Debian ship resolved listening on 127.0.0.53:53. Our DNS binds
    # the LAN address (not the wildcard), so the two usually coexist — but
    # when resolved also grabs the LAN or wildcard 53, the bind fails. Fix:
    # turn off its stub listener, keep the resolver itself running.
    local holds=0
    if command -v ss >/dev/null 2>&1; then
        ss -lnup 2>/dev/null | grep -q ':53 ' && holds=1
    fi
    [ "$holds" -eq 0 ] && return 0
    if resolvectl status 2>/dev/null | grep -q .; then
        log "systemd-resolved holds port 53 — disabling its stub listener (resolver keeps working)..."
        $SUDO mkdir -p /etc/systemd/resolved.conf.d
        echo -e "[Resolve]\nDNSStubListener=no" | $SUDO tee /etc/systemd/resolved.conf.d/gamevip.conf >/dev/null
        $SUDO systemctl restart systemd-resolved 2>/dev/null || \
        $SUDO service systemd-resolved restart 2>/dev/null || true
        sleep 1
    fi
    return 0
}

# -- firewall: LAN-only, ufw or nftables ----------------------------------------
# Every rule this setup adds carries the GameVIP tag (ufw comment / nft
# comment), and removal deletes by that tag only — never by bare port, so
# a rule the user already had for 53/80 survives uninstall.
UFW_TAG="GameVIP"
NFT_TAG="gamevip"
open_firewall() {
    [ "$NO_FIREWALL" -eq 1 ] && { log "Firewall left alone (--no-firewall)."; return 0; }
    if command -v ufw >/dev/null 2>&1 && $SUDO ufw status 2>/dev/null | grep -q .; then
        # ufw active: allow from LAN only (RFC1918), same scope as Windows localsubnet.
        # ufw < 0.36 has no `comment` keyword: try tagged first, fall back to
        # untagged (still LAN-scoped), and record which form landed.
        local comment_ok=0
        $SUDO ufw allow from 192.168.0.0/16 to any port 53 proto udp comment "$UFW_TAG DNS" >/dev/null 2>&1 && comment_ok=1 || true
        for net in 10.0.0.0/8 172.16.0.0/12 192.168.0.0/16; do
            if [ "$comment_ok" -eq 1 ]; then
                $SUDO ufw allow from "$net" to any port 53 proto udp comment "$UFW_TAG DNS" >/dev/null 2>&1 || true
                $SUDO ufw allow from "$net" to any port 80 proto tcp comment "$UFW_TAG HTTP" >/dev/null 2>&1 || true
            else
                $SUDO ufw allow from "$net" to any port 53 proto udp >/dev/null 2>&1 || true
                $SUDO ufw allow from "$net" to any port 80 proto tcp >/dev/null 2>&1 || true
            fi
        done
        # The probe rule above duplicated one LAN net: harmless (ufw skips
        # duplicates with "Skipping adding existing rule"), and it tells us
        # whether delete-by-comment will work later.
        mkdir -p "$DATA_DIR" 2>/dev/null || true
        echo "$comment_ok" > "$DATA_DIR/ufw_comment_ok" 2>/dev/null || true
        log "Firewall opened for UDP 53 + TCP 80 (LAN only, via ufw)."
        return 0
    fi
    if command -v nft >/dev/null 2>&1; then
        # nftables: insert LAN-scoped accepts at the top of the input chain
        # when one exists, each carrying our comment tag so uninstall deletes
        # exactly these and nothing the user already had.
        if $SUDO nft list chain inet filter input >/dev/null 2>&1; then
            for net in 10.0.0.0/8 172.16.0.0/12 192.168.0.0/16; do
                $SUDO nft insert rule inet filter input ip saddr "$net" udp dport 53 accept comment "$NFT_TAG" >/dev/null 2>&1 || \
                $SUDO nft insert rule inet filter input ip saddr "$net" udp dport 53 accept >/dev/null 2>&1 || true
                $SUDO nft insert rule inet filter input ip saddr "$net" tcp dport 80 accept comment "$NFT_TAG" >/dev/null 2>&1 || \
                $SUDO nft insert rule inet filter input ip saddr "$net" tcp dport 80 accept >/dev/null 2>&1 || true
            done
            log "Firewall opened for UDP 53 + TCP 80 (LAN only, via nftables)."
        else
            warn "nftables has no inet filter input chain — skipped; open UDP 53 + TCP 80 for LAN manually."
        fi
        return 0
    fi
    if command -v firewall-cmd >/dev/null 2>&1 && $SUDO firewall-cmd --state >/dev/null 2>&1; then
        $SUDO firewall-cmd --permanent --add-port=53/udp >/dev/null 2>&1 || true
        $SUDO firewall-cmd --permanent --add-port=80/tcp >/dev/null 2>&1 || true
        $SUDO firewall-cmd --reload >/dev/null 2>&1 || true
        log "Firewall opened for UDP 53 + TCP 80 (via firewalld; scope to LAN in your zone config)."
        return 0
    fi
    log "No active firewall found (ufw/nft/firewalld) — nothing to open. The panel will ask if one appears."
    return 0
}
close_firewall() {
    # Delete ONLY our tagged rules. ufw: numbered delete of rules carrying
    # the GameVIP comment (or, on ufw < 0.36 where comments never landed,
    # our exact LAN-scoped allow lines). nft: handles of rules carrying our
    # comment. Anything without our tag is the user's and stays.
    if command -v ufw >/dev/null 2>&1; then
        local numbered
        numbered=$($SUDO ufw status numbered 2>/dev/null | grep -i "$UFW_TAG" | grep -oE '^\[\s*[0-9]+' | grep -oE '[0-9]+' | sort -rn || true)
        for n in $numbered; do
            yes y | $SUDO ufw delete "$n" >/dev/null 2>&1 || true
        done
        if [ -f "$DATA_DIR/ufw_comment_ok" ] && [ "$(cat "$DATA_DIR/ufw_comment_ok" 2>/dev/null)" = "0" ]; then
            numbered=$($SUDO ufw status numbered 2>/dev/null | grep -E 'ALLOW.*(53/udp|80/tcp)' | grep -E '(10\.0\.0\.0/8|172\.16\.0\.0/12|192\.168\.0\.0/16)' | grep -oE '^\[\s*[0-9]+' | grep -oE '[0-9]+' | sort -rn || true)
            for n in $numbered; do
                yes y | $SUDO ufw delete "$n" >/dev/null 2>&1 || true
            done
        fi
    fi
    if command -v nft >/dev/null 2>&1; then
        $SUDO nft --handle list chain inet filter input 2>/dev/null \
            | grep -E "comment \"$NFT_TAG\"|comment '$NFT_TAG'|comment $NFT_TAG" | grep -oE 'handle [0-9]+' | awk '{print $2}' \
            | while read -r h; do $SUDO nft delete rule inet filter input handle "$h" 2>/dev/null || true; done
    fi
}

# -- desktop entry + autostart ---------------------------------------------------
write_desktop() { # $1 = target dir for the .desktop, $2 = panel path
    local dir="$1" panel="$2"
    mkdir -p "$dir"
    local icon=""
    for cand in "$TARGET_DIR/assets/gamevip-logo.png" "$HERE/assets/gamevip-logo.png" \
                "$TARGET_DIR/assets/logo.png" "$HERE/assets/logo.png"; do
        [ -f "$cand" ] && { icon="$cand"; break; }
    done
    {
        echo "[Desktop Entry]"
        echo "Type=Application"
        echo "Name=$APP_NAME"
        echo "Comment=PS4 premium session over your own network"
        echo "Exec=$panel"
        echo "Path=$TARGET_DIR"
        echo "Terminal=false"
        echo "Categories=Network;Utility;"
        [ -n "$icon" ] && echo "Icon=$icon"
    } > "$dir/gamevip.desktop"
    chmod +x "$dir/gamevip.desktop" 2>/dev/null || true
}

# -- install ---------------------------------------------------------------------
do_install() {
    if [ "$SILENT" -eq 0 ]; then
        if [ "$ASK_AUTOSTART" -eq 1 ]; then
            read -rp "Start GameVIP with login? [Y/n] " ans
            case "$ans" in [Nn]*) NO_AUTOSTART=1 ;; esac
        fi
        if [ "$NO_SHORTCUT" -eq 0 ]; then
            read -rp "Install directory [$TARGET_DIR]: " ans
            [ -n "$ans" ] && TARGET_DIR="$ans"
        fi
    fi
    mkdir -p "$TARGET_DIR"

    ensure_sudo || SUDO=""
    ensure_deps || true

    log "GameVIP $VERSION — Linux setup"
    echo "  python:    $(check_python || true)"
    echo "  tk:        $(check_tk)"
    echo "  ports:     $(check_ports)"
    echo "  disk:      $(check_space)"
    echo "  target:    $TARGET_DIR"

    local py_ok=1
    check_python >/dev/null || py_ok=0
    if [ "$py_ok" -eq 0 ]; then
        echo "Python 3.9+ is required and auto-install failed — install python3 + python3-tk by hand, then re-run." >&2
        exit 1
    fi

    log "Stopping any running panel..."
    stopped=$(stop_running || true)
    [ -n "$stopped" ] && log "Closed:$stopped"

    log "Copying the one program..."
    # Source checkout: panel runs from app.py until build_linux.py freezes it.
    # Installed dir holds the frozen gamevip-panel when built, else a
    # self-contained copy of the sources (stdlib only — no pip needed to run).
    if [ -f "$HERE/release-linux/$PANEL_BIN" ]; then
        cp -f "$HERE/release-linux/$PANEL_BIN" "$TARGET_DIR/$PANEL_BIN"
        chmod +x "$TARGET_DIR/$PANEL_BIN"
        log "Copied $PANEL_BIN ($(du -h "$TARGET_DIR/$PANEL_BIN" | cut -f1))."
    elif [ -f "$HERE/$PANEL_BIN" ] && [ "$HERE" != "$TARGET_DIR" ]; then
        cp -f "$HERE/$PANEL_BIN" "$TARGET_DIR/$PANEL_BIN"
        chmod +x "$TARGET_DIR/$PANEL_BIN"
        log "Copied $PANEL_BIN."
    elif [ "$HERE" = "$TARGET_DIR" ]; then
        log "$PANEL_BIN already in place (installing in the checkout folder)."
    else
        for f in app.py tap.py control.py tap.sh; do
            [ -f "$HERE/$f" ] && cp -f "$HERE/$f" "$TARGET_DIR/$f"
        done
        [ -d "$HERE/assets" ] && cp -rf "$HERE/assets" "$TARGET_DIR/" 2>/dev/null || true
        chmod +x "$TARGET_DIR/tap.sh" 2>/dev/null || true
        log "Copied sources (stdlib only — no Python packages needed to run)."
    fi

    free_resolved_stub

    # setcap: bind 53/80 with no root, day to day. Same privilege split as
    # Windows (firewall prompt once, unelevated after).
    if [ -f "$TARGET_DIR/$PANEL_BIN" ] && command -v setcap >/dev/null 2>&1; then
        $SUDO setcap 'cap_net_bind_service=+ep' "$TARGET_DIR/$PANEL_BIN" 2>/dev/null \
            && log "Granted low-port bind (setcap cap_net_bind_service) — no sudo needed to run." \
            || warn "setcap failed — run with sudo, or sudo setcap cap_net_bind_service=+ep $TARGET_DIR/$PANEL_BIN"
    fi

    log "Opening the firewall..."
    open_firewall

    if [ "$NO_SHORTCUT" -eq 0 ]; then
        panel_path="$TARGET_DIR/$PANEL_BIN"
        [ -x "$panel_path" ] || panel_path="$TARGET_DIR/tap.sh"
        write_desktop "$HOME/.local/share/applications" "$panel_path" \
            && log "Launcher created (applications menu → $APP_NAME)." \
            || warn "could not write the launcher."
    fi

    if [ "$NO_AUTOSTART" -eq 0 ]; then
        panel_path="$TARGET_DIR/$PANEL_BIN"
        [ -x "$panel_path" ] || panel_path="$TARGET_DIR/tap.sh"
        write_desktop "$HOME/.config/autostart" "$panel_path" \
            && log "The panel will start at login." \
            || warn "the autostart entry was not created; use the menu launcher instead."
    else
        rm -f "$HOME/.config/autostart/gamevip.desktop" 2>/dev/null || true
    fi

    # Marker: beside the program — unless installed into the folder this
    # script runs from, where it goes to the data dir (same rule as Windows).
    marker_path="$TARGET_DIR/$MARKER"
    if [ "$TARGET_DIR" = "$HERE" ]; then
        mkdir -p "$DATA_DIR"
        marker_path="$DATA_DIR/$MARKER"
    fi
    {
        echo "version=$VERSION"
        echo "dir=$TARGET_DIR"
        echo "autostart=$([ "$NO_AUTOSTART" -eq 0 ] && echo 1 || echo 0)"
        echo "firewall=$([ "$NO_FIREWALL" -eq 0 ] && echo 1 || echo 0)"
    } > "$marker_path" 2>/dev/null \
        && log "Install recorded in $marker_path." \
        || warn "the install record could not be written."

    log "Done. The panel is starting and the page is opening."
    log "Flip the switch ON, point the PS4 DNS at $(python3 -c 'import socket; s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(("8.8.8.8", 80)); print(s.getsockname()[0]); s.close()' 2>/dev/null || echo THIS-PC), open the store app."
    if [ "$LAUNCH" -eq 1 ]; then
        open_panel
        log "Running at http://127.0.0.1:$PANEL_PORT/ — quit from the window or $TARGET_DIR/tap.sh handles restarts."
    else
        log "Skipped starting (--no-launch). Run: $TARGET_DIR/$PANEL_BIN  (or $TARGET_DIR/tap.sh from source)"
    fi
}

open_panel() {
    # Plug-and-play: start the panel if down, wait for the port, open the page.
    # With a display and Tk, the full window comes up (same as ./tap.sh);
    # headless (servers, SSH) gets the page only. Either way the user lands
    # on the dashboard with zero further commands.
    if ! port_busy "$PANEL_PORT"; then
        mkdir -p "$DATA_DIR"
        local has_display=0 has_tk=0
        { [ -n "${DISPLAY:-}" ] || [ -n "${WAYLAND_DISPLAY:-}" ]; } && has_display=1
        python3 -c 'import tkinter' 2>/dev/null && has_tk=1
        if [ "$has_display" -eq 1 ] && [ "$has_tk" -eq 1 ]; then
            if [ -x "$TARGET_DIR/$PANEL_BIN" ]; then
                nohup "$TARGET_DIR/$PANEL_BIN" >>"$DATA_DIR/panel.log" 2>&1 &
            elif [ -f "$TARGET_DIR/tap.sh" ]; then
                nohup bash "$TARGET_DIR/tap.sh" >>"$DATA_DIR/panel.log" 2>&1 &
            else
                nohup bash "$HERE/tap.sh" --headless >>"$DATA_DIR/panel.log" 2>&1 &
            fi
        elif [ -x "$TARGET_DIR/$PANEL_BIN" ]; then
            nohup "$TARGET_DIR/$PANEL_BIN" --headless >>"$DATA_DIR/panel.log" 2>&1 &
        else
            nohup bash "${TARGET_DIR}/tap.sh" --headless >>"$DATA_DIR/panel.log" 2>&1 &
        fi
        for _ in $(seq 1 50); do
            port_busy "$PANEL_PORT" && break
            sleep 0.3
        done
    fi
    local url="http://127.0.0.1:$PANEL_PORT/"
    if command -v xdg-open >/dev/null 2>&1; then xdg-open "$url" >/dev/null 2>&1 &
    else log "Open $url yourself."; fi
}

# -- uninstall -------------------------------------------------------------------
do_uninstall() {
    log "Removing $APP_NAME..."
    ensure_sudo || SUDO=""
    stop_running >/dev/null 2>&1 || true
    rm -f "$HOME/.local/share/applications/gamevip.desktop" \
          "$HOME/.config/autostart/gamevip.desktop" \
          "$HOME/Desktop/gamevip.desktop" 2>/dev/null || true
    log "Launchers removed."
    close_firewall
    log "Firewall rules removed."
    if [ -d "$DATA_DIR" ]; then
        rm -rf "$DATA_DIR" && log "Removed $DATA_DIR." || warn "could not remove $DATA_DIR"
    fi
    # Only product files go — anything else in the folder is the user's.
    for name in "$PANEL_BIN" "gbtviptap-engine" "$MARKER" "tap.sh" \
                "app.py" "tap.py" "control.py" "panel.log" "tap.log" \
                "engine_health.json" "cache" "assets"; do
        rm -rf "$TARGET_DIR/$name" 2>/dev/null || true
    done
    if [ -d "$TARGET_DIR" ] && [ -z "$(ls -A "$TARGET_DIR" 2>/dev/null)" ]; then
        rmdir "$TARGET_DIR" 2>/dev/null && log "$TARGET_DIR is gone." || true
    else
        log "$TARGET_DIR kept files that are not part of this product."
    fi
    if [ -f /etc/systemd/resolved.conf.d/gamevip.conf ]; then
        $SUDO rm -f /etc/systemd/resolved.conf.d/gamevip.conf
        $SUDO systemctl restart systemd-resolved 2>/dev/null || true
        log "systemd-resolved stub restored."
    fi
    log "Uninstalled."
}

if [ "$UNINSTALL" -eq 1 ]; then do_uninstall; else do_install; fi
