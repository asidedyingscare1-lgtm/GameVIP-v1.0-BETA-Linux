# GameBaTo VIP Spoof

Gives the GameBaTo PS4 application a local premium answer: forged subscription
verdict, pay flags flipped free, genuine relayed everything-else with disk cache.

## Install (one click)
1. Double-click **`release/GameVIP-Setup.exe**`. The window that opens
   lists what it checked on the PC — Windows version, administrator rights, that
   ports 53 and 80 are free, and room to install — then offers the handful of
   choices that go with them (install folder, Start menu and desktop shortcuts,
   opening the firewall, starting the panel with Windows).
2. Press **Install**. Everything it does is listed in the window as it happens.
   The setup never opens a browser on its own: the finish page has an **Open the
   dashboard** button for when you want it, and ticking *Open the dashboard when
   the setup finishes* on the options page is the only way it happens by itself.
   Windows asks for administrator rights **once**, at launch; that single consent
   covers the firewall rules, the shortcuts and the optional logon task.
3. The shortcut opens **GameVIP's own window** with one switch. Flip it to ON:
   the panel starts serving and the local page opens in your browser with the
   3 PS4 steps. Flip it back to OFF to stop the spoof and free ports 53 and 80.
   The page's own switch does the same thing, and both stay in step.
4. Open the GameBaTo application. Account shows **Premium**.

Nothing needs Python: the panel and the engine ship as two compiled programs
`GameVIP.exe` (the engine rides inside it) and the setup carries it inside
itself. Neither ever opens a console window or a stray terminal. The setup
installs **the program into the folder it was run from**: put the setup where
the program should live — this project's `release/` folder, a second drive, a
stick — run it, and the program lands in that same folder, beside the setup,
with no subfolder made and nothing else added. Its working files do not land in that folder: the panel's log, the
engine's log, the store cache and the engine heartbeat all go to
`%LOCALAPPDATA%\GameBaToVipSpoof`, so the folder stays readable and the program
still works from read-only media. The install folder itself must be one this
user can write to without elevation (replacing or removing the program writes
there) and must not be a temporary folder or a system folder such as Program
Files; wherever that does not hold, the install goes to
`%LOCALAPPDATA%\Programs\GameBaToVipSpoof` instead, which is also where an
install made by an earlier build is still found and still removed from.
Uninstalling takes the product's own files and that per-user folder with it, so
a folder holding anything else of yours keeps it.

Uninstall with the same file: run it again and it offers to replace or remove the
install (or `"GameVIP-Setup.exe" --uninstall`). Removing takes the
processes, the firewall rules, the shortcuts, the logon task and the cached store
files with it. For a scripted install:

```
GameVIP-Setup.exe --silent --dir=D:\Tools\GameVIP --desktop --autostart
GameVIP-Setup.exe --silent --launch     also opens the dashboard when done
GameVIP-Setup.exe --silent --uninstall
```

A scripted install never opens a browser unless it is given `--launch`; without
it the log says so and the shortcut is how the dashboard is opened.

## Use from source
1. Double-click **TAP.bat**. It asks Windows for administrator rights once (for
   the firewall rules), then opens the dashboard and the control window above.
   No console stays open: anything the panel would have printed goes to
   `panel.log` beside it. `python app.py --headless` serves the page without the
   window, which is what a script or a service wants.
2. Flip the **switch** at the bottom of the page to ON — it glows green — then
   follow the 3 PS4 steps. If the firewall rules are missing, switching on asks
   Windows once to add them. Flipping it back to OFF stops the spoof and frees
   ports 53 and 80.
3. Open the GameBaTo application. Account shows **Premium**.

## If the tap stops right away
The panel shows the reason in the **Why it stopped** card and in the live log.

- **`Port 80 (TCP) is busy ...`** — IIS, Skype or another spoof owns 80. Close
  it, then flip the switch again.
- **`Port 53 (UDP) is busy - cannot bind 10.0.0.6:53 ...`** — something holds the
  spoof engine's own LAN address, usually a copy left running from an earlier
  session. The dashboard clears that when you switch it on; from a command line
  use `python tap.py --free-ports`.
- **Windows Internet Connection Sharing (ICS) holding `0.0.0.0:53` is not an
  error.** The tap binds this PC's LAN address instead of the wildcard, and
  Windows delivers each query to the most specific binding, so the PS4 reaches
  the tap while ICS keeps port 53 for its own sharing and hotspot DNS proxy. No
  administrator rights and no service changes are needed to serve DNS.
- **The PS4 cannot reach the PC at all** — the inbound firewall rules are
  missing. Press **Allow through** on the panel (or start TAP.bat as
  administrator) and approve the Windows prompt.

## What it does
- DNS: answers `gamebatoapi.ir` / `update.gamebatoapi.ir` with this PC,
  forwards the rest upstream (auto-picked fastest of 8.8.8.8 / 1.1.1.1 / 9.9.9.9).
  Binds the advertised LAN address rather than the wildcard so it coexists with
  Windows ICS instead of fighting it for port 53.
- HTTP: forges `/check_user_subscription_status` → Premium/active and `/login`,
  flips the pay gates and the free/upgrade flags in the genuine `/config` (the
  store sends that answer chunked, so it is unwrapped before it is edited), and
  relays the rest live.
- Relay: passes the store's answer through byte for byte — status line, framing
  and body — so a resume stays a `206`, a `HEAD` stays body-less, and a POST keeps
  its method and body. Downloads are streamed, never trimmed by a fixed ceiling.
- Cache: only a complete plain `200 GET` is stored, and only for static content
  such as pictures and update parts. Live API and config answers are always
  refetched, and a body that was cut short (a stalled or unfinished transfer) is
  never cached. Anything stale or half-stored is cleared when the tap starts, so
  a damaged copy cannot be replayed to the application.
- Firewall: the panel checks the three inbound rules (UDP 53, TCP 80, TCP 8899)
  and adds any that are missing with a single Windows prompt.
- Ports: checks UDP 53 and TCP 80 before serving and names whoever holds them.
  With `--free-ports` it also clears a leftover tap, or stops ICS when ICS has
  taken the address the tap needs.
- Auto-detects your LAN address (internet-route adapter wins; private ranges
  preferred; virtual adapters skipped). Binds all adapters, advertises one.
- The dashboard is styled as a green terminal panel: labels, values and copy are
  the same mint green the log's request lines use, in monospace, over faint
  scanlines, with a `>` prompt on each section label and a blinking cursor beside
  the title, and the PS4 setup instructions and the tile values are the brighter
  mint (`#8bffd0`) so the words you actually read stand out against it. The state
  is colour-coded — **off is red** (the switch and the state word)
  while green means serving and draws the glowing outline around the switch box,
  which is left off when idle. Every line of the live log is that same green;
  what separates them is weight, not hue, because bold marks a start, a stop or a
  failure and italic marks a note. The logo artwork keeps its own colours — only
  the tile behind it is the panel's green.
- The control window is the installed program's own face, in the setup's design
  system rather than the page's: the same charcoal surfaces, hairlines and red
  brand, the supplied emblem and metallic wordmark in the header, and the same
  Segoe UI labels. That artwork arrives painted on a plate of its own
  background, which shows as a rectangle against the header; the plate is
  composited into the window's own tone at build time
  (`tools/clear_branding_frames.py`, written to `assets/branding_t/`, which the
  window prefers), so only the emblem and the wordmark are left on the header.
  Cutting the plate out as transparent pixels is not possible for this art --
  the emblem is a dark figure on black, where the figure's black and the plate's
  black are the same connected black, so keying at any tolerance that clears the
  plate also eats the face and the cloak (checked by keying one at 2, 4, 6 and 8
  and rendering each over magenta). The largest change any single pixel takes
  from the treatment is the gap between the two tones, a few levels out of 255,
  and `tools/control_audit.py` reads every picture on screen back to check that
  its corners are the surface behind it. The window frame is asked for in dark mode and its caption
  painted the window's own grey (DWM attributes; Windows 11 takes the exact
  colour, Windows 10 1809+ gets the system dark bar, and older builds keep the
  light one), so nothing at the top of the window reads as someone else's. State is colour-coded the same way the page does it — green
  **CONNECTED** while serving, dim red **DISCONNECTED** when idle, amber while a
  flip is still in flight — over one switch that turns green and slides
  right, drawn bare on the card: no box and no ring around it, with keyboard
  focus showing only as a thin halo hugging the pill. Its track and knob are
  rasterised instead of drawn with Tk's own shapes, because the canvas has no
  anti-aliasing and a round edge comes out stair-stepped: the artwork is
  computed from a signed distance and handed to Tk as a PNG with a transparent
  background, so the curve is smooth, only the pill and the knob are painted,
  the card itself shows through and no rectangle of the switch's own can ever
  appear behind it. The shipped program still carries no image library, and
  `tools/control_audit.py` reads the result back off the screen — counting the
  blended pixels along each curve, and proving the transparency by turning the
  card magenta behind one throwaway window — a `PS4 DNS` line with
  this PC's address, an engine line, and the same
  red primary button the setup footer uses, for the local page. Every label was
  checked for a readable contrast ratio against the surface behind it, and the
  window is sized so nothing clips, at the reference 100% scale
  (`tools/control_audit.py` photographs both states and checks all of it).
- The dashboard is one switch at the bottom of the page: ON serves the PS4, OFF
  releases ports 53 and 80. While serving, the line beside the switch reads
  **Premium Access Granted**, but only once the intrusion feed below has played out;
  while that run is still going the line reads **Breaching** in amber and the grant
  is held back, so the green never lands before the breach does. Idle it reads
  **Access Normal**. The switch, clock, cache and firewall tiles all
  repaint in place every 2s, and the **live log** lives behind the cog button in
  the top right, so the page itself stays short enough to fit without scrolling —
  the small card between the PS4 steps and the switch is the **intrusion feed**
  (see below), not the log. That sheet has a **Blur
  details** switch: turn it on and every address the
  panel shows — the DNS target, the setup line, the log — fogs over, so a
  screenshot or a shared screen never carries your addresses out of the room. The
  choice is remembered in the browser that made it; nothing is blurred by default.
  A spoof that dies shows the **Why it stopped** card with the reason instead of
  silently vanishing, and the log colours requests, hints and crashes so a
  failure stands out. Calls the application makes for itself are left out of that
  list, so what you see is the tap's own work; every line is still written to
  `tap.log` if you want the full detail.
- The console is dressed as an intrusion, and all of it is theatre: a code-rain
  backdrop, a phosphor flicker, a glitch flash at the moment the spoof changes
  state, and the **intrusion feed** in the small card between the PS4 steps
  and the switch — a breach played out like a Kali console: a `root@kali:~#` prompt
  typing invented tools (*knockknock*, *doorbell*, *peekaboo*, *milkandcookies*,
  *goodvibes*, *honestybypass*, *ducttape*, *kettle*, *victorylap* and friends) —
  none of which exist to install or run — each hanging for a few seconds before
  its invented output lands, over a glowing progress bar. Each flip draws a fresh
  opener, four middle jokes and a sign-off at random, so no two runs read alike;
  the lines are jokes about knocking on the store's door, never a description of
  what the tap does. The switch's green appears only once the last line has been
  typed. Every one of those lines is invented in the browser;
  nothing in the feed is telemetry, none of it reaches `tap.log`, and the feed
  falls silent when the spoof is off. The real state stays in the switch, the
  tiles and the live log behind the cog.
- Switch the spoof off to release ports 53 and 80 and leave the panel idle for
  the next time. The control window is also the way out: closing it with its X
  stops the spoof and ends the panel, after one confirmation while the spoof is
  serving. The page keeps its own close button
  (`http://127.0.0.1:8899/quit`), so neither handle is the only one.
- Panel actions (the switch, clear cache, allow through firewall) are accepted
  only from requests that arrive on 127.0.0.1, so a page in another browser tab
  cannot flip the spoof off behind your back.
- Nothing is uploaded anywhere. Keys stay on your machine.

## Overrides
- `python tap.py --ip=192.168.1.50` — advertise and bind a specific address.
- `python tap.py --upstream=1.1.1.1` — force an upstream DNS.
- `python tap.py --free-ports` — clear a leftover tap, or stop ICS if it holds
  the tap's own address.
- `python tap.py --dns-port=5533 --http-port=8080` — test the engine on spare
  ports without touching live DNS (the PS4 still needs the real 53/80).
- `python tap.py --origin=127.0.0.1:8099 --http-port=8080` — relay to a stand-in
  store instead of the real one, for testing the relay without touching the application.
- `python app.py --port=8898` — run a second dashboard beside the first.

## Files
- `release/GameVIP-Setup.exe` — the installer: the bundled program, the readme
  and the icon are all inside it, so it is the one file to hand over.
- `GameVIP.exe` — the one bundled program (dashboard on
  http://127.0.0.1:8899/ with the spoof engine inside), no console window. It is
  built into `release/` beside the setup, so the released folder holds the
  program and the way to install it: run it straight from there, or hand over
  the setup, which installs it as one file.
- `app.py` — dashboard UI source, stdlib only.
- `tap.py` — the spoof engine source (forged DNS answers + byte-exact relay),
  stdlib only.
- `setup_wizard.py` — the installer's source: same window, same steps, and it
  still installs from beside itself when run as a script.
- `build_release.py`, `tools/make_icon.py`, `requirements.txt` — rebuild the icon,
  both programs and the one-file setup: `pip install -r requirements.txt` then
  `python build_release.py`.
- `TAP.bat` — double-click to launch headless from source; self-elevates to
  administrator.
- `assets/gbt.ico` — the icon, drawn by `tools/make_icon.py` rather than stored.
  Two things happen there. The logo's flat black plate is keyed to transparency
  (alpha only: not one artwork pixel is recoloured), so no black square is ever
  drawn behind the hood; and the hood is then laid on the panel's own mark tile
  — the rounded `#03090c` square with the green rim and glow the dashboard
  paints beside its title — with the tile's corners left genuinely transparent.
  The tile's values are copied from that `app.py` rule and `verify_all.py`
  fails if the two drift apart. Same for the stored `assets/gamevip.ico`, which
  the tool rebuilds too. Sizes of 32px and below — what an Explorer list or the
  taskbar actually draws — get their own treatment: a thicker, brighter rim,
  the artwork lifted so its red ring and eyes carry, and no outer glow, because
  the drawn-for-48px composition is a murky square at 16px.
- `panel.log`, `tap.log`, `engine_health.json`, `cache/` — the working files:
  what the headless panel prints, what the engine logs, the engine's heartbeat
  and the relay cache. Run from source they appear beside the script; installed,
  they live in `%LOCALAPPDATA%\GameBaToVipSpoof`, so the install folder holds the
  program and nothing else. All four are auto-created and safe to delete.
- `install.txt` — the marker that records what the install did. Installed into
  a folder of its own it sits there, hidden, so Explorer shows the program
  alone; installed into the folder the setup was run from it goes to
  `%LOCALAPPDATA%\GameBaToVipSpoof` instead, so nothing of ours is added beside
  the setup.
- `INSTALL.bat` / `Installer.ps1` — the earlier PowerShell installer, kept for
  source checkouts; the compiled setup above replaces it.
