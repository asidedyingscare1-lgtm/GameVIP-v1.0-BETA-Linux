"""Design audit for the control window: geometry, clipping, contrast, states.

Builds the real window against a fake panel -- no engine, no PowerShell, no
browser -- photographs it disconnected and connected, and flags anything that
overflows the frame, clips its own text, or drops below a readable contrast
ratio. It also proves the window leaves no timer behind when it closes.

    python tools/control_audit.py    (exit 0 = clean)
"""
import ctypes
import math
import os
import sys
import time
import tkinter as tk
from ctypes import wintypes

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import control

PROBLEMS = []
SHOTS = []
AA_SMALL = 4.5          # WCAG AA for body text
AA_LARGE = 3.0          # WCAG AA for 18pt+/14pt bold text


def problem(text):
    PROBLEMS.append(text)
    print('  PROBLEM: %s' % text)


def relative_luminance(colour):
    """WCAG relative luminance of a '#rrggbb' colour."""
    channels = []
    for index in (1, 3, 5):
        value = int(colour[index:index + 2], 16) / 255.0
        channels.append(value / 12.92 if value <= 0.03928
                        else ((value + 0.055) / 1.055) ** 2.4)
    red, green, blue = channels
    return 0.2126 * red + 0.7152 * green + 0.0722 * blue


def contrast_ratio(foreground, background):
    lighter, darker = sorted((relative_luminance(foreground),
                              relative_luminance(background)), reverse=True)
    return (lighter + 0.05) / (darker + 0.05)


def walk(window, widget, path='root', stage_ids=frozenset()):
    """Flag widgets that leave the frame or clip their own text."""
    try:
        x = widget.winfo_rootx() - window.winfo_rootx()
        y = widget.winfo_rooty() - window.winfo_rooty()
        width, height = widget.winfo_width(), widget.winfo_height()
    except Exception:
        return
    frame_w, frame_h = window.winfo_width(), window.winfo_height()
    cls = widget.winfo_class()
    text = ''
    try:
        if cls in ('Label', 'Button'):
            text = str(widget.cget('text'))
    except Exception:
        pass
    if width > 1 and height > 1 and path != 'root':
        if x < 0 or y < 0 or x + width > frame_w + 2 or y + height > frame_h + 2:
            problem('%s %s at (%d,%d) %dx%d text=%r leaves the %dx%d frame'
                    % (cls, path, x, y, width, height, text[:40], frame_w, frame_h))
    if cls == 'Label' and text:
        check_clipping(widget, path, text, width, height)
        check_contrast(widget, path, text)
    for index, child in enumerate(widget.winfo_children()):
        walk(window, child, '%s/%s%d' % (path, child.winfo_class(), index),
             stage_ids)


def check_clipping(widget, path, text, width, height):
    """A label must have room for its text, wrapped or not."""
    try:
        needed = widget.tk.call('font', 'measure', widget.cget('font'), text)
        wrap = int(widget.cget('wraplength') or 0)
    except Exception:
        return
    if width <= 10:
        return
    if wrap > 0:
        # Wrapping labels are judged by wrapped height, not by one long line,
        # and Tk wraps at whichever is smaller: the setting or the widget.
        effective = min(wrap, width)
        lines = max(1, math.ceil(needed / float(effective)))
        try:
            line = int(widget.tk.call('font', 'metrics', widget.cget('font'),
                                      '-linespace'))
        except Exception:
            return
        if height + 2 < lines * line:
            problem('%s %s needs %d wrapped lines (%dpx) in %dpx: %r'
                    % (widget.winfo_class(), path, lines, lines * line,
                       height, text[:60]))
    elif needed > width + 2:
        problem('%s %s text clipped: needs %dpx in %dpx: %r'
                % (widget.winfo_class(), path, needed, width, text[:60]))


def check_contrast(widget, path, text):
    """Read the label's own colours back and hold them to WCAG AA."""
    try:
        foreground = str(widget.cget('fg'))
        background = str(widget.cget('bg'))
        font = str(widget.cget('font'))
    except Exception:
        return
    if not foreground.startswith('#') or not background.startswith('#'):
        return
    size = 10.0
    bold = 'Semibold' in font or 'Bold' in font
    for token in font.replace('{', ' ').replace('}', ' ').split():
        try:
            size = float(token)
        except ValueError:
            pass
    floor = AA_LARGE if (bold and size >= 14) or size >= 18 else AA_SMALL
    ratio = contrast_ratio(foreground, background)
    if ratio < floor:
        problem('%s %s contrast %.2f:1 below %.1f for %r (%s on %s)'
                % (widget.winfo_class(), path, ratio, floor, text[:40],
                   foreground, background))


def branding_loaded(panel):
    """The window must find its art, in the checkout and in the bundle."""
    for name, subsample in (('sidebar-emblem.png', 4),
                            ('sidebar-wordmark.png', 2)):
        if panel.images.get(name, subsample) is None:
            problem('%s did not load: the window is falling back to text'
                    % name)


def count_close_to(image, colour, tolerance=26, box=None):
    """How many pixels are within tolerance of a colour, inside an optional box."""
    wanted = tuple(int(colour[index:index + 2], 16) for index in (1, 3, 5))
    x0, y0, x1, y1 = box or (0, 0, image.width, image.height)
    pixels = image.load()
    total = 0
    for x in range(x0, x1):
        for y in range(y0, y1):
            here = pixels[x, y][:3]
            if all(abs(here[i] - wanted[i]) <= tolerance for i in range(3)):
                total += 1
    return total


def top_window(panel):
    """The operating system's handle for this panel's window."""
    user32 = ctypes.windll.user32
    return user32.GetParent(panel.winfo_id()) or panel.winfo_id()


def is_foreground(panel):
    """Is this window the one the system counts as active?"""
    if os.name != 'nt':
        return True
    try:
        return ctypes.windll.user32.GetForegroundWindow() == top_window(panel)
    except (AttributeError, OSError):
        return True


def activate(panel):
    """Hand the foreground to this window, the way Windows requires.

    focus_force is a request, and it is not always granted: a window that is
    not the foreground one has Windows draw its own min/max/close buttons
    dimmed, which the caption check would otherwise read by accident and report
    as a contrast failure that has nothing to do with the window. A stray input
    event is the documented way to be allowed to pass the foreground on.
    """
    try:
        user32 = ctypes.windll.user32
        window = top_window(panel)
        if user32.GetForegroundWindow() == window:
            return
        user32.keybd_event(0, 0, 0, 0)
        user32.SetForegroundWindow(wintypes.HWND(window))
    except (AttributeError, OSError):
        pass


def raise_window(panel, activate_window=False):
    """Put the window on top before reading it, and settle it.

    These checks photograph the screen, so what they measure has to be this
    window and not whatever else is on that patch of desk. Every check raises
    its own window: one that leans on activation alone reads a neighbour the
    moment the focus moves on.

    ``activate_window`` is for the caption check, which has to read an active
    window. Everywhere else the window keeps the focus it opened with, and the
    switch inside it stays unfocused so no halo is drawn.
    """
    try:
        panel.lift()
        panel.attributes('-topmost', True)
        if activate_window:
            panel.focus_force()
        else:
            panel.focus_set()          # the window, never the switch inside it
    except tk.TclError:
        pass
    panel.update()
    if activate_window:
        activate(panel)
    time.sleep(0.4)
    panel.update()
    return is_foreground(panel)


def lower_window(panel):
    """Hand the desk back: the window must not stay on top of the user's."""
    try:
        panel.attributes('-topmost', False)
    except tk.TclError:
        pass


def window_frame(panel):
    """(left, top, right, bottom) of the whole window, caption bar included."""
    window = top_window(panel)
    rect = wintypes.RECT()
    ctypes.windll.user32.GetWindowRect(wintypes.HWND(window), ctypes.byref(rect))
    return rect.left, rect.top, rect.right, rect.bottom


def check_caption_bar():
    """Windows draws the caption bar, so its colour has to be read back."""
    status = {'running': False, 'ip': '10.0.0.6', 'note': ''}
    panel = control.ControlPanel(
        state=lambda: dict(status), start=lambda: None, stop=lambda: None,
        open_page=lambda: None, quit_panel=lambda: None)
    panel.update()
    time.sleep(0.5)                 # let the second DWM pass land
    panel.update()
    try:
        from PIL import ImageGrab
        active = raise_window(panel, activate_window=True)
        print('  caption read while the window is %s'
              % ('active' if active else 'NOT active'))
        left, top, right, bottom = window_frame(panel)
        caption = ImageGrab.grab(bbox=(left, top, right, top + 28)).convert('RGB')
        wanted = tuple(int(control.C['sidebar'][index:index + 2], 16)
                       for index in (1, 3, 5))
        pixels = [caption.getpixel((x, y))
                  for x in range(160, max(161, caption.width - 220), 3)
                  for y in range(6, 24, 3)]
        average = tuple(sum(here[i] for here in pixels) // len(pixels)
                        for i in range(3))
        print('  caption bar %s near %s' % (average, wanted))
        if max(average) > 90:
            problem('the caption bar is still light %s (Windows default)'
                    % (average,))
        if max(abs(average[i] - wanted[i]) for i in range(3)) > 60:
            problem('the caption bar %s does not match the window grey %s'
                    % (average, wanted))
        # The title and the system buttons are drawn by Windows on that bar,
        # so their contrast against it is measured rather than assumed.
        for label, box in (('title', (40, 6, 200, 24)),
                           ('window buttons', (caption.width - 170, 6,
                                               caption.width - 6, 24))):
            strokes = [(x, y) for x in range(box[0], box[2])
                       for y in range(box[1], box[3])
                       if max(abs(caption.getpixel((x, y))[index] - average[index])
                              for index in range(3)) > 25]
            if not strokes:
                problem('nothing is drawn on the caption bar for the %s' % label)
                continue
            stroke = tuple(sum(caption.getpixel(spot)[index] for spot in strokes)
                           // len(strokes) for index in range(3))
            ratio = contrast_ratio('#%02x%02x%02x' % stroke,
                                   '#%02x%02x%02x' % average)
            print('  caption %s %.2f:1' % (label, ratio))
            if label == 'window buttons' and not active:
                # Windows' own buttons, drawn dimmed because this window is not
                # the active one: that reading says nothing about the window, so
                # it is reported and not judged.
                print('    measured on an inactive window: not asserted')
                continue
            if ratio < AA_LARGE:
                problem('the caption %s is lost on the bar: %.2f:1'
                        % (label, ratio))
    finally:
        lower_window(panel)
        panel.destroy()


def check_switch_chrome():
    """The switch must sit on the card bare: no box, no ring while it rests."""
    status = {'running': False, 'ip': '10.0.0.6', 'note': ''}
    panel = control.ControlPanel(
        state=lambda: dict(status), start=lambda: None, stop=lambda: None,
        open_page=lambda: None, quit_panel=lambda: None)
    panel.update()
    panel.poll()
    panel.update()
    raise_window(panel)
    try:
        from PIL import ImageGrab
        x, y = panel.winfo_rootx(), panel.winfo_rooty()
        shot = ImageGrab.grab(bbox=(x, y, x + panel.winfo_width(),
                                    y + panel.winfo_height())).convert('RGB')
        left = panel.switch.winfo_rootx() - x
        top = panel.switch.winfo_rooty() - y
        rectangle = (left, top, left + panel.switch.winfo_width(),
                     top + panel.switch.winfo_height())
        resting = count_close_to(shot, control.C['brand_hot'], 40, rectangle)
        if resting:
            problem('the resting switch is ringed in brand red (%d px)' % resting)
        # Just outside the switch, the card must show through untouched.
        width, height = panel.switch.winfo_width(), panel.switch.winfo_height()
        edges = [(left - 1, top - 1, left + width + 1, top),
                 (left - 1, top, left, top + height)]
        for box in edges:
            painted = count_close_to(shot, control.C['brand_hot'], 60, box)
            if painted:
                problem('the switch is framed by %d painted pixels at %s'
                        % (painted, box))
        if shot.getpixel((left + 1, top + 1)) != shot.getpixel((left - 4, top - 4)):
            problem('the switch canvas is not the colour of the card behind it')
        panel.switch.focus_set()
        panel._draw_switch()
        panel.update()
        return panel
    finally:
        if panel.winfo_exists():
            lower_window(panel)
            panel.destroy()


def blend_pixels(image, inner, outer, box, margin=8):
    """Count pixels that mix two colours: the mark of a softened edge.

    An anti-aliased curve passes through the colours in between; a shape drawn
    by Tk's own canvas steps straight from one colour to the other and scores
    zero here, which is exactly what the switch used to look like.
    """
    inside = tuple(int(inner[index:index + 2], 16) for index in (1, 3, 5))
    outside = tuple(int(outer[index:index + 2], 16) for index in (1, 3, 5))
    x0, y0, x1, y1 = box
    total = 0
    for x in range(x0, x1):
        for y in range(y0, y1):
            here = image.getpixel((x, y))[:3]
            if all(abs(here[i] - inside[i]) <= margin for i in range(3)):
                continue                            # solidly the shape itself
            if all(abs(here[i] - outside[i]) <= margin for i in range(3)):
                continue                            # solidly the surface behind
            if all(min(inside[i], outside[i]) - margin <= here[i]
                   <= max(inside[i], outside[i]) + margin for i in range(3)):
                total += 1
    return total


def check_switch_edges():
    """The switch's curves must be anti-aliased, not stair-stepped.

    Tk's canvas has no anti-aliasing, so the track's caps and the knob used to
    come out visibly stepped. Read the real window back and count the pixels on
    each curve that mix the colours either side of it: a smoothed edge has
    them, a hard one has none.
    """
    status = {'running': False, 'ip': '10.0.0.6', 'note': ''}
    panel = control.ControlPanel(
        state=lambda: dict(status), start=lambda: None, stop=lambda: None,
        open_page=lambda: None, quit_panel=lambda: None)
    panel.update()
    panel.poll()
    panel.update()
    raise_window(panel)             # the window has to be the one on screen
    try:
        from PIL import ImageGrab
        x, y = panel.winfo_rootx(), panel.winfo_rooty()
        shot = ImageGrab.grab(bbox=(x, y, x + panel.winfo_width(),
                                    y + panel.winfo_height())).convert('RGB')
        left = panel.switch.winfo_rootx() - x
        top = panel.switch.winfo_rooty() - y
        track = control.C['track_off']
        # Idle, so the knob sits at the left end: the track's own curves are the
        # right cap, and the knob's circle is checked on its own.
        track_edges = blend_pixels(shot, track, control.C['row'],
                                   (left + 2, top + 6, left + control.SWITCH_W - 2,
                                    top + control.SWITCH_H - 6))
        radius = int(control.KNOB_RADIUS)
        knob_edges = blend_pixels(
            shot, control.C['faint'], track,
            (left + control.TRACK_LEFT - radius - 2, top + control.TRACK_TOP - 2,
             left + control.TRACK_LEFT + radius + 2, top + control.TRACK_BOTTOM + 2))
        print('  switch edge blends: track %d px, knob %d px'
              % (track_edges, knob_edges))
        if track_edges < 20:
            problem('the track edge is not smoothed: only %d blended pixels'
                    % track_edges)
        if knob_edges < 25:
            problem('the knob edge is not smoothed: only %d blended pixels'
                    % knob_edges)
        # A curve drawn by the canvas is a single hard step, so the swipe has to
        # show the artwork is an image and not the drawn fallback.
        kinds = set()
        for item in panel.switch.find_all():
            kinds.add(panel.switch.type(item))
        if kinds != {'image'}:
            problem('the switch fell back to drawn shapes: %r' % sorted(kinds))
    finally:
        lower_window(panel)
        panel.destroy()


def check_switch_transparency():
    """Nothing but the switch may be painted: the artwork has to carry alpha.

    A Tk canvas has no transparency of its own, so "transparent" can only mean
    the image's own pixels are. The proof is to put a colour behind it that the
    artwork could not have baked in -- the card is turned magenta for one
    throwaway window -- and check that the pixels around the pill turn with it
    instead of staying the card grey.
    """
    original = control.C['row']
    control.C['row'] = '#ff00ff'
    status = {'running': False, 'ip': '10.0.0.6', 'note': ''}
    panel = control.ControlPanel(
        state=lambda: dict(status), start=lambda: None, stop=lambda: None,
        open_page=lambda: None, quit_panel=lambda: None)
    panel.update()
    panel.poll()
    panel.update()
    raise_window(panel)
    try:
        from PIL import ImageGrab
        x, y = panel.winfo_rootx(), panel.winfo_rooty()
        shot = ImageGrab.grab(bbox=(x, y, x + panel.winfo_width(),
                                    y + panel.winfo_height())).convert('RGB')
        left = panel.switch.winfo_rootx() - x
        top = panel.switch.winfo_rooty() - y
        width, height = panel.switch.winfo_width(), panel.switch.winfo_height()
        behind = (255, 0, 255)
        # the switch's own canvas corners, all clear of the pill
        corners = [(left + 1, top + 1), (left + width - 2, top + 1),
                   (left + 2, top + height - 2),
                   (left + width - 2, top + height - 2)]
        seen = [shot.getpixel(spot) for spot in corners]
        print('  switch corners over a magenta card: %s' % (seen,))
        for spot, here in zip(corners, seen):
            if here != behind:
                problem('the switch paints its own background at %s: %s, not the '
                        'card %s behind it' % (spot, here, behind))
        middle_x = (control.TRACK_LEFT + control.TRACK_RIGHT) // 2
        middle_y = (control.TRACK_TOP + control.TRACK_BOTTOM) // 2
        pill = shot.getpixel((left + middle_x, top + middle_y))
        if pill == behind:
            problem('the track did not paint over the card at all: %s' % (pill,))
    finally:
        control.C['row'] = original
        lower_window(panel)
        panel.destroy()


def image_widgets(widget, path='root', found=None):
    """Every widget that draws a picture, with its place in the window tree."""
    found = [] if found is None else found
    try:
        has_image = bool(widget.cget('image'))
    except Exception:
        has_image = False
    if has_image:
        found.append((path, widget))
    for index, child in enumerate(widget.winfo_children()):
        image_widgets(child, '%s/%s%d' % (path, child.winfo_class(), index),
                      found)
    return found


def check_artwork_frames():
    """Drawn art must not carry a frame of its own onto the window.

    The supplied artwork ships on a plate of its own background, which reads as
    a rectangle on the header's grey. Whatever the treatment -- transparent
    pixels, or the frame composited into the window's own colour -- the test is
    the same: the corners of every picture on screen have to be the surface
    behind it, and not some tone the art carried with it.
    """
    status = {'running': False, 'ip': '10.0.0.6', 'note': ''}
    panel = control.ControlPanel(
        state=lambda: dict(status), start=lambda: None, stop=lambda: None,
        open_page=lambda: None, quit_panel=lambda: None)
    panel.update()
    panel.poll()
    panel.update()
    time.sleep(0.3)
    panel.update()
    try:
        from PIL import ImageGrab
        raise_window(panel)
        x, y = panel.winfo_rootx(), panel.winfo_rooty()
        width, height = panel.winfo_width(), panel.winfo_height()
        shot = ImageGrab.grab(bbox=(x, y, x + width, y + height)).convert('RGB')
        pictures = image_widgets(panel)
        if not pictures:
            problem('the window draws no artwork at all')
        for path, widget in pictures:
            left = widget.winfo_rootx() - x
            top = widget.winfo_rooty() - y
            w, h = widget.winfo_width(), widget.winfo_height()
            if w < 4 or h < 4:
                continue
            corners = [(left + 1, top + 1), (left + w - 2, top + 1),
                       (left + 1, top + h - 2), (left + w - 2, top + h - 2)]
            spots = [(px, py) for px, py in corners
                     if 0 <= px < width and 0 <= py < height]
            beside = [(left - 3, top + h // 2), (left + w // 2, top - 3),
                      (left + w + 2, top + h // 2)]
            around = [(px, py) for px, py in beside
                      if 0 <= px < width and 0 <= py < height]
            if len(spots) < 4 or not around:
                continue
            surface = shot.getpixel(around[0])
            seen = [shot.getpixel(spot) for spot in spots]
            print('  %s %dx%d at (%d,%d) frame %s, surface %s'
                  % (path, w, h, left, top, seen, surface))
            for spot, here in zip(spots, seen):
                if here != surface:
                    problem('the art at %s carries its own frame: %s at %s on a '
                            '%s surface' % (path, here, spot, surface))
    finally:
        lower_window(panel)
        panel.destroy()


def check_states(off_path, on_path):
    """The two states must look different, and each must show its own colour."""
    try:
        from PIL import Image
        off = Image.open(off_path).convert('RGB')
        on = Image.open(on_path).convert('RGB')
    except Exception as error:
        problem('cannot compare the two states: %s' % error)
        return
    for name, image in (('disconnected', off), ('connected', on)):
        if count_close_to(image, control.C['bg']) == image.width * image.height:
            problem('the %s window is one flat colour' % name)
    green_off = count_close_to(off, control.C['ok'])
    green_on = count_close_to(on, control.C['ok'])
    red_off = count_close_to(off, control.C['bad'])
    red_on = count_close_to(on, control.C['bad'])
    if green_on < 200:
        problem('the connected window shows almost no green (%d px)' % green_on)
    if green_off > green_on // 4:
        problem('the disconnected window is already green (%d px)' % green_off)
    if red_off < 100:
        problem('the disconnected window shows no red state word (%d px)' % red_off)
    if red_on > red_off // 2:
        problem('the connected window still reads red (%d px)' % red_on)


def audit(label, running, note, shot_name):
    """Build the window in one state and report on it."""
    status = {'running': running, 'ip': '10.0.0.6', 'note': note}
    started = []
    panel = control.ControlPanel(
        state=lambda: dict(status),
        start=lambda: started.append('start'),
        stop=lambda: started.append('stop'),
        open_page=lambda: started.append('open'),
        quit_panel=lambda: started.append('quit'))
    panel.update()
    panel.poll()                       # paint the state without waiting a tick
    panel.update()
    time.sleep(0.3)
    panel.update()
    frame = (panel.winfo_width(), panel.winfo_height())
    print('=== %s window=%dx%d' % ((label,) + frame))
    before = len(PROBLEMS)
    branding_loaded(panel)
    walk(panel, panel)
    if len(PROBLEMS) == before:
        print('  layout clean')
    # The screenshots are evidence, so they are taken from a window that is on
    # top rather than from whatever happened to be on that patch of screen.
    raise_window(panel)
    save_shot(panel, shot_name)
    lower_window(panel)
    panel.destroy()
    leftover = panel.tk.call('after', 'info')
    if leftover:
        problem('%s left timers behind after close: %r' % (label, leftover))
    return frame


def save_shot(panel, name):
    """Photograph the real window at its own position, like the setup tools."""
    try:
        from PIL import ImageGrab
        x, y = panel.winfo_rootx(), panel.winfo_rooty()
        width, height = panel.winfo_width(), panel.winfo_height()
        shot = ImageGrab.grab(bbox=(x, y, x + width, y + height))
        path = os.path.join('build', name)
        shot.save(path)
        SHOTS.append((path, shot.size, (width, height)))
        print('  shot %s %s' % (path, shot.size))
    except Exception as error:
        print('  shot skipped: %s' % error)


# The window as a fresh install shows it, then serving.
check_caption_bar()
check_switch_chrome()
check_switch_edges()
check_switch_transparency()
check_artwork_frames()
off_frame = audit('disconnected', False, '', 'control_off.png')
on_frame = audit('connected', True, 'Ports 53 and 80 are serving.',
                 'control_on.png')
if off_frame != on_frame:
    problem('the window changes size between states: %s then %s'
            % (off_frame, on_frame))
check_states(os.path.join('build', 'control_off.png'),
             os.path.join('build', 'control_on.png'))


# -- the switch must do what its label promises -------------------------------
def flow():
    """ON starts and opens the page, OFF disconnects, close quits the panel."""
    status = {'running': False, 'ip': '10.0.0.6', 'note': ''}
    called = []
    panel = control.ControlPanel(
        state=lambda: dict(status),
        start=lambda: (called.append('start'), status.update(running=True)),
        stop=lambda: (called.append('stop'), status.update(running=False)),
        open_page=lambda: called.append('page'),
        quit_panel=lambda: called.append('quit'))
    panel.update()
    panel.switch.event_generate('<Button-1>')     # the real click path
    panel.update()
    time.sleep(0.2)
    panel.poll()
    panel.update()
    if called[:1] != ['start']:
        problem('clicking the switch on did not start the spoof: %r' % called)
    if called[1:2] != ['page']:
        problem('switching on did not open the local page: %r' % called)
    if 'CONNECTED' not in panel.state_label.cget('text'):
        problem('the window still reads %r while serving'
                % panel.state_label.cget('text'))
    if panel.pending is not None:
        problem('the window never settled after switching on')
    # a second poll must not open the page again
    panel.poll()
    if called.count('page') != 1:
        problem('the page opened %d times for one flip' % called.count('page'))

    panel.switch.event_generate('<Button-1>')
    panel.update()
    time.sleep(0.2)
    panel.poll()
    panel.update()
    if called[-1] != 'stop':
        problem('clicking the switch off did not stop the spoof: %r' % called)
    if 'DISCONNECTED' not in panel.state_label.cget('text'):
        problem('the window still reads %r after switching off'
                % panel.state_label.cget('text'))

    # a spoof started from the page itself must not throw a second tab open
    called.clear()
    status['running'] = True
    panel.poll()
    if 'page' in called:
        problem('an outside start opened the page from the window')

    status['running'] = False
    panel.CONFIRM_CLOSE = False                   # no dialog in a check run
    panel.close()
    panel.update()
    if 'quit' not in called:
        problem('closing the window did not end the panel: %r' % called)
    leftover = panel.tk.call('after', 'info')
    if leftover:
        problem('the closed window left timers behind: %r' % leftover)


flow()

for path, size, frame in SHOTS:
    if size != frame:
        problem('%s came out %s, not the window frame %s' % (path, size, frame))

print('\n%d problems.' % len(PROBLEMS))
sys.exit(1 if PROBLEMS else 0)
