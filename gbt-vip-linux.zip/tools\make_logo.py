"""Draw assets/logo.png: the green rings mark on a dark plate (PIL)."""
from PIL import Image, ImageDraw

SIZE = 512
BG = (4, 12, 9)
RING_OUTER = (74, 232, 148)
RING_MID = (47, 143, 93)
CORE = (220, 247, 234)

img = Image.new('RGB', (SIZE, SIZE), BG)
draw = ImageDraw.Draw(img)
cx = cy = SIZE // 2
# soft outer glow: stacked fading circles
for radius, alpha in ((238, 18), (228, 26), (218, 34)):
    layer = Image.new('RGB', (SIZE, SIZE), BG)
    glow = ImageDraw.Draw(layer)
    glow.ellipse([cx - radius, cy - radius, cx + radius, cy + radius],
                 outline=RING_MID)
    img = Image.blend(img, layer, alpha / 255.0)
draw = ImageDraw.Draw(img)
draw.ellipse([cx - 208, cy - 208, cx + 208, cy + 208], outline=RING_OUTER, width=14)
draw.ellipse([cx - 148, cy - 148, cx + 148, cy + 148], outline=RING_MID, width=9)
draw.ellipse([cx - 58, cy - 58, cx + 58, cy + 58], outline=CORE, width=10)
img.save('assets/logo.png')
print('Wrote assets/logo.png')
