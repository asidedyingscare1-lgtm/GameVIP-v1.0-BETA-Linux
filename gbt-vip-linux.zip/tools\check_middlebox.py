"""Prove the product needs a second machine on the network, and what for.

The claim to check is a requirement, not a feature: the console has to be told
to ask another computer for the store's address, and that computer has to
answer the console by name and rewrite the store's answers. This runs the real
engine from source on spare ports, points it at a stand-in store instead of the
real one, and then talks to it exactly as a console on the LAN would:

    python tools/check_middlebox.py

What it asserts:
  * the DNS answer for the store's name is this machine's own LAN address
  * the engine answers that query over the network, not just on loopback
  * the console's membership question is answered here and never asked of the
    stand-in store
  * the store's settings come back with the pay gates flipped free
  * ordinary store content is relayed, byte for byte, from the stand-in
  * anything outside the store's names is forwarded upstream untouched

Exit status is 0 when every check holds, 1 otherwise. The engine is started on
spare ports and stopped again at the end; the real ports 53 and 80, the real
store and this machine's real data folder are not touched.
"""
import json
import os
import socket
import struct
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STORE_NAME = 'gamebatoapi.ir'
FAILURES = []
STORE_HITS = []


def check(label, ok, detail=''):
    print('[%s] %s%s' % ('PASS' if ok else 'FAIL', label,
                         '' if ok else ' -- %s' % detail))
    if not ok:
        FAILURES.append(label)


def free_port():
    """A port nothing is listening on, so the engine can have it."""
    probe = socket.socket()
    probe.bind(('127.0.0.1', 0))
    port = probe.getsockname()[1]
    probe.close()
    return port


def lan_ip():
    """The address this machine would use to reach the internet."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(('8.8.8.8', 80))
        return probe.getsockname()[0]
    except OSError:
        return '127.0.0.1'
    finally:
        probe.close()


# -- the stand-in store -------------------------------------------------------

CONFIG = {
    'ads_config': {'DownloadMoviePaid': '1', 'DownloadTvseriesPaid': '1',
                   'TvPaymentEnabled': '1'},
    'app_config': {'TitanUrl': '#free#false#free#|#upgrade#true#upgrade#'},
}
CONTENT = b'REAL STORE BYTES, NOT FORGED ANYWHERE'


class StandInStore(BaseHTTPRequestHandler):
    """A fake store: it would never say Premium, and every hit is recorded."""

    protocol_version = 'HTTP/1.1'

    def log_message(self, *_args):
        pass

    def do_GET(self):
        STORE_HITS.append(self.path)
        if self.path.startswith('/psx/rest-api/v100/config'):
            # The real store sends this answer chunked, so this one does too.
            body = json.dumps(CONFIG, separators=(',', ':')).encode()
            pieces = (body[:12], body[12:40], body[40:])
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Transfer-Encoding', 'chunked')
            self.end_headers()
            for piece in pieces:
                self.wfile.write(b'%x\r\n' % len(piece) + piece + b'\r\n')
            self.wfile.write(b'0\r\n\r\n')
            return
        if self.path.startswith('/check_user_subscription_status'):
            body = b'{"package_title":"Free","status":"expired"}'
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        self.send_header('Content-Length', str(len(CONTENT)))
        self.end_headers()
        self.wfile.write(CONTENT)


# -- talking to the engine the way the console does ---------------------------

def dns_query(server_ip, port, name, timeout=5):
    """Ask for one A record and return the address in the answer, or None."""
    question = b''.join(bytes([len(part)]) + part.encode()
                        for part in name.split('.')) + b'\x00'
    packet = struct.pack('!HHHHHH', 0x1234, 0x0100, 1, 0, 0, 0)
    packet += question + struct.pack('!HH', 1, 1)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(timeout)
    try:
        sock.sendto(packet, (server_ip, port))
        reply = sock.recvfrom(4096)[0]
    except OSError:
        return None
    finally:
        sock.close()
    answers = struct.unpack_from('!H', reply, 6)[0]
    offset = 12
    while reply[offset] != 0:                # the question is echoed back first
        offset += 1 + reply[offset]
    offset += 5                              # its terminating zero, type, class
    for _ in range(answers):
        if reply[offset] & 0xC0:             # a compression pointer to the name
            offset += 2
        else:
            offset += 2
        rtype, _rclass, _ttl, length = struct.unpack_from('!HHIH', reply, offset)
        offset += 10
        if rtype == 1 and length == 4:
            return socket.inet_ntoa(reply[offset:offset + 4])
        offset += length
    return None


def http_get(host_ip, port, path, timeout=10):
    """One plain GET, the way the store app makes it."""
    sock = socket.create_connection((host_ip, port), timeout=timeout)
    try:
        sock.sendall(('GET %s HTTP/1.1\r\nHost: %s\r\nConnection: close\r\n\r\n'
                      % (path, STORE_NAME)).encode())
        raw = b''
        while True:
            piece = sock.recv(65536)
            if not piece:
                break
            raw += piece
    finally:
        sock.close()
    head, _sep, body = raw.partition(b'\r\n\r\n')
    text = head.decode('iso-8859-1', 'replace')
    if 'transfer-encoding: chunked' in text.lower():
        body = dechunk(body)
    return text.splitlines()[0] if text else '', body


def dechunk(raw):
    """Read a chunked body back into the bytes it carries."""
    out, rest = b'', raw
    while True:
        line, _sep, rest = rest.partition(b'\r\n')
        try:
            size = int(line.split(b';')[0], 16)
        except ValueError:
            return out + rest
        if size == 0:
            return out
        out += rest[:size]
        rest = rest[size + 2:]


def main():
    if os.name != 'nt':
        raise SystemExit('this check drives the Windows build')
    dns_port, http_port, store_port = free_port(), free_port(), free_port()
    store = ThreadingHTTPServer(('127.0.0.1', store_port), StandInStore)
    store.daemon_threads = True
    threading.Thread(target=store.serve_forever, daemon=True).start()
    address = lan_ip()
    scratch = os.path.join(ROOT, 'build', 'middlebox')
    os.makedirs(scratch, exist_ok=True)
    log = open(os.path.join(scratch, 'engine.log'), 'wb')
    engine = subprocess.Popen(
        [sys.executable, os.path.join(ROOT, 'tap.py'),
         '--dns-port=%d' % dns_port, '--http-port=%d' % http_port,
         '--origin=127.0.0.1:%d' % store_port, '--upstream=1.1.1.1'],
        cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    try:
        print('=== engine on DNS %d, HTTP %d, stand-in store %d, this machine %s'
              % (dns_port, http_port, store_port, address))
        for _ in range(40):                      # wait for the listeners
            if dns_query(address, dns_port, STORE_NAME, 1):
                break
            if engine.poll() is not None:
                raise SystemExit('the engine stopped at once; see %s'
                                 % os.path.join(scratch, 'engine.log'))
            time.sleep(0.25)

        answered = dns_query(address, dns_port, STORE_NAME)
        check('the store name resolves to this machine',
              answered == address, 'answer was %r, this machine is %s'
              % (answered, address))
        check('the answer is served over the network, not only loopback',
              dns_query('127.0.0.1', dns_port, STORE_NAME) is None,
              'loopback answered, which a console could not use')

        verdict = dns_query(address, dns_port, 'example.com')
        check('every other name is forwarded upstream, untouched',
              verdict is None or verdict != address,
              'example.com answered %r' % (verdict,))

        status, body = http_get(address, http_port,
                                '/check_user_subscription_status?user_id=TEST')
        text = body.decode('utf-8', 'replace')
        check('the membership question is answered here as Premium',
              'Premium' in text and 'active' in text, text[:120])
        check('the stand-in store was never asked that question',
              not any('check_user_subscription_status' in hit for hit in STORE_HITS),
              repr(STORE_HITS))

        status, body = http_get(address, http_port,
                                '/psx/rest-api/v100/config?&API-KEY=TEST')
        config = body.decode('utf-8', 'replace')
        flipped = ('"DownloadMoviePaid":"0"' in config
                   and '"TvPaymentEnabled":"0"' in config
                   and '#free#true#free#' in config
                   and '#upgrade#false#upgrade#' in config)
        check('the store settings come back with the pay gates free', flipped,
              config[:200])
        check('the settings themselves came from the store',
              any('config' in hit for hit in STORE_HITS), repr(STORE_HITS))

        # A fresh name each run: a complete static answer is cached by design,
        # so a name used twice would be answered from the cache instead of the
        # store and would prove nothing about the relay.
        content_path = '/media/part-%s.bin' % os.urandom(4).hex()
        status, body = http_get(address, http_port, content_path)
        check('ordinary store content is relayed untouched',
              body == CONTENT, 'got %d bytes' % len(body))
        check('and it was fetched from the store, not invented here',
              any(content_path in hit for hit in STORE_HITS), repr(STORE_HITS))
    finally:
        engine.terminate()
        try:
            engine.wait(timeout=10)
        except subprocess.TimeoutExpired:
            engine.kill()
        log.close()
        store.shutdown()
        store.server_close()
    print('\n%d failures.' % len(FAILURES))
    return 1 if FAILURES else 0


if __name__ == '__main__':
    sys.exit(main())
