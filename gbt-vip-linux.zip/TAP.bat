@echo off
REM GameBaTo VIP Spoof - double-click this.
REM cyberfox1337x.function("gbt-vip-tap-launcher")
REM
REM Runs headless: no console window stays open. The panel is started with
REM pythonw and writes what it would have printed to panel.log next to it.
REM Administrator rights are required: the spoof engine stops Windows Internet
REM Connection Sharing when it holds UDP 53, and adds the firewall rules for
REM 53/80/8899. That is the one Windows prompt this asks for.
setlocal

net session >nul 2>&1
if errorlevel 1 (
  REM Relaunch this file elevated, hidden, so no console window appears.
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs -WindowStyle Hidden"
  exit /b
)

REM Delete first: a plain add with an existing name piles up a duplicate rule on
REM every run, so the list grows without ever saying anything new.
netsh advfirewall firewall delete rule name="GBTTap DNS" >nul 2>&1
netsh advfirewall firewall delete rule name="GBTTap HTTP" >nul 2>&1
netsh advfirewall firewall delete rule name="GBTTap Panel" >nul 2>&1
netsh advfirewall firewall add rule name="GBTTap DNS" dir=in action=allow protocol=UDP localport=53 >nul 2>&1
netsh advfirewall firewall add rule name="GBTTap HTTP" dir=in action=allow protocol=TCP localport=80 >nul 2>&1
netsh advfirewall firewall add rule name="GBTTap Panel" dir=in action=allow protocol=TCP localport=8899 >nul 2>&1
cd /d %~dp0

set GBTPY=
for /f "delims=" %%p in ('where pythonw 2^>nul') do if not defined GBTPY set GBTPY=%%p
if not defined GBTPY (
  REM A visible window on purpose: this is the one failure the user must read.
  start "" cmd /k echo Python 3.9 or newer is required by GameBaTo VIP Spoof. Install it from python.org and tick "Add python.exe to PATH", then run TAP.bat again.
  exit /b 1
)

REM Headless: pythonw has no console, so the panel never shows a window. Its
REM output goes to panel.log in case something goes wrong.
start "" /b "%GBTPY%" app.py >> panel.log 2>&1

REM Wait for the panel to answer before showing it, so the browser tab never
REM lands on a connection error. Gives up after about fifteen seconds.
powershell -NoProfile -Command "for ($i = 0; $i -lt 50; $i++) { try { $client = New-Object Net.Sockets.TcpClient; $client.Connect('127.0.0.1', 8899); $client.Close(); exit 0 } catch { Start-Sleep -Milliseconds 300 } }"
start "" http://127.0.0.1:8899/
exit /b
