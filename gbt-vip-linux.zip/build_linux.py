"""Build the Linux release: one panel binary with the engine inside.

    python3 build_linux.py            build everything into release-linux/
    python3 build_linux.py --fast     reuse built binaries

Mirrors build_release.py on Windows: the engine freezes first, then the
panel packs it as a binary so the install folder holds ONE program.
PyInstaller onefile on Linux needs no icon flag (no .ico); the .desktop
launcher carries the PNG art instead.

Needs on the BUILD machine only:  pip install -r requirements.txt
The product itself needs no Python once gamevip-panel is built.
"""
import hashlib
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
RELEASE = os.path.join(ROOT, 'release-linux')
WORK = os.path.join(ROOT, 'build', 'work-linux')
SPECS = os.path.join(ROOT, 'build')
PANEL = 'gamevip-panel'
ENGINE = 'gbtviptap-engine'


def pyinstaller(name, script, extra):
    """Run one PyInstaller build and fail loudly if it did not produce a file."""
    command = [sys.executable, '-m', 'PyInstaller', '--noconfirm', '--onefile',
               '--name', name,
               '--distpath', RELEASE, '--workpath', WORK, '--specpath', SPECS]
    command += extra + [script]
    print('=== %s' % name, flush=True)
    finished = subprocess.run(command, cwd=ROOT)
    if finished.returncode != 0:
        raise SystemExit('PyInstaller failed for %s (exit %d)' % (name, finished.returncode))
    built = os.path.join(RELEASE, name)
    if not os.path.isfile(built):
        raise SystemExit('%s was not written to %s' % (name, RELEASE))
    return built


def size_text(path):
    return '%.1f MB' % (os.path.getsize(path) / (1024 * 1024.0))


def main():
    if os.name == 'nt':
        raise SystemExit('Run this on Linux — build_release.py is the Windows build.')
    fast = '--fast' in sys.argv[1:]
    os.makedirs(RELEASE, exist_ok=True)
    os.makedirs(WORK, exist_ok=True)
    os.makedirs(SPECS, exist_ok=True)

    panel = os.path.join(RELEASE, PANEL)
    engine = os.path.join(RELEASE, ENGINE)
    if not fast or not os.path.isfile(engine):
        engine = pyinstaller(ENGINE, os.path.join(ROOT, 'tap.py'), [])
    if not fast or not os.path.isfile(panel):
        # Single-binary install: the engine rides inside the panel's bundle,
        # so the installed folder holds one program and install.sh ships one.
        extra = ['--add-binary', '%s:.' % engine]
        for folder in ('branding', 'branding_t'):
            src = os.path.join(ROOT, 'assets', folder)
            if os.path.isdir(src):
                extra += ['--add-data', '%s:assets/%s' % (src, folder)]
        panel = pyinstaller(PANEL, os.path.join(ROOT, 'app.py'), extra)

    print('\nBuilt into %s:' % RELEASE, flush=True)
    sums = []
    for name in (PANEL, ENGINE):
        path = os.path.join(RELEASE, name)
        print('  %-28s %s' % (name, size_text(path) if os.path.isfile(path) else 'MISSING'),
              flush=True)
    # The engine rides inside the panel's bundle, so the loose copy is only a
    # build input: it stays out of the released folder.
    try:
        if os.path.isfile(os.path.join(RELEASE, ENGINE)):
            os.remove(os.path.join(RELEASE, ENGINE))
    except OSError:
        pass
    for name in (PANEL,):
        path = os.path.join(RELEASE, name)
        if os.path.isfile(path):
            digest = hashlib.sha256()
            with open(path, 'rb') as handle:
                for chunk in iter(lambda: handle.read(1048576), b''):
                    digest.update(chunk)
            sums.append('%s  %s' % (digest.hexdigest(), name))
    with open(os.path.join(RELEASE, 'SHA256SUMS.txt'), 'w', encoding='utf-8') as handle:
        handle.write('\n'.join(sums) + '\n')
    print('  %-28s written' % 'SHA256SUMS.txt', flush=True)
    print('  NOTE: install.sh sets cap_net_bind_service via setcap so the', flush=True)
    print('  binary binds 53/80 without root. Re-run setcap after copying', flush=True)
    print('  the binary anywhere: sudo setcap cap_net_bind_service=+ep %s' % PANEL, flush=True)
    # Ship the installer + launcher beside the binary: the folder handed over
    # holds the program and the way to install it, same as release/ on Windows.
    for name in ('install.sh', 'tap.sh'):
        src = os.path.join(ROOT, name)
        dst = os.path.join(RELEASE, name)
        try:
            if os.path.isfile(src) and os.path.abspath(src) != os.path.abspath(dst):
                shutil.copy2(src, dst)
                os.chmod(dst, 0o755)
        except OSError:
            pass
    if not os.path.isfile(panel):
        raise SystemExit('The panel binary is missing.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
