# GameVIP — Linux

Same product as Windows (`GameVIP.exe`), native Linux command line. The
Python sources are shared (`app.py` + `tap.py` run on both); only the OS
seams differ — firewall, low-port bind, launcher, install flow.

## Fastest path (one paste, inside the extracted folder)

```bash
chmod +x install.sh tap.sh && ./install.sh
```

That single line does everything: installs missing packages (python3,
python3-tk, iproute2 via apt/dnf/pacman/zypper), asks sudo once, runs the
checks, copies the program, frees port 53, sets setcap, opens the
LAN-only firewall, writes the menu launcher + autostart — then starts the
panel and opens the page itself. Plug-and-play: no second command.
(`--no-launch` skips the autostart when scripting.)

One sudo prompt up front (firewall + setcap + resolved stub), then:

1. checks: python3.9+, ports 53/80/8899 free, disk room, Tk
2. copies the program, frees port 53 from systemd-resolved's stub
3. `setcap cap_net_bind_service` — ports 53/80 bind with **no root** after
4. opens the firewall **LAN-only** (ufw → nftables → firewalld, first wins)
5. writes the menu launcher (`~/.local/share/applications`) + autostart
6. records `install.txt`

Then run it:

```bash
./tap.sh            # panel + control window, opens the page when ready
./tap.sh --headless # page only (scripts / services)
```

Flip the switch ON, point the PS4 DNS at the address the page shows,
open the store app. Account shows **Premium**.

## Frozen build (one binary, like GameVIP.exe)

```bash
pip install -r requirements.txt
python3 build_linux.py
```

Produces `release-linux/gamevip-panel` — panel with the engine inside —
plus `install.sh`/`tap.sh` copies and `SHA256SUMS.txt`. After copying the
binary anywhere, re-apply the bind bit:

```bash
sudo setcap cap_net_bind_service=+ep gamevip-panel
```

## Uninstall

```bash
./install.sh --uninstall            # interactive paths
./install.sh --silent --uninstall   # scripted
```

Takes processes, firewall rules, launchers, autostart, `~/.local/share/GameBaToVipSpoof`,
and the resolved-stub override with it. Only product files go — your files stay.

## Scripted install

```bash
./install.sh --silent --dir=/opt/gamevip --launch
./install.sh --silent --dir=/opt/gamevip --no-autostart --no-firewall
```

## Why it stops (same card as Windows)

- **Port 80 busy** — apache/nginx or another spoof. Close it, flip ON again.
- **Port 53 busy** — usually `systemd-resolved`. Re-run `install.sh` (frees
  the stub), or `sudo systemctl disable --now systemd-resolved`.
- **PS4 can't reach the PC** — firewall. Re-run `install.sh` (opens LAN-only
  rules), or open UDP 53 + TCP 80 for your LAN subnet manually.
- **Permission denied on 53/80** — the setcap bit didn't stick (copied the
  binary?). Re-run `sudo setcap cap_net_bind_service=+ep gamevip-panel`.

## Files

- `install.sh` — the setup (this file's twin is `GameVIP-Setup.exe`)
- `tap.sh` — the launcher (twin is `TAP.bat`)
- `build_linux.py` — the freezer (twin is `build_release.py`)
- `release-linux/` — `gamevip-panel` + sums (twin is `release/`)
- `app.py`, `tap.py`, `control.py` — shared sources, `os.name`-guarded seams
- Working files: `~/.local/share/GameBaToVipSpoof/` (twin: `%LOCALAPPDATA%\GameBaToVipSpoof`)
