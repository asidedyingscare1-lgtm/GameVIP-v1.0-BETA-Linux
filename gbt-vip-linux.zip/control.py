"""GameVIP control window: the product's own UI, not a console.

Double-clicking the installed shortcut opens this window. One switch:

    ON   starts the spoof and opens the local page in the browser.
    OFF  stops the engine and frees ports 53 and 80.

Closing the window disconnects and ends the panel, so there is no Task Manager
hunt and no curl command to remember. The panel's HTTP page is still there for
the PS4 steps and the live log; this window is the front door to it.

Drawn from the same design system as the setup (charcoal surfaces, red brand,
green state) and reusing the supplied branding art, so the installer and the
installed product read as one product.

The window never touches the engine itself: it is handed the panel's own
callables, so all state lives in app.py.
"""
import base64
import math
import os
import struct
import sys
import threading
import time
import zlib
import tkinter as tk

APP_NAME = 'GameVIP'
APP_TAGLINE = 'PS4 PREMIUM SESSION'
APP_SUBTAGLINE = 'OVER YOUR OWN NETWORK'

# Same tokens as the setup window, so a colour change stays one decision in
# each file rather than two palettes drifting apart.
SWITCH_W, SWITCH_H = 84, 64     # switch canvas, not much wider than it is tall
TRACK_TOP, TRACK_BOTTOM = 12, 52
TRACK_RADIUS = (TRACK_BOTTOM - TRACK_TOP) // 2
TRACK_LEFT = TRACK_RADIUS + 6
TRACK_RIGHT = SWITCH_W - TRACK_RADIUS - 6
HALO = 2                        # focus halo, drawn inside the canvas

# Windows draws the caption bar, not Tk, so the frame has to be asked for in
# DWM terms: dark mode for the bar and the system buttons, plus the exact
# caption/text/border colours on Windows 11. Anything older keeps the default
# light frame -- every call below is best effort and none of it is required.
DWMWA_USE_IMMERSIVE_DARK_MODE = 20
DWMWA_DARK_MODE_LEGACY = 19      # the same attribute on Windows 10 1809-1903
DWMWA_BORDER_COLOR = 34
DWMWA_CAPTION_COLOR = 35
DWMWA_TEXT_COLOR = 36


def colourref(colour):
    """'#rrggbb' as the 0x00BBGGRR integer the Windows colour APIs expect."""
    red, green, blue = (int(colour[index:index + 2], 16) for index in (1, 3, 5))
    return (blue << 16) | (green << 8) | red


# -- the switch, rasterised ---------------------------------------------------
# Tk's canvas has no anti-aliasing, so a create_oval curve comes out
# stair-stepped -- very visible on a 40-pixel-round track. The switch is
# therefore rasterised here: coverage read off a signed distance, composed into
# a transparent PNG, and handed to Tk as an image. Standard library only, so
# the shipped program stays free of an image library; the drawn shapes below
# remain the fallback for a build that cannot make the image.
PILL_CX = (TRACK_LEFT + TRACK_RIGHT) / 2.0
PILL_CY = (TRACK_TOP + TRACK_BOTTOM) / 2.0
PILL_HALF_W = (TRACK_RIGHT - TRACK_LEFT) / 2.0 + TRACK_RADIUS
PILL_HALF_H = (TRACK_BOTTOM - TRACK_TOP) / 2.0
KNOB_RADIUS = TRACK_RADIUS - 4          # the knob, inset inside the track
KNOB_CORE = KNOB_RADIUS / 2.0           # the dark middle it wears when on
KNOB_CORE_COLOUR = '#0b2a18'

C = {'bg': '#060708', 'sidebar': '#0a0b0e', 'card': '#111318',
     'card_edge': '#1e222b', 'ink': '#f2f4f7', 'muted': '#9aa0ab',
     'faint': '#7d838d', 'accent': '#4ae894', 'brand': '#d61f26',
     'brand_hot': '#f0333b', 'ok': '#2fd671', 'warn': '#f5a623',
     'bad': '#ff7d7d', 'row': '#101319', 'line': '#1d4436',
     'track_off': '#232830', 'track_on': '#143b28'}

# Typeface per platform: Segoe UI ships with Windows; Linux desktops ship
# DejaVu Sans (near-metric twin) or plain Sans. Tk falls back silently to a
# wrong-sized default when the named family is missing, which is what used
# to shrink every label on Linux — so the family is chosen up front, once.
if os.name == 'nt':
    FONT, FONT_BOLD = 'Segoe UI', 'Segoe UI Semibold'
else:
    FONT, FONT_BOLD = 'DejaVu Sans', 'DejaVu Sans'


def _rgb(colour):
    """'#rrggbb' as a float triple, for blending."""
    return tuple(float(int(colour[index:index + 2], 16)) for index in (1, 3, 5))


def _coverage(distance):
    """Pixel coverage of an edge: a one-pixel ramp either side of it."""
    return min(1.0, max(0.0, 0.5 - distance))


def _pill_coverage(px, py, grow):
    """Coverage of the track's rounded rectangle, grown for the focus halo."""
    half_w, half_h = PILL_HALF_W + grow, PILL_HALF_H + grow
    radius = TRACK_RADIUS + grow
    dx, dy = px - PILL_CX, py - PILL_CY
    if abs(dx) > half_w + 1 or abs(dy) > half_h + 1:
        return 0.0                                   # nowhere near this shape
    qx, qy = abs(dx) - half_w + radius, abs(dy) - half_h + radius
    distance = (math.hypot(max(qx, 0.0), max(qy, 0.0))
                + min(max(qx, qy), 0.0) - radius)
    return _coverage(distance)


def _circle_coverage(px, py, centre_x, radius):
    """Coverage of a circle sitting on the track's middle line."""
    if abs(px - centre_x) > radius + 1 or abs(py - PILL_CY) > radius + 1:
        return 0.0
    return _coverage(math.hypot(px - centre_x, py - PILL_CY) - radius)


def _layer(state, colour, coverage):
    """Source-over one shape on the pixel built so far: (r, g, b, alpha).

    Straight alpha, so the shape keeps its own colour at the edges and Tk does
    the blending against whatever is behind the switch.
    """
    red, green, blue, alpha = state
    if coverage <= 0.0:
        return state
    out_alpha = alpha + coverage * (1.0 - alpha)
    weight = coverage / out_alpha                   # 1.0 when nothing under it
    return (red + (colour[0] - red) * weight,
            green + (colour[1] - green) * weight,
            blue + (colour[2] - blue) * weight,
            out_alpha)


def _png(width, height, rows):
    """A minimal 8-bit RGBA PNG: what Tk's own image loader reads."""
    def chunk(tag, payload):
        body = tag + payload
        return (struct.pack('>I', len(payload)) + body
                + struct.pack('>I', zlib.crc32(body) & 0xffffffff))

    raw = b''.join(b'\x00' + row for row in rows)      # filter 0 on every row
    header = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', header)
            + chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b''))


def render_switch(on, busy, focus):
    """The switch for one state, as transparent PNG bytes: halo, track, knob.

    Sampled at pixel centres with the shapes in canvas coordinates, so the
    raster sits exactly where the drawn shapes sat -- only with a soft edge
    instead of a hard one. Everything the switch does not cover stays fully
    transparent: the artwork carries an alpha channel rather than a plate of
    the card's colour, so the card itself shows through and no rectangle of
    the switch's own can ever appear behind it.
    """
    halo = _rgb(C['brand_hot'])
    track = _rgb(C['card_edge'] if busy else
                 (C['track_on'] if on else C['track_off']))
    knob = _rgb(C['warn'] if busy else (C['ok'] if on else C['faint']))
    core = _rgb(KNOB_CORE_COLOUR)
    knob_x = float(TRACK_RIGHT if (on or busy) else TRACK_LEFT)
    rows = []
    for y in range(SWITCH_H):
        py = y + 0.5
        row = bytearray()
        for x in range(SWITCH_W):
            px = x + 0.5
            pixel = (0.0, 0.0, 0.0, 0.0)
            if focus:                     # the halo only exists while focused
                pixel = _layer(pixel, halo, _pill_coverage(px, py, HALO))
            pixel = _layer(pixel, track, _pill_coverage(px, py, 0))
            pixel = _layer(pixel, knob,
                           _circle_coverage(px, py, knob_x, KNOB_RADIUS))
            if on:
                pixel = _layer(pixel, core,
                               _circle_coverage(px, py, knob_x, KNOB_CORE))
            row.extend(int(round(channel)) for channel in pixel[:3])
            row.append(int(round(pixel[3] * 255.0)))
        rows.append(bytes(row))
    return _png(SWITCH_W, SWITCH_H, rows)


def app_dir():
    """The folder this build lives in (bundle temp dir when frozen)."""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def asset(*parts):
    """Absolute path of one bundled asset, frozen or run from source."""
    bundle = getattr(sys, '_MEIPASS', None)
    candidates = []
    if bundle:
        candidates.append(os.path.join(bundle, 'assets', *parts))
    here = app_dir()
    candidates.append(os.path.join(here, 'assets', *parts))
    for candidate in candidates:
        if os.path.isfile(candidate):
            return candidate
    return candidates[0]


class Images:
    """Tk images for the branding art, loaded once and kept alive.

    The cleared copy is preferred when it is there: the art ships on a plate of
    its own background, which shows as a rectangle against this window's grey,
    and assets/branding_t holds the same artwork with that frame composited
    into the window's own colour (tools/clear_branding_frames.py). The original
    stays as the fallback, so a checkout without the cleared copy still draws.
    """

    def __init__(self):
        self._images = {}

    def get(self, name, subsample=1):
        key = (name, subsample)
        if key in self._images:
            return self._images[key]
        path = asset('branding_t', name)
        if not os.path.isfile(path):
            path = asset('branding', name)
        image = None
        if os.path.isfile(path):
            try:
                image = tk.PhotoImage(file=path)
            except (tk.TclError, RuntimeError):
                image = None      # no window yet, or an unreadable picture
        if image is not None and subsample > 1:
            try:
                image = image.subsample(subsample, subsample)
            except tk.TclError:
                pass
        self._images[key] = image
        return image


class ControlPanel(tk.Tk):
    """The installed product's window: one switch, one address, one page."""

    POLL_MS = 700          # how often the window reads the panel's real state
    SETTLE_SECONDS = 25    # give up waiting for a slow start/stop and re-read
    CONFIRM_CLOSE = True   # ask before closing while the spoof is serving

    def __init__(self, state, start, stop, open_page, quit_panel, version='1.0'):
        super().__init__()
        self.read_state = state
        self.start_spoof = start
        self.stop_spoof = stop
        self.open_page = open_page
        self.quit_panel = quit_panel
        self.version = version
        self.images = Images()
        self.running = False
        self.pending = None          # 'on' / 'off' while work is in flight
        self.pending_at = 0.0
        self.page_wanted = False     # this switch asked for the page, not the page itself
        self._closing = False
        self._poll_job = None
        self._delayed_jobs = []
        self._switch_images = {}     # rasterised switch, one per state
        self._set_icon()
        try:
            self.withdraw()          # no white flash before the first layout
        except tk.TclError:
            pass
        self.title('%s' % APP_NAME)
        self.configure(bg=C['bg'])
        self.resizable(False, False)
        self._build()
        self._draw_switch()
        self.protocol('WM_DELETE_WINDOW', self.close)
        self._poll_job = self.after(self.POLL_MS, self.poll)
        self.update_idletasks()
        self._centre()
        try:
            self.deiconify()
        except tk.TclError:
            pass
        self.lift()
        self._dark_caption()
        # Focus is deliberately left alone: the switch is reachable with Tab
        # (takefocus) and only then wears its halo, so a window that merely
        # opened never shows a ring around the switch.

    # -- window furniture --------------------------------------------------
    def _set_icon(self):
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except (AttributeError, OSError, ImportError):
            pass
        icon = asset('gbt.ico')
        if os.path.isfile(icon):
            try:
                self.iconbitmap(icon)
            except tk.TclError:
                pass
        # Linux has no .ico frame icon: hand the window manager the PNG art
        # directly (largest first), so the taskbar/dock shows the brand
        # instead of a default Tk feather. Windows keeps the path above —
        # iconphoto with the small emblem is its taskbar refinement.
        if os.name != 'nt':
            for art in ('gamevip-logo.png', 'logo.png'):
                path = asset(art)
                if not os.path.isfile(path):
                    continue
                try:
                    photo = tk.PhotoImage(file=path)
                    self.iconphoto(True, photo)
                    self._linux_icon = photo   # keep alive past this call
                    return
                except tk.TclError:
                    continue
        emblem = self.images.get('sidebar-emblem.png', subsample=4)
        if emblem is not None:
            try:
                self.iconphoto(True, emblem)
            except tk.TclError:
                pass

    def _dark_caption(self, second_pass=False):
        """Ask Windows for a caption bar that matches the window's own grey.

        The frame around a Tk window comes from Windows, which paints it light
        grey over a dark body. DWM is the supported way to change that: dark
        mode for the bar and its buttons, then the caption, text and border
        colours where the build supports them (Windows 11). Applied once more
        shortly after, because a freshly mapped window can be repainted with
        the theme default when it first becomes active.
        """
        if os.name != 'nt':
            return
        try:
            import ctypes
            from ctypes import wintypes
            window = (ctypes.windll.user32.GetParent(self.winfo_id())
                      or self.winfo_id())
            dwm = ctypes.windll.dwmapi

            def attribute(number, value):
                return dwm.DwmSetWindowAttribute(
                    wintypes.HWND(window), wintypes.DWORD(number),
                    ctypes.byref(wintypes.DWORD(value)),
                    ctypes.sizeof(wintypes.DWORD))

            if attribute(DWMWA_USE_IMMERSIVE_DARK_MODE, 1) != 0:
                attribute(DWMWA_DARK_MODE_LEGACY, 1)
            attribute(DWMWA_CAPTION_COLOR, colourref(C['sidebar']))
            attribute(DWMWA_TEXT_COLOR, colourref(C['ink']))
            attribute(DWMWA_BORDER_COLOR, colourref(C['card_edge']))
        except (AttributeError, OSError, ValueError):
            pass                                     # old Windows: light frame
        if not second_pass:
            self._later(140, lambda: self._dark_caption(True))

    def _centre(self):
        width, height = self.winfo_reqwidth(), self.winfo_reqheight()
        self.geometry('%dx%d+%d+%d' % (
            width, height,
            max(0, (self.winfo_screenwidth() - width) // 2),
            max(0, (self.winfo_screenheight() - height) // 3)))

    def _build(self):
        self._build_header()
        self._build_card()
        self._build_footer()

    def _build_header(self):
        header = tk.Frame(self, bg=C['sidebar'])
        header.pack(fill='x')
        row = tk.Frame(header, bg=C['sidebar'])
        row.pack(fill='x', padx=20, pady=(16, 14))
        emblem = self.images.get('sidebar-emblem.png', subsample=4)
        if emblem is not None:
            tk.Label(row, image=emblem, bg=C['sidebar'], bd=0,
                     highlightthickness=0).pack(side='left', padx=(0, 12))
        else:
            tk.Label(row, text='\u25c6', bg=C['sidebar'], fg=C['brand_hot'],
                     font=(FONT, 30)).pack(side='left', padx=(0, 12))
        words = tk.Frame(row, bg=C['sidebar'])
        words.pack(side='left', anchor='w')
        wordmark = self.images.get('sidebar-wordmark.png', subsample=2)
        if wordmark is not None:
            tk.Label(words, image=wordmark, bg=C['sidebar'], bd=0,
                     highlightthickness=0).pack(anchor='w')
        else:
            mark = tk.Frame(words, bg=C['sidebar'])
            mark.pack(anchor='w')
            tk.Label(mark, text='Game', bg=C['sidebar'], fg='#ffffff',
                     font=(FONT_BOLD, 20)).pack(side='left')
            tk.Label(mark, text='VIP', bg=C['sidebar'], fg=C['brand_hot'],
                     font=(FONT_BOLD, 20)).pack(side='left')
        tk.Label(words, text=APP_TAGLINE, bg=C['sidebar'], fg=C['muted'],
                 font=(FONT, 9)).pack(anchor='w', pady=(4, 0))
        tk.Label(words, text=APP_SUBTAGLINE, bg=C['sidebar'], fg=C['faint'],
                 font=(FONT, 8)).pack(anchor='w', pady=(1, 0))
        tk.Frame(self, bg=C['card_edge'], height=1).pack(fill='x')

    def _build_card(self):
        body = tk.Frame(self, bg=C['bg'])
        body.pack(fill='both', expand=True)
        card = tk.Frame(body, bg=C['row'], highlightbackground=C['card_edge'],
                        highlightthickness=1)
        card.pack(fill='x', padx=20, pady=(18, 0), ipady=16)
        inner = tk.Frame(card, bg=C['row'])
        inner.pack(fill='x', padx=18)
        # The canvas carries the card's own background and no highlight ring,
        # so the switch sits on the card with nothing drawn behind or around it.
        self.switch = tk.Canvas(inner, width=SWITCH_W, height=SWITCH_H,
                                bg=C['row'], highlightthickness=0, bd=0,
                                takefocus=1, cursor='hand2')
        self.switch.pack(side='left', padx=(0, 16), pady=(4, 4))
        self.switch.bind('<Button-1>', self.toggle)
        self.switch.bind('<space>', self.toggle)
        self.switch.bind('<Return>', self.toggle)
        self.switch.bind('<FocusIn>', lambda _event: self._draw_switch())
        self.switch.bind('<FocusOut>', lambda _event: self._draw_switch())

        words = tk.Frame(inner, bg=C['row'])
        words.pack(side='left', fill='x', expand=True)
        self.state_label = tk.Label(words, text='DISCONNECTED', bg=C['row'],
                                    fg=C['bad'],
                                    font=(FONT_BOLD, 17))
        self.state_label.pack(anchor='w')
        self.address_label = tk.Label(words, text='', bg=C['row'],
                                      fg=C['muted'], font=(FONT, 10),
                                      justify='left', anchor='w')
        self.address_label.pack(anchor='w', pady=(4, 0))
        self.health_label = tk.Label(words, text='', bg=C['row'], fg=C['muted'],
                                     font=(FONT, 9), justify='left',
                                     anchor='w')
        self.health_label.pack(anchor='w', pady=(4, 0))

        self.hint = tk.Label(body, text='', bg=C['bg'], fg=C['muted'],
                             font=(FONT, 9), justify='left', anchor='w',
                             wraplength=304)
        self.hint.pack(fill='x', padx=22, pady=(12, 0))

    def _build_footer(self):
        tk.Frame(self, bg=C['card_edge'], height=1).pack(fill='x')
        footer = tk.Frame(self, bg=C['bg'])
        footer.pack(fill='x')
        buttons = tk.Frame(footer, bg=C['bg'])
        buttons.pack(side='right', padx=20, pady=14)
        self.open_button = self._button(buttons, 'Open the local page',
                                       self.show_page, kind='brand')
        self.open_button.pack(side='left')
        tk.Label(footer, text='Version %s' % self.version, bg=C['bg'],
                 fg=C['faint'], font=(FONT, 8)).pack(side='left',
                                                           padx=20)

    def _button(self, parent, text, command, kind='ghost'):
        colours = {'brand': (C['brand'], '#ffffff', C['brand_hot']),
                   'ghost': (C['row'], C['ink'], C['card_edge'])}[kind]
        # Same two button kinds as the setup footer: a red primary and a dark
        # ghost whose text carries it. The one-pixel highlight reserves the
        # ring Tk paints around a focused button; unfocused it shows nothing,
        # so the fill and the text do the styling, as on the approved pages.
        return tk.Button(parent, text=text, command=command, bg=colours[0],
                         fg=colours[1], activebackground=colours[2],
                         activeforeground=colours[1], relief='flat', bd=0,
                         font=(FONT_BOLD, 10), cursor='hand2',
                         highlightthickness=1,
                         highlightbackground=C['bg'],
                         highlightcolor=C['brand_hot'], padx=14, pady=9,
                         disabledforeground=C['faint'], takefocus=1)

    # -- the switch --------------------------------------------------------
    def _pill(self, grow, colour):
        """Draw one rounded track: two end circles plus the bar between them."""
        canvas = self.switch
        top, bottom = TRACK_TOP - grow, TRACK_BOTTOM + grow
        left, right = TRACK_LEFT - grow, TRACK_RIGHT + grow
        radius = TRACK_RADIUS + grow
        canvas.create_oval(left - radius, top, left + radius, bottom,
                           fill=colour, outline=colour)
        canvas.create_oval(right - radius, top, right + radius, bottom,
                           fill=colour, outline=colour)
        canvas.create_rectangle(left, top, right, bottom,
                                fill=colour, outline=colour)

    def _switch_photo(self, on, busy, focus):
        """The switch as a Tk image, rasterised once per state.

        Tk draws its shapes aliased, so the track and the knob used to come out
        stair-stepped. The image is built from the same geometry and cached by
        state -- six at most, so a flip costs one lookup. None means no image
        could be made (an old Tk without PNG) and the drawn shapes take over.
        """
        key = (bool(on), bool(busy), bool(focus))
        if key not in self._switch_images:
            image = None
            try:
                image = tk.PhotoImage(
                    data=base64.b64encode(render_switch(on, busy, focus))
                    .decode('ascii'))
            except (tk.TclError, ValueError, RuntimeError, OSError):
                image = None
            self._switch_images[key] = image
        return self._switch_images[key]

    def _draw_switch(self):
        """Paint the switch for the state the panel is actually in.

        The rasterised image is preferred because Tk's own canvas shapes have
        no anti-aliasing; the drawn shapes stay as the fallback when no image
        can be made. Nothing else is painted either way: the canvas keeps the
        card's background, so there is no box or outline behind the switch,
        and the keyboard focus cue is a halo inside the artwork rather than a
        ring around the widget.
        """
        canvas = self.switch
        canvas.delete('all')
        busy = self.pending is not None
        on = self.pending == 'on' or (not busy and self.running)
        focus = self.focus_get() is canvas
        photo = self._switch_photo(on, busy, focus)
        if photo is not None:
            canvas.create_image(0, 0, anchor='nw', image=photo)
            return
        knob = C['warn'] if busy else (C['ok'] if on else C['faint'])
        track = C['card_edge'] if busy else (C['track_on'] if on else C['track_off'])
        # Keyboard focus shows as a thin halo hugging the pill, drawn inside the
        # canvas: an outer highlight ring would frame the switch in a box.
        self._pill(HALO, C['brand_hot'] if focus else C['row'])
        self._pill(0, track)
        middle = (TRACK_TOP + TRACK_BOTTOM) // 2
        knob_x = TRACK_RIGHT if (on or busy) else TRACK_LEFT
        knob_r = int(KNOB_RADIUS)
        canvas.create_oval(knob_x - knob_r, middle - knob_r,
                           knob_x + knob_r, middle + knob_r,
                           fill=knob, outline=knob)
        if on:
            canvas.create_oval(knob_x - knob_r // 2, middle - knob_r // 2,
                               knob_x + knob_r // 2, middle + knob_r // 2,
                               fill=KNOB_CORE_COLOUR, outline=KNOB_CORE_COLOUR)

    def toggle(self, _event=None):
        """Flip the switch: ON serves and opens the page, OFF disconnects."""
        if self._closing or self.pending is not None:
            return
        self._commit(not self.running)

    def _commit(self, want_on):
        self.pending = 'on' if want_on else 'off'
        self.pending_at = time.monotonic()
        # "On" means the page too: this flip is what asks for it. A spoof
        # started from the page itself must not open a second tab, so the
        # request is tied to this switch rather than to the running state.
        self.page_wanted = bool(want_on)
        if not want_on:
            self.page_wanted = False
        self._draw_switch()
        self._paint_state()
        threading.Thread(target=self._work, args=(want_on,), daemon=True).start()

    def _work(self, want_on):
        """Start or stop the spoof off the UI thread: both run PowerShell.

        want_on is the flip that asked for this, not whatever the state looks
        like by the time the thread runs: a queued thread must not read a
        later flip's intention.
        """
        try:
            if want_on:
                self.start_spoof()
            else:
                self.stop_spoof()
        except Exception as error:                   # surfaced, never swallowed
            self.hint.configure(text='The panel could not %s the spoof: %s'
                                     % ('start' if want_on else 'stop', error))
        self.pending_at = time.monotonic()           # settle window starts now

    # -- state polling -----------------------------------------------------
    def poll(self):
        """Read the real state twice a second and repaint when it moves.

        Any timer still pending is cancelled first: this runs as that timer's
        own callback normally, but a call from anywhere else (a test, a future
        menu action) would otherwise orphan the scheduled job.
        """
        if self._poll_job is not None:
            try:
                self.after_cancel(self._poll_job)
            except tk.TclError:
                pass
            self._poll_job = None
        if self._closing:
            return
        state = None
        try:
            state = self.read_state()
        except Exception as error:                   # a probe must never kill the loop
            self.hint.configure(text='Cannot read the panel state: %s' % error)
        if state is not None:
            self.running = bool(state.get('running'))
            if self.pending is not None:
                settled = (self.running if self.pending == 'on' else not self.running)
                if settled or time.monotonic() - self.pending_at > self.SETTLE_SECONDS:
                    self.pending = None
            self.address = state.get('ip') or ''
            self.note = state.get('note') or ''
            self._paint_state()
            self._draw_switch()
            if self.page_wanted and self.running:
                self.page_wanted = False
                self.show_page()
        if not self._closing:
            self._poll_job = self.after(self.POLL_MS, self.poll)

    def _paint_state(self):
        busy = self.pending is not None
        if busy:
            word = 'STARTING' if self.pending == 'on' else 'STOPPING'
            self.state_label.configure(text=word, fg=C['warn'])
            self.hint.configure(text='One moment - the engine is being '
                                     '%s.' % ('started' if self.pending == 'on'
                                              else 'stopped'))
            return
        address = getattr(self, 'address', '')
        if self.running:
            self.state_label.configure(text='CONNECTED', fg=C['ok'])
            self.address_label.configure(
                text='PS4 DNS  %s' % (address or 'this PC'))
            note = getattr(self, 'note', '')
            self.health_label.configure(
                text=note if note else 'Ports 53 and 80 are serving.')
            self.hint.configure(text='The page is open in your browser. Point '
                                     "the PS4's DNS at this PC, then start the "
                                     'store app.')
        else:
            self.state_label.configure(text='DISCONNECTED', fg=C['bad'])
            self.address_label.configure(
                text='PS4 DNS  %s  (idle)' % (address or 'this PC'))
            self.health_label.configure(text='Ports 53 and 80 are free.')
            self.hint.configure(text='Flip the switch on to serve the PS4 and '
                                     'open the local page.')

    def show_page(self):
        try:
            self.open_page()
        except Exception as error:                   # a dead browser is not fatal
            self.hint.configure(text='Could not open the page: %s' % error)

    # -- timers ------------------------------------------------------------
    def _later(self, delay_ms, callback):
        """A one-shot UI callback that dies with the window."""
        job = None

        def run():
            if job in self._delayed_jobs:
                self._delayed_jobs.remove(job)
            if not self._closing:
                callback()

        job = self.after(delay_ms, run)
        self._delayed_jobs.append(job)
        return job

    def destroy(self):
        """Cancel the timers first, then take the window down."""
        if self._closing:
            return
        self._closing = True
        jobs = [self._poll_job] + list(self._delayed_jobs)
        self._poll_job = None
        self._delayed_jobs = []
        for job in jobs:
            if job is None:
                continue
            try:
                self.after_cancel(job)
            except tk.TclError:
                pass
        super().destroy()

    # -- closing -----------------------------------------------------------
    def close(self):
        """Disconnect and end the panel, after one confirmation when serving."""
        if self._closing:
            return
        if self.running and self.CONFIRM_CLOSE and self.pending is None:
            from tkinter import messagebox
            try:
                stay = messagebox.askyesno(
                    '%s' % APP_NAME,
                    'The spoof is serving the PS4.\n\n'
                    'Quit anyway? The PS4 loses the premium session until you '
                    'start the panel again.')
            except tk.TclError:
                stay = False
            if not stay:
                return
        self.destroy()
        self.quit_panel()


def available():
    """True when this build can show the window at all."""
    try:
        import tkinter                                  # noqa: F401
    except ImportError:
        return False
    return True


def run(state, start, stop, open_page, quit_panel, version='1.0'):
    """Show the control window and block until the user closes it."""
    panel = ControlPanel(state=state, start=start, stop=stop,
                         open_page=open_page, quit_panel=quit_panel,
                         version=version)
    panel.mainloop()
    return 0
